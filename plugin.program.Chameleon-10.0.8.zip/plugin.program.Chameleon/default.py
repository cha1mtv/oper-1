# encode('utf8')
# coding: utf-8
import xbmc ,xbmcaddon ,xbmcgui ,xbmcplugin ,os ,sys ,xbmcvfs ,glob #line:50
import shutil #line:51
import urllib2 ,urllib #line:52
import re #line:53
import zipfile #line:54
import uservar #line:55
import fnmatch #line:56
try :from sqlite3 import dbapi2 as database #line:57
except :from pysqlite2 import dbapi2 as database #line:58
from datetime import date ,datetime ,timedelta #line:59
from urlparse import urljoin #line:60
from resources .libs import extract ,downloader ,notify ,debridit ,traktit ,allucit ,loginit ,net ,skinSwitch ,uploadLog ,yt ,speedtest ,wizard as wiz ,addonwindow as pyxbmct #line:61
ADDON_ID =uservar .ADDON_ID #line:64
ADDONTITLE =uservar .ADDONTITLE #line:65
ADDON =wiz .addonId (ADDON_ID )#line:66
VERSION =wiz .addonInfo (ADDON_ID ,'version')#line:67
ADDONPATH =wiz .addonInfo (ADDON_ID ,'path')#line:68
DIALOG =xbmcgui .Dialog ()#line:69
DP =xbmcgui .DialogProgress ()#line:70
HOME =xbmc .translatePath ('special://home/')#line:71
LOG =xbmc .translatePath ('special://logpath/')#line:72
PROFILE =xbmc .translatePath ('special://profile/')#line:73
TEMPDIR =xbmc .translatePath ('special://temp')#line:74
ADDONS =os .path .join (HOME ,'addons')#line:75
USERDATA =os .path .join (HOME ,'userdata')#line:76
PLUGIN =os .path .join (ADDONS ,ADDON_ID )#line:77
PACKAGES =os .path .join (ADDONS ,'packages')#line:78
ADDOND =os .path .join (USERDATA ,'addon_data')#line:79
ADDONDATA =os .path .join (USERDATA ,'addon_data',ADDON_ID )#line:80
ADVANCED =os .path .join (USERDATA ,'advancedsettings.xml')#line:81
SOURCES =os .path .join (USERDATA ,'sources.xml')#line:82
FAVOURITES =os .path .join (USERDATA ,'favourites.xml')#line:83
PROFILES =os .path .join (USERDATA ,'profiles.xml')#line:84
GUISETTINGS =os .path .join (USERDATA ,'guisettings.xml')#line:85
THUMBS =os .path .join (USERDATA ,'Thumbnails')#line:86
DATABASE =os .path .join (USERDATA ,'Database')#line:87
FANART =os .path .join (PLUGIN ,'fanart.jpg')#line:88
ICON =os .path .join (PLUGIN ,'icon.png')#line:89
ART =os .path .join (PLUGIN ,'resources','art')#line:90
WIZLOG =os .path .join (ADDONDATA ,'wizard.log')#line:91
SPEEDTESTFOLD =os .path .join (ADDONDATA ,'SpeedTest')#line:92
ARCHIVE_CACHE =os .path .join (TEMPDIR ,'archive_cache')#line:93
SKIN =xbmc .getSkinDir ()#line:94
BUILDNAME =wiz .getS ('buildname')#line:95
DEFAULTSKIN =wiz .getS ('defaultskin')#line:96
DEFAULTNAME =wiz .getS ('defaultskinname')#line:97
DEFAULTIGNORE =wiz .getS ('defaultskinignore')#line:98
BUILDVERSION =wiz .getS ('buildversion')#line:99
BUILDTHEME =wiz .getS ('buildtheme')#line:100
BUILDLATEST =wiz .getS ('latestversion')#line:101
SHOW15 =wiz .getS ('show15')#line:102
SHOW16 =wiz .getS ('show16')#line:103
SHOW17 =wiz .getS ('show17')#line:104
SHOW18 =wiz .getS ('show18')#line:105
SHOWADULT =wiz .getS ('adult')#line:106
SHOWMAINT =wiz .getS ('showmaint')#line:107
AUTOCLEANUP =wiz .getS ('autoclean')#line:108
AUTOCACHE =wiz .getS ('clearcache')#line:109
AUTOPACKAGES =wiz .getS ('clearpackages')#line:110
AUTOTHUMBS =wiz .getS ('clearthumbs')#line:111
AUTOFEQ =wiz .getS ('autocleanfeq')#line:112
AUTONEXTRUN =wiz .getS ('nextautocleanup')#line:113
INCLUDEVIDEO =wiz .getS ('includevideo')#line:114
INCLUDEALL =wiz .getS ('includeall')#line:115
INCLUDEBOB =wiz .getS ('includebob')#line:116
INCLUDEPHOENIX =wiz .getS ('includephoenix')#line:117
INCLUDESPECTO =wiz .getS ('includespecto')#line:118
INCLUDEGENESIS =wiz .getS ('includegenesis')#line:119
INCLUDEEXODUS =wiz .getS ('includeexodus')#line:120
INCLUDEONECHAN =wiz .getS ('includeonechan')#line:121
INCLUDESALTS =wiz .getS ('includesalts')#line:122
INCLUDESALTSHD =wiz .getS ('includesaltslite')#line:123
SEPERATE =wiz .getS ('seperate')#line:124
NOTIFY =wiz .getS ('notify')#line:125
NOTEID =wiz .getS ('noteid')#line:126
NOTEDISMISS =wiz .getS ('notedismiss')#line:127
TRAKTSAVE =wiz .getS ('traktlastsave')#line:128
REALSAVE =wiz .getS ('debridlastsave')#line:129
ALLUCSAVE =wiz .getS ('alluclastsave')#line:130
LOGINSAVE =wiz .getS ('loginlastsave')#line:131
KEEPFAVS =wiz .getS ('keepfavourites')#line:132
FAVSsave =wiz .getS ('favouriteslastsave')#line:133
KEEPSOURCES =wiz .getS ('keepsources')#line:134
KEEPPROFILES =wiz .getS ('keepprofiles')#line:135
KEEPADVANCED =wiz .getS ('keepadvanced')#line:136
KEEPREPOS =wiz .getS ('keeprepos')#line:137
KEEPSUPER =wiz .getS ('keepsuper')#line:138
KEEPWHITELIST =wiz .getS ('keepwhitelist')#line:139
KEEPTRAKT =wiz .getS ('keeptrakt')#line:140
KEEPREAL =wiz .getS ('keepdebrid')#line:141
KEEPALLUC =wiz .getS ('keepalluc')#line:142
KEEPLOGIN =wiz .getS ('keeplogin')#line:143
DEVELOPER =wiz .getS ('developer')#line:144
THIRDPARTY =wiz .getS ('enable3rd')#line:145
THIRD1NAME =wiz .getS ('wizard1name')#line:146
THIRD1URL =wiz .getS ('wizard1url')#line:147
THIRD2NAME =wiz .getS ('wizard2name')#line:148
THIRD2URL =wiz .getS ('wizard2url')#line:149
THIRD3NAME =wiz .getS ('wizard3name')#line:150
THIRD3URL =wiz .getS ('wizard3url')#line:151
BACKUPLOCATION =ADDON .getSetting ('path')if not ADDON .getSetting ('path')==''else 'special://home/'#line:152
BACKUPROMS =wiz .getS ('rompath')#line:153
MYBUILDS =os .path .join (BACKUPLOCATION ,'My_Builds','')#line:154
AUTOFEQ =int (float (AUTOFEQ ))if AUTOFEQ .isdigit ()else 0 #line:155
TODAY =date .today ()#line:156
TOMORROW =TODAY +timedelta (days =1 )#line:157
THREEDAYS =TODAY +timedelta (days =3 )#line:158
KODIV =float (xbmc .getInfoLabel ("System.BuildVersion")[:4 ])#line:159
if KODIV >17 :#line:160
	from resources .libs import zfile as zipfile #line:161
else :#line:162
	import zipfile #line:163
MCNAME =wiz .mediaCenter ()#line:164
EXCLUDES =uservar .EXCLUDES #line:165
CACHETEXT =uservar .CACHETEXT #line:166
CACHEAGE =uservar .CACHEAGE if str (uservar .CACHEAGE ).isdigit ()else 30 #line:167
BUILDFILE =uservar .BUILDFILE #line:168
ADDONPACK =uservar .ADDONPACK #line:169
APKFILE =uservar .APKFILE #line:170
YOUTUBETITLE =uservar .YOUTUBETITLE #line:171
YOUTUBEFILE =uservar .YOUTUBEFILE #line:172
ADDONFILE =uservar .ADDONFILE #line:173
ADVANCEDFILE =uservar .ADVANCEDFILE #line:174
UPDATECHECK =uservar .UPDATECHECK if str (uservar .UPDATECHECK ).isdigit ()else 1 #line:175
NEXTCHECK =TODAY +timedelta (days =UPDATECHECK )#line:176
NOTIFICATION =uservar .NOTIFICATION #line:177
ENABLE =uservar .ENABLE #line:178
HEADERMESSAGE =uservar .HEADERMESSAGE #line:179
AUTOUPDATE =uservar .AUTOUPDATE #line:180
BUILDERNAME =uservar .BUILDERNAME #line:181
WIZARDFILE =uservar .WIZARDFILE #line:182
HIDECONTACT =uservar .HIDECONTACT #line:183
CONTACT =uservar .CONTACT #line:184
CONTACTICON =uservar .CONTACTICON if not uservar .CONTACTICON =='http://'else ICON #line:185
CONTACTFANART =uservar .CONTACTFANART if not uservar .CONTACTFANART =='http://'else FANART #line:186
HIDESPACERS =uservar .HIDESPACERS #line:187
COLOR1 =uservar .COLOR1 #line:188
COLOR2 =uservar .COLOR2 #line:189
THEME1 =uservar .THEME1 #line:190
THEME2 =uservar .THEME2 #line:191
THEME3 =uservar .THEME3 #line:192
THEME4 =uservar .THEME4 #line:193
THEME5 =uservar .THEME5 #line:194
THEME6 =uservar .THEME6 #line:195
ICONBUILDS =uservar .ICONBUILDS if not uservar .ICONBUILDS =='http://'else ICON #line:196
ICONMAINT =uservar .ICONMAINT if not uservar .ICONMAINT =='http://'else ICON #line:197
ICONAPK =uservar .ICONAPK if not uservar .ICONAPK =='http://'else ICON #line:198
ICONADDONS =uservar .ICONADDONS if not uservar .ICONADDONS =='http://'else ICON #line:199
ICONYOUTUBE =uservar .ICONYOUTUBE if not uservar .ICONYOUTUBE =='http://'else ICON #line:200
ICONSAVE =uservar .ICONSAVE if not uservar .ICONSAVE =='http://'else ICON #line:201
ICONTRAKT =uservar .ICONTRAKT if not uservar .ICONTRAKT =='http://'else ICON #line:202
ICONREAL =uservar .ICONREAL if not uservar .ICONREAL =='http://'else ICON #line:203
ICONLOGIN =uservar .ICONLOGIN if not uservar .ICONLOGIN =='http://'else ICON #line:204
ICONCONTACT =uservar .ICONCONTACT if not uservar .ICONCONTACT =='http://'else ICON #line:205
ICONSETTINGS =uservar .ICONSETTINGS if not uservar .ICONSETTINGS =='http://'else ICON #line:206
Images =xbmc .translatePath (os .path .join ('special://home','addons',ADDON_ID ,'resources','images/'));#line:207
LOGFILES =wiz .LOGFILES #line:208
TRAKTID =traktit .TRAKTID #line:209
DEBRIDID =debridit .DEBRIDID #line:210
LOGINID =loginit .LOGINID #line:211
ALLUCID =allucit .ALLUCID #line:212
MODURL ='http://tribeca.tvaddons.ag/tools/maintenance/modules/'#line:213
MODURL2 ='http://mirrors.kodi.tv/addons/jarvis/'#line:214
INSTALLMETHODS =['Always Ask','Reload Profile','Force Close']#line:215
DEFAULTPLUGINS =['metadata.album.universal','metadata.artists.universal','metadata.common.fanart.tv','metadata.common.imdb.com','metadata.common.musicbrainz.org','metadata.themoviedb.org','metadata.tvdb.com','service.xbmc.versioncheck']#line:216
ROMPACK =uservar .ROMPACK #line:218
EMUAPKS =uservar .EMUAPKS #line:219
ROMPATH =ADDON .getSetting ('rompath')if not ADDON .getSetting ('rompath')==''else 'special://home/'#line:220
ROMLOC =os .path .join (ROMPATH ,'Roms','')#line:221
try :#line:222
	INSTALLMETHOD =int (float (wiz .getS ('installmethod')))#line:223
except :#line:224
	INSTALLMETHOD =0 #line:225
global Bname #line:227
Bname =""#line:228
def index ():#line:237
	OOOO0000O0000O0O0 =int (errorChecking (count =True ))#line:238
	OO00OO00O0OOO0OOO =str (OOOO0000O0000O0O0 )#line:239
	O0O0O0000O0OOOO00 ='[COLOR red]%s[/COLOR] Error(s) נמצא/ו'%(OO00OO00O0OOO0OOO )if OOOO0000O0000O0O0 >0 else 'אין שגיאות'#line:240
	if AUTOUPDATE =='Yes':#line:241
		OOO000O0OOOOOO0O0 =wiz .textCache (WIZARDFILE )#line:242
		if not OOO000O0OOOOOO0O0 ==False :#line:243
			OO0O0OOO0OOOO0OO0 =wiz .checkWizard ('version')#line:244
			if OO0O0OOO0OOOO0OO0 >VERSION :addFile ('%s [v%s] [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(ADDONTITLE ,VERSION ,OO0O0OOO0OOOO0OO0 ),'wizardupdate',themeit =THEME2 )#line:245
			else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:246
		else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:247
	else :addFile ('%s [v%s]'%(ADDONTITLE ,VERSION ),'',themeit =THEME2 )#line:248
	if len (BUILDNAME )>0 :#line:249
		O00O0000OOOO0O0O0 =wiz .checkBuild (BUILDNAME ,'version')#line:250
		O000O0O000OO00OOO ='%s (v%s)'%(BUILDNAME ,BUILDVERSION )#line:251
		if O00O0000OOOO0O0O0 >BUILDVERSION :O000O0O000OO00OOO ='%s [COLOR red][B][UPDATE v%s][/B][/COLOR]'%(O000O0O000OO00OOO ,O00O0000OOOO0O0O0 )#line:252
		addDir (O000O0O000OO00OOO ,'viewbuild',BUILDNAME ,themeit =THEME4 )#line:253
		O0O0OOOOO000O0O0O =wiz .themeCount (BUILDNAME )#line:254
		if not O0O0OOOOO000O0O0O ==False :#line:255
			addFile ('None'if BUILDTHEME ==""else BUILDTHEME ,'theme',BUILDNAME ,themeit =THEME5 )#line:256
	else :addDir ('None','builds',themeit =THEME4 )#line:257
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:258
	addDir ('בילדים','builds',icon =ICONBUILDS ,themeit =THEME1 )#line:259
	addDir ('תחזוקה','maint',icon =ICONMAINT ,themeit =THEME1 )#line:260
	addDir ('כלי אינטרנט','net',icon =ICONCONTACT ,themeit =THEME1 )#line:261
	if wiz .platform ()=='android'or DEVELOPER =='true':addDir ('Apk Installer','apk',icon =ICONAPK ,themeit =THEME1 )#line:262
	if wiz .platform ()=='android'or wiz .platform ()=='windows'or DEVELOPER =='true':addDir ('Retro Gaming Zone','retromenu',icon =ICONSAVE ,themeit =THEME1 )#line:263
	if not ADDONFILE =='http://':addDir ('Addon Installer','addons',icon =ICONADDONS ,themeit =THEME1 )#line:264
	if not YOUTUBEFILE =='http://'and not YOUTUBETITLE =='':addDir (YOUTUBETITLE ,'youtube',icon =ICONYOUTUBE ,themeit =THEME1 )#line:265
	addDir ('Save Login Data / Favs Options','savedata',icon =ICONSAVE ,themeit =THEME1 )#line:266
	addDir ('גיבוי/שחזור Data Options','backup',icon =ICONSAVE ,themeit =THEME1 )#line:267
	if HIDECONTACT =='No':addFile ('Contact','contact',icon =ICONCONTACT ,themeit =THEME1 )#line:268
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:269
	addFile ('Upload Log File','uploadlog',icon =ICONMAINT ,themeit =THEME1 )#line:270
	addFile ('View Errors in Log: %s'%(O0O0O0000O0OOOO00 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME1 )#line:271
	if OOOO0000O0000O0O0 >0 :addFile ('View Last Error In Log','viewerrorlast',icon =ICONMAINT ,themeit =THEME1 )#line:272
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:273
	addFile ('Settings','settings',icon =ICONSETTINGS ,themeit =THEME1 )#line:274
	addFile ('Force Update Text Files','forcetext',icon =ICONMAINT ,themeit =THEME1 )#line:275
	if DEVELOPER =='true':addDir ('Developer Menu','developer',icon =ICON ,themeit =THEME1 )#line:276
	xbmc .executeJSONRPC ('{"jsonrpc":"2.0","method":"Settings.SetSettingValue","id":1,"params":{"setting":"lookandfeel.font","value":"Arial"}}')#line:277
	setView ('files','viewType')#line:278
def KodiVer ():#line:279
	if KODIV >=16.0 and KODIV <=16.9 :O0O0OOOOOOOOOOOO0 ='Jarvis'#line:280
	elif KODIV >=17.0 and KODIV <=17.9 :O0O0OOOOOOOOOOOO0 ='Krypton'#line:281
	elif KODIV >=18.0 and KODIV <=18.9 :O0O0OOOOOOOOOOOO0 ='Leia'#line:282
	else :O0O0OOOOOOOOOOOO0 ="Unknown"#line:283
	return O0O0OOOOOOOOOOOO0 #line:284
def buildMenu ():#line:285
	OO0O0O0OOO0OOO0OO =KodiVer ()#line:287
	O0OO0OO00000O000O =wiz .textCache (BUILDFILE )#line:288
	if O0OO0OO00000O000O ==False :#line:289
		O0O0O0OOO00O00000 =wiz .workingURL (BUILDFILE )#line:290
		addFile ('%s Version: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:291
		addDir ('Save Data Menu','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:292
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:293
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:294
		addFile ('%s'%O0O0O0OOO00O00000 ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:295
		return #line:296
	O000O0OOO0OOOOOOO ,OO0OO000O00O0OOO0 ,O00O000O0OO00OOO0 ,OOO0OO0000O0O000O ,OOOO0O000OOO0OOOO ,OOO0OO000000OO000 ,O00OO0OO0OO00000O =wiz .buildCount ()#line:297
	O0OOO000O00OOO0OO =False ;OO0OOOO0OO000O000 =[]#line:298
	if THIRDPARTY =='true':#line:299
		if not THIRD1NAME ==''and not THIRD1URL =='':O0OOO000O00OOO0OO =True ;OO0OOOO0OO000O000 .append ('1')#line:300
		if not THIRD2NAME ==''and not THIRD2URL =='':O0OOO000O00OOO0OO =True ;OO0OOOO0OO000O000 .append ('2')#line:301
		if not THIRD3NAME ==''and not THIRD3URL =='':O0OOO000O00OOO0OO =True ;OO0OOOO0OO000O000 .append ('3')#line:302
	OOOOO0OOOO000O0OO =O0OO0OO00000O000O .replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('adult=""','adult="no"').replace ('url2=""','url2="http://"').replace ('url3=""','url3="http://"').replace ('preview=""','preview="http://"')#line:303
	O00000OO0OO0OOO0O =re .compile ('name="(.+?)".+?ersion="(.+?)".+?rl="(.+?)".+?rl2="(.+?)".+?rl3="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)".+?review="(.+?)"').findall (OOOOO0OOOO000O0OO )#line:304
	if O000O0OOO0OOOOOOO ==1 and O0OOO000O00OOO0OO ==False :#line:305
		for OO00OO000OO000O00 ,O0OO00O0000O0OO0O ,OO0OOO00OOO0OO0OO ,OOO00OOOO00OOOOOO ,O0OO00OO00O000OO0 ,O00O0O0O0OO0OOO0O ,O000000000OOOO0O0 ,O0O000OO00OOO0O00 ,O00OO00OOO00OOO00 ,OO0O0O0OO000OO000 ,O0OO0OO0OO0O0O0O0 ,OO0OOOO0000OO0OOO ,O000O00OOO0O00OO0 in O00000OO0OO0OOO0O :#line:306
			if not SHOWADULT =='true'and O0OO0OO0OO0O0O0O0 .lower ()=='yes':continue #line:307
			if not DEVELOPER =='true'and wiz .strTest (OO00OO000OO000O00 ):continue #line:308
			viewBuild (O00000OO0OO0OOO0O [0 ][0 ])#line:309
			return #line:310
	addFile ('%s גרסה: %s'%(MCNAME ,KODIV ),'',icon =ICONBUILDS ,themeit =THEME3 )#line:311
	addDir ('Save Data Menu','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:312
	addDir ('[COLOR yellow]---[B][COLOR lime]Addon Packs [COLOR blue]/ [COLOR red]Fixes[/COLOR][/B][COLOR yellow]---[/COLOR]','viewpack',icon =ICONMAINT ,themeit =THEME1 )#line:313
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:314
	if O0OOO000O00OOO0OO ==True :#line:315
		for O0OOO00O000O0O00O in OO0OOOO0OO000O000 :#line:316
			OO00OO000OO000O00 =eval ('THIRD%sNAME'%O0OOO00O000O0O00O )#line:317
			addDir ("[B]%s[/B]"%OO00OO000OO000O00 ,'viewthirdparty',O0OOO00O000O0O00O ,icon =ICONBUILDS ,themeit =THEME3 )#line:318
	if len (O00000OO0OO0OOO0O )>=1 :#line:319
		if SEPERATE =='true':#line:320
			for OO00OO000OO000O00 ,O0OO00O0000O0OO0O ,OO0OOO00OOO0OO0OO ,OOO00OOOO00OOOOOO ,O0OO00OO00O000OO0 ,O00O0O0O0OO0OOO0O ,O000000000OOOO0O0 ,O0O000OO00OOO0O00 ,O00OO00OOO00OOO00 ,OO0O0O0OO000OO000 ,O0OO0OO0OO0O0O0O0 ,OO0OOOO0000OO0OOO ,O000O00OOO0O00OO0 in O00000OO0OO0OOO0O :#line:321
				if not SHOWADULT =='true'and O0OO0OO0OO0O0O0O0 .lower ()=='yes':continue #line:322
				if not DEVELOPER =='true'and wiz .strTest (OO00OO000OO000O00 ):continue #line:323
				OO0OOOO0OO0000OO0 =createMenu ('install','',OO00OO000OO000O00 )#line:324
				addDir ('[%s] %s (v%s)'%(float (O000000000OOOO0O0 ),OO00OO000OO000O00 ,O0OO00O0000O0OO0O ),'viewbuild',OO00OO000OO000O00 ,description =OO0OOOO0000OO0OOO ,fanart =OO0O0O0OO000OO000 ,icon =O00OO00OOO00OOO00 ,menu =OO0OOOO0OO0000OO0 ,themeit =THEME2 )#line:325
		elif DEVELOPER =='true':#line:326
			if OO0OO000O00O0OOO0 >0 :#line:327
				addFile ('[B]Test builds[/B]','togglesetting','show15',themeit =THEME3 )#line:328
				for OO00OO000OO000O00 ,O0OO00O0000O0OO0O ,OO0OOO00OOO0OO0OO ,OOO00OOOO00OOOOOO ,O0OO00OO00O000OO0 ,O00O0O0O0OO0OOO0O ,O000000000OOOO0O0 ,O0O000OO00OOO0O00 ,O00OO00OOO00OOO00 ,OO0O0O0OO000OO000 ,O0OO0OO0OO0O0O0O0 ,OO0OOOO0000OO0OOO ,O000O00OOO0O00OO0 in O00000OO0OO0OOO0O :#line:329
					if not SHOWADULT =='true'and O0OO0OO0OO0O0O0O0 .lower ()=='yes':continue #line:330
					if not DEVELOPER =='true'and wiz .strTest (OO00OO000OO000O00 ):continue #line:331
					OOOO00OOO0000O0O0 =int (float (O000000000OOOO0O0 ))#line:332
					if OOOO00OOO0000O0O0 <=15 :#line:333
						OO0OOOO0OO0000OO0 =createMenu ('install','',OO00OO000OO000O00 )#line:334
						addDir (' %s (v%s)'%(OO00OO000OO000O00 ,O0OO00O0000O0OO0O ),'viewbuild',OO00OO000OO000O00 ,description =OO0OOOO0000OO0OOO ,fanart =OO0O0O0OO000OO000 ,icon =O00OO00OOO00OOO00 ,menu =OO0OOOO0OO0000OO0 ,themeit =THEME2 )#line:335
			if OOOO0O000OOO0OOOO >0 :#line:336
				O00OO0000OOOOO0OO ='+'if SHOW18 =='false'else '-'#line:337
				addFile ('[B]%s Leia Builds(%s)[/B]'%(O00OO0000OOOOO0OO ,OOOO0O000OOO0OOOO ),'togglesetting','show18',themeit =THEME3 )#line:338
				if SHOW18 =='true':#line:339
					for OO00OO000OO000O00 ,O0OO00O0000O0OO0O ,OO0OOO00OOO0OO0OO ,OOO00OOOO00OOOOOO ,O0OO00OO00O000OO0 ,O00O0O0O0OO0OOO0O ,O000000000OOOO0O0 ,O0O000OO00OOO0O00 ,O00OO00OOO00OOO00 ,OO0O0O0OO000OO000 ,O0OO0OO0OO0O0O0O0 ,OO0OOOO0000OO0OOO ,O000O00OOO0O00OO0 in O00000OO0OO0OOO0O :#line:340
						if not SHOWADULT =='true'and O0OO0OO0OO0O0O0O0 .lower ()=='yes':continue #line:341
						if not DEVELOPER =='true'and wiz .strTest (OO00OO000OO000O00 ):continue #line:342
						OOOO00OOO0000O0O0 =int (float (O000000000OOOO0O0 ))#line:343
						if OOOO00OOO0000O0O0 ==18 :#line:344
							OO0OOOO0OO0000OO0 =createMenu ('install','',OO00OO000OO000O00 )#line:345
							addDir ('[%s] %s (v%s)'%(float (O000000000OOOO0O0 ),OO00OO000OO000O00 ,O0OO00O0000O0OO0O ),'viewbuild',OO00OO000OO000O00 ,description =OO0OOOO0000OO0OOO ,fanart =OO0O0O0OO000OO000 ,icon =O00OO00OOO00OOO00 ,menu =OO0OOOO0OO0000OO0 ,themeit =THEME2 )#line:346
			if OOO0OO0000O0O000O >0 :#line:347
				O00OO0000OOOOO0OO ='+'if SHOW17 =='false'else '-'#line:348
				addFile ('[B]%s Krypton Builds(%s)[/B]'%(O00OO0000OOOOO0OO ,OOO0OO0000O0O000O ),'togglesetting','show17',themeit =THEME3 )#line:349
				if SHOW17 =='true':#line:350
					for OO00OO000OO000O00 ,O0OO00O0000O0OO0O ,OO0OOO00OOO0OO0OO ,OOO00OOOO00OOOOOO ,O0OO00OO00O000OO0 ,O00O0O0O0OO0OOO0O ,O000000000OOOO0O0 ,O0O000OO00OOO0O00 ,O00OO00OOO00OOO00 ,OO0O0O0OO000OO000 ,O0OO0OO0OO0O0O0O0 ,OO0OOOO0000OO0OOO ,O000O00OOO0O00OO0 in O00000OO0OO0OOO0O :#line:351
						if not SHOWADULT =='true'and O0OO0OO0OO0O0O0O0 .lower ()=='yes':continue #line:352
						if not DEVELOPER =='true'and wiz .strTest (OO00OO000OO000O00 ):continue #line:353
						OOOO00OOO0000O0O0 =int (float (O000000000OOOO0O0 ))#line:354
						if OOOO00OOO0000O0O0 ==17 :#line:355
							OO0OOOO0OO0000OO0 =createMenu ('install','',OO00OO000OO000O00 )#line:356
							addDir ('[%s] %s (v%s)'%(float (O000000000OOOO0O0 ),OO00OO000OO000O00 ,O0OO00O0000O0OO0O ),'viewbuild',OO00OO000OO000O00 ,description =OO0OOOO0000OO0OOO ,fanart =OO0O0O0OO000OO000 ,icon =O00OO00OOO00OOO00 ,menu =OO0OOOO0OO0000OO0 ,themeit =THEME2 )#line:357
			if O00O000O0OO00OOO0 >0 :#line:358
				O00OO0000OOOOO0OO ='+'if SHOW16 =='false'else '-'#line:359
				addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O00OO0000OOOOO0OO ,O00O000O0OO00OOO0 ),'togglesetting','show16',themeit =THEME3 )#line:360
				if SHOW16 =='true':#line:361
					for OO00OO000OO000O00 ,O0OO00O0000O0OO0O ,OO0OOO00OOO0OO0OO ,OOO00OOOO00OOOOOO ,O0OO00OO00O000OO0 ,O00O0O0O0OO0OOO0O ,O000000000OOOO0O0 ,O0O000OO00OOO0O00 ,O00OO00OOO00OOO00 ,OO0O0O0OO000OO000 ,O0OO0OO0OO0O0O0O0 ,OO0OOOO0000OO0OOO ,O000O00OOO0O00OO0 in O00000OO0OO0OOO0O :#line:362
						if not SHOWADULT =='true'and O0OO0OO0OO0O0O0O0 .lower ()=='yes':continue #line:363
						if not DEVELOPER =='true'and wiz .strTest (OO00OO000OO000O00 ):continue #line:364
						OOOO00OOO0000O0O0 =int (float (O000000000OOOO0O0 ))#line:365
						if OOOO00OOO0000O0O0 ==16 :#line:366
							OO0OOOO0OO0000OO0 =createMenu ('install','',OO00OO000OO000O00 )#line:367
							addDir ('[%s] %s (v%s)'%(float (O000000000OOOO0O0 ),OO00OO000OO000O00 ,O0OO00O0000O0OO0O ),'viewbuild',OO00OO000OO000O00 ,description =OO0OOOO0000OO0OOO ,fanart =OO0O0O0OO000OO000 ,icon =O00OO00OOO00OOO00 ,menu =OO0OOOO0OO0000OO0 ,themeit =THEME2 )#line:368
		else :#line:369
			if OO0O0O0OOO0OOO0OO =="Leia":#line:370
				O00OO0000OOOOO0OO ='+'if SHOW18 =='false'else '-'#line:371
				addFile ('[B]%s Leia Builds(%s)[/B]'%(O00OO0000OOOOO0OO ,OOOO0O000OOO0OOOO ),'togglesetting','show18',themeit =THEME3 )#line:372
				if SHOW18 =='true':#line:373
					for OO00OO000OO000O00 ,O0OO00O0000O0OO0O ,OO0OOO00OOO0OO0OO ,OOO00OOOO00OOOOOO ,O0OO00OO00O000OO0 ,O00O0O0O0OO0OOO0O ,O000000000OOOO0O0 ,O0O000OO00OOO0O00 ,O00OO00OOO00OOO00 ,OO0O0O0OO000OO000 ,O0OO0OO0OO0O0O0O0 ,OO0OOOO0000OO0OOO ,O000O00OOO0O00OO0 in O00000OO0OO0OOO0O :#line:374
						if not SHOWADULT =='true'and O0OO0OO0OO0O0O0O0 .lower ()=='yes':continue #line:375
						if not DEVELOPER =='true'and wiz .strTest (OO00OO000OO000O00 ):continue #line:376
						OOOO00OOO0000O0O0 =int (float (O000000000OOOO0O0 ))#line:377
						if OOOO00OOO0000O0O0 ==18 :#line:378
							OO0OOOO0OO0000OO0 =createMenu ('install','',OO00OO000OO000O00 )#line:379
							addDir ('[%s] %s (v%s)'%(float (O000000000OOOO0O0 ),OO00OO000OO000O00 ,O0OO00O0000O0OO0O ),'viewbuild',OO00OO000OO000O00 ,description =OO0OOOO0000OO0OOO ,fanart =OO0O0O0OO000OO000 ,icon =O00OO00OOO00OOO00 ,menu =OO0OOOO0OO0000OO0 ,themeit =THEME2 )#line:380
			elif OO0O0O0OOO0OOO0OO =="Krypton":#line:381
				O00OO0000OOOOO0OO ='+'if SHOW17 =='false'else '-'#line:382
				addFile ('[B]%s Krypton Builds(%s)[/B]'%(O00OO0000OOOOO0OO ,OOO0OO0000O0O000O ),'togglesetting','show17',themeit =THEME3 )#line:383
				if SHOW17 =='true':#line:384
					for OO00OO000OO000O00 ,O0OO00O0000O0OO0O ,OO0OOO00OOO0OO0OO ,OOO00OOOO00OOOOOO ,O0OO00OO00O000OO0 ,O00O0O0O0OO0OOO0O ,O000000000OOOO0O0 ,O0O000OO00OOO0O00 ,O00OO00OOO00OOO00 ,OO0O0O0OO000OO000 ,O0OO0OO0OO0O0O0O0 ,OO0OOOO0000OO0OOO ,O000O00OOO0O00OO0 in O00000OO0OO0OOO0O :#line:385
						if not SHOWADULT =='true'and O0OO0OO0OO0O0O0O0 .lower ()=='yes':continue #line:386
						if not DEVELOPER =='true'and wiz .strTest (OO00OO000OO000O00 ):continue #line:387
						OOOO00OOO0000O0O0 =int (float (O000000000OOOO0O0 ))#line:388
						if OOOO00OOO0000O0O0 ==17 :#line:389
							OO0OOOO0OO0000OO0 =createMenu ('install','',OO00OO000OO000O00 )#line:390
							addDir ('[%s] %s (v%s)'%(float (O000000000OOOO0O0 ),OO00OO000OO000O00 ,O0OO00O0000O0OO0O ),'viewbuild',OO00OO000OO000O00 ,description =OO0OOOO0000OO0OOO ,fanart =OO0O0O0OO000OO000 ,icon =O00OO00OOO00OOO00 ,menu =OO0OOOO0OO0000OO0 ,themeit =THEME2 )#line:391
			elif OO0O0O0OOO0OOO0OO =="Jarvis":#line:392
				O00OO0000OOOOO0OO ='+'if SHOW16 =='false'else '-'#line:393
				addFile ('[B]%s Jarvis Builds(%s)[/B]'%(O00OO0000OOOOO0OO ,O00O000O0OO00OOO0 ),'togglesetting','show16',themeit =THEME3 )#line:394
				if SHOW16 =='true':#line:395
					for OO00OO000OO000O00 ,O0OO00O0000O0OO0O ,OO0OOO00OOO0OO0OO ,OOO00OOOO00OOOOOO ,O0OO00OO00O000OO0 ,O00O0O0O0OO0OOO0O ,O000000000OOOO0O0 ,O0O000OO00OOO0O00 ,O00OO00OOO00OOO00 ,OO0O0O0OO000OO000 ,O0OO0OO0OO0O0O0O0 ,OO0OOOO0000OO0OOO ,O000O00OOO0O00OO0 in O00000OO0OO0OOO0O :#line:396
						if not SHOWADULT =='true'and O0OO0OO0OO0O0O0O0 .lower ()=='yes':continue #line:397
						if not DEVELOPER =='true'and wiz .strTest (OO00OO000OO000O00 ):continue #line:398
						OOOO00OOO0000O0O0 =int (float (O000000000OOOO0O0 ))#line:399
						if OOOO00OOO0000O0O0 ==16 :#line:400
							OO0OOOO0OO0000OO0 =createMenu ('install','',OO00OO000OO000O00 )#line:401
							addDir ('[%s] %s (v%s)'%(float (O000000000OOOO0O0 ),OO00OO000OO000O00 ,O0OO00O0000O0OO0O ),'viewbuild',OO00OO000OO000O00 ,description =OO0OOOO0000OO0OOO ,fanart =OO0O0O0OO000OO000 ,icon =O00OO00OOO00OOO00 ,menu =OO0OOOO0OO0000OO0 ,themeit =THEME2 )#line:402
	elif O00OO0OO0OO00000O >0 :#line:403
		if OOO0OO000000OO000 >0 :#line:404
			addFile ('There is currently only Adult builds','',icon =ICONBUILDS ,themeit =THEME3 )#line:405
			addFile ('Enable Show Adults in Addon Settings > Misc','',icon =ICONBUILDS ,themeit =THEME3 )#line:406
		else :#line:407
			addFile ('Currently No Builds Offered from %s'%ADDONTITLE ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:408
	else :addFile ('Text file for builds not formated correctly.','',icon =ICONBUILDS ,themeit =THEME3 )#line:409
	setView ('files','viewType')#line:410
def viewBuild (O0OO0O0OO0000OO00 ):#line:411
	O0O0O0OOOO00OOOO0 =wiz .textCache (BUILDFILE )#line:413
	if O0O0O0OOOO00OOOO0 ==False :#line:414
		OO000O0OOOOOOO00O =wiz .workingURL (BUILDFILE )#line:415
		addFile ('Url for txt file not valid','',themeit =THEME3 )#line:416
		addFile ('%s'%OO000O0OOOOOOO00O ,'',themeit =THEME3 )#line:417
		return #line:418
	if wiz .checkBuild (O0OO0O0OO0000OO00 ,'version')==False :#line:419
		addFile ('Error reading the txt file.','',themeit =THEME3 )#line:420
		addFile ('%s was not found in the builds list.'%O0OO0O0OO0000OO00 ,'',themeit =THEME3 )#line:421
		return #line:422
	O0000OOO00OO00O0O =O0O0O0OOOO00OOOO0 .replace ('\n','').replace ('\r','').replace ('\t','').replace ('gui=""','gui="http://"').replace ('theme=""','theme="http://"').replace ('url2=""','url2="http://"').replace ('url3=""','url3="http://"').replace ('preview=""','preview="http://"').replace ('"https://"','preview="http://"')#line:423
	OO00OO0O0O000O0OO =re .compile ('name="%s".+?ersion="(.+?)".+?rl="(.+?)".+?rl2="(.+?)".+?rl3="(.+?)".+?ui="(.+?)".+?odi="(.+?)".+?heme="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)".+?review="(.+?)"'%O0OO0O0OO0000OO00 ).findall (O0000OOO00OO00O0O )#line:424
	for OOOOO00O00OOOO0OO ,OO0O00000OOO0OO0O ,OOO0OO0O0O00OOOO0 ,O00O00OOO0O00O000 ,O000OOOOOO00O0O00 ,O00O0O0O0OOO00OO0 ,O0OOO000O00OO0OO0 ,OOOOOOO00OO0OOO00 ,O000OOOO00OO00O0O ,O0OOOO0O0OOOOO0O0 ,O00OO0OOOO00000OO ,OOO0OO000OO00O00O in OO00OO0O0O000O0OO :#line:425
		OOOOOOO00OO0OOO00 =OOOOOOO00OO0OOO00 #line:426
		O000OOOO00OO00O0O =O000OOOO00OO00O0O #line:427
		OOO0OO000OO000OO0 ='%s (v%s)'%(O0OO0O0OO0000OO00 ,OOOOO00O00OOOO0OO )#line:428
		if BUILDNAME ==O0OO0O0OO0000OO00 and OOOOO00O00OOOO0OO >BUILDVERSION :#line:429
			OOO0OO000OO000OO0 ='%s [COLOR red][CURRENT v%s][/COLOR]'%(OOO0OO000OO000OO0 ,BUILDVERSION )#line:430
		addFile (OOO0OO000OO000OO0 ,'',description =O00OO0OOOO00000OO ,fanart =O000OOOO00OO00O0O ,icon =OOOOOOO00OO0OOO00 ,themeit =THEME4 )#line:431
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:432
		addDir ('Save Data Menu','savedata',icon =ICONSAVE ,themeit =THEME3 )#line:433
		addFile ('Build Information','buildinfo',O0OO0O0OO0000OO00 ,description =O00OO0OOOO00000OO ,fanart =O000OOOO00OO00O0O ,icon =OOOOOOO00OO0OOO00 ,themeit =THEME3 )#line:434
		if not OOO0OO000OO00O00O =="http://":addFile ('View Video Preview','buildpreview',O0OO0O0OO0000OO00 ,description =O00OO0OOOO00000OO ,fanart =O000OOOO00OO00O0O ,icon =OOOOOOO00OO0OOO00 ,themeit =THEME3 )#line:435
		OO0000000O00000O0 =int (float (KODIV ));O00OOO0O0O000OOOO =int (float (O00O0O0O0OOO00OO0 ))#line:436
		if not OO0000000O00000O0 ==O00OOO0O0O000OOOO :#line:437
			if OO0000000O00000O0 ==16 and O00OOO0O0O000OOOO <=15 :OOOOOOOOOOO0000OO =False #line:438
			else :OOOOOOOOOOO0000OO =True #line:439
		else :OOOOOOOOOOO0000OO =False #line:440
		if OOOOOOOOOOO0000OO ==True :#line:441
			addFile ('BUILD DESIGNED FOR KODI VERSION %s [COLOR yellow](INSTALLED: %s)[/COLOR]'%(str (O00O0O0O0OOO00OO0 ),str (KODIV )),'',fanart =O000OOOO00OO00O0O ,icon =OOOOOOO00OO0OOO00 ,themeit =THEME6 )#line:442
		addFile (wiz .sep ('INSTALL'),'',fanart =O000OOOO00OO00O0O ,icon =OOOOOOO00OO0OOO00 ,themeit =THEME3 )#line:443
		addFile ('Fresh Start then Install','install',O0OO0O0OO0000OO00 ,'fresh',description =O00OO0OOOO00000OO ,fanart =O000OOOO00OO00O0O ,icon =OOOOOOO00OO0OOO00 ,themeit =THEME1 )#line:444
		addFile ('Standard Install','install',O0OO0O0OO0000OO00 ,'normal',description =O00OO0OOOO00000OO ,fanart =O000OOOO00OO00O0O ,icon =OOOOOOO00OO0OOO00 ,themeit =THEME1 )#line:445
		if not O000OOOOOO00O0O00 =='http://':addFile ('עדכון מהיר','install',O0OO0O0OO0000OO00 ,'gui',description =O00OO0OOOO00000OO ,fanart =O000OOOO00OO00O0O ,icon =OOOOOOO00OO0OOO00 ,themeit =THEME1 )#line:446
		if not O0OOO000O00OO0OO0 =='http://':#line:447
			OO0O0OOO0O000OO0O =wiz .textCache (O0OOO000O00OO0OO0 )#line:448
			if not OO0O0OOO0O000OO0O ==False :#line:449
				addFile (wiz .sep ('THEMES'),'',fanart =O000OOOO00OO00O0O ,icon =OOOOOOO00OO0OOO00 ,themeit =THEME3 )#line:450
				O0000OOO00OO00O0O =OO0O0OOO0O000OO0O .replace ('\n','').replace ('\r','').replace ('\t','')#line:451
				OO00OO0O0O000O0OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (O0000OOO00OO00O0O )#line:452
				for O0OO0O000OOOO000O ,OOO0O0000OO0O0000 ,OOOO0O0O0O0O00000 ,OO00000OO0OO00OOO ,O00OO0OOOO00000OO in OO00OO0O0O000O0OO :#line:453
					OOOO0O0O0O0O00000 =OOOO0O0O0O0O00000 if OOOO0O0O0O0O00000 =='http://'else OOOOOOO00OO0OOO00 #line:454
					OO00000OO0OO00OOO =OO00000OO0OO00OOO if OO00000OO0OO00OOO =='http://'else O000OOOO00OO00O0O #line:455
					addFile (O0OO0O000OOOO000O if not O0OO0O000OOOO000O ==BUILDTHEME else "[B]%s (Installed)[/B]"%O0OO0O000OOOO000O ,'theme',O0OO0O0OO0000OO00 ,O0OO0O000OOOO000O ,description =O00OO0OOOO00000OO ,fanart =OO00000OO0OO00OOO ,icon =OOOO0O0O0O0O00000 ,themeit =THEME3 )#line:456
	setView ('files','viewType')#line:457
def viewThirdList (OO00O00OOO00OOOO0 ):#line:458
	O000O0OOOO00OOO0O =eval ('THIRD%sNAME'%OO00O00OOO00OOOO0 )#line:459
	OO00O0OOO00OOOO0O =eval ('THIRD%sURL'%OO00O00OOO00OOOO0 )#line:460
	OO00OO00O0O0O000O =wiz .workingURL (OO00O0OOO00OOOO0O )#line:461
	if not OO00OO00O0O0O000O ==True :#line:462
		addFile ('Url for txt file not valid','',icon =ICONBUILDS ,themeit =THEME3 )#line:463
		addFile ('%s'%WORKINGURL ,'',icon =ICONBUILDS ,themeit =THEME3 )#line:464
	else :#line:465
		OO0O00000000OOOOO ,O00O0OOOOO0000O0O =wiz .thirdParty (OO00O0OOO00OOOO0O )#line:466
		addFile ("[B]%s[/B]"%O000O0OOOO00OOO0O ,'',themeit =THEME3 )#line:467
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:468
		if OO0O00000000OOOOO :#line:469
			for O000O0OOOO00OOO0O ,O0O0000O000O0O00O ,OO00O0OOO00OOOO0O ,O0OO0O0OOO00O000O ,O0000OO000OOO0O00 ,O00O0O0O0O0OO00O0 ,O0O000OO00O0O0O00 ,OOO0OO00OOO0O00O0 in O00O0OOOOO0000O0O :#line:470
				if not SHOWADULT =='true'and O0O000OO00O0O0O00 .lower ()=='yes':continue #line:471
				addFile ("[%s] %s v%s"%(O0OO0O0OOO00O000O ,O000O0OOOO00OOO0O ,O0O0000O000O0O00O ),'installthird',O000O0OOOO00OOO0O ,OO00O0OOO00OOOO0O ,icon =O0000OO000OOO0O00 ,fanart =O00O0O0O0O0OO00O0 ,description =OOO0OO00OOO0O00O0 ,themeit =THEME2 )#line:472
		else :#line:473
			for O000O0OOOO00OOO0O ,OO00O0OOO00OOOO0O ,O0000OO000OOO0O00 ,O00O0O0O0O0OO00O0 ,OOO0OO00OOO0O00O0 in O00O0OOOOO0000O0O :#line:474
				addFile (O000O0OOOO00OOO0O ,'installthird',O000O0OOOO00OOO0O ,OO00O0OOO00OOOO0O ,icon =O0000OO000OOO0O00 ,fanart =O00O0O0O0O0OO00O0 ,description =OOO0OO00OOO0O00O0 ,themeit =THEME2 )#line:475
def editThirdParty (O00000O000000O0OO ):#line:476
	OOOO0000OO0O0O000 =eval ('THIRD%sNAME'%O00000O000000O0OO )#line:477
	O0O0OO0O000O000O0 =eval ('THIRD%sURL'%O00000O000000O0OO )#line:478
	O00000O0O0O0OOO00 =wiz .getKeyboard (OOOO0000OO0O0O000 ,'Enter the Name of the Wizard')#line:479
	O0OO0OO0O0OOOO0O0 =wiz .getKeyboard (O0O0OO0O000O000O0 ,'Enter the URL of the Wizard Text')#line:480
	wiz .setS ('wizard%sname'%O00000O000000O0OO ,O00000O0O0O0OOO00 )#line:481
	wiz .setS ('wizard%surl'%O00000O000000O0OO ,O0OO0OO0O0OOOO0O0 )#line:482
def apkScraper (name =""):#line:483
	if name =='kodi':#line:484
		OOO000OOO00O0O000 ='http://mirrors.kodi.tv/releases/android/arm/'#line:485
		OOO00OO0O0O0OO00O ='http://mirrors.kodi.tv/releases/android/arm/old/'#line:486
		O00O00O00O0OOO0OO =wiz .openURL (OOO000OOO00O0O000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:487
		OOOOOO0O000OO0O00 =wiz .openURL (OOO00OO0O0O0OO00O ).replace ('\n','').replace ('\r','').replace ('\t','')#line:488
		OO000OOO0OO0O00O0 =0 #line:489
		OO000O0O00O00OOOO =re .compile ('<tr><td><a href="(.+?)".+?>(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (O00O00O00O0OOO0OO )#line:490
		OO0OO0O000O0OOO00 =re .compile ('<tr><td><a href="(.+?)".+?>(.+?)</a></td><td>(.+?)</td><td>(.+?)</td></tr>').findall (OOOOOO0O000OO0O00 )#line:491
		addFile ("Official Kodi Apk\'s",themeit =THEME1 )#line:492
		OO00O0000OOOOOO00 =False #line:493
		for OO00O00O0OO000OOO ,name ,OO000000OO00OOOO0 ,O0O00O0OOOOOO00OO in OO000O0O00O00OOOO :#line:494
			if OO00O00O0OO000OOO in ['../','old/']:continue #line:495
			if not OO00O00O0OO000OOO .endswith ('.apk'):continue #line:496
			if not OO00O00O0OO000OOO .find ('_')==-1 and OO00O0000OOOOOO00 ==True :continue #line:497
			try :#line:498
				O00O0OOO0O0OO0O0O =name .split ('-')#line:499
				if not OO00O00O0OO000OOO .find ('_')==-1 :#line:500
					OO00O0000OOOOOO00 =True #line:501
					OOOO00O000OO0O00O ,O0OOO00O0O0O0OOOO =O00O0OOO0O0OO0O0O [2 ].split ('_')#line:502
				else :#line:503
					OOOO00O000OO0O00O =O00O0OOO0O0OO0O0O [2 ]#line:504
					O0OOO00O0O0O0OOOO =''#line:505
				O0OOOOOO00OO0OOO0 ="[COLOR %s]%s v%s%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0OOO0O0OO0O0O [0 ].title (),O00O0OOO0O0OO0O0O [1 ],O0OOO00O0O0O0OOOO .upper (),OOOO00O000OO0O00O ,COLOR2 ,OO000000OO00OOOO0 .replace (' ',''),COLOR1 ,O0O00O0OOOOOO00OO )#line:506
				OO0OO00OO000O0OOO =urljoin (OOO000OOO00O0O000 ,OO00O00O0OO000OOO )#line:507
				addFile (O0OOOOOO00OO0OOO0 ,'apkinstall',"%s v%s%s %s"%(O00O0OOO0O0OO0O0O [0 ].title (),O00O0OOO0O0OO0O0O [1 ],O0OOO00O0O0O0OOOO .upper (),OOOO00O000OO0O00O ),OO0OO00OO000O0OOO )#line:508
				OO000OOO0OO0O00O0 +=1 #line:509
			except :#line:510
				wiz .log ("Error on: %s"%name )#line:511
		for OO00O00O0OO000OOO ,name ,OO000000OO00OOOO0 ,O0O00O0OOOOOO00OO in OO0OO0O000O0OOO00 :#line:512
			if OO00O00O0OO000OOO in ['../','old/']:continue #line:513
			if not OO00O00O0OO000OOO .endswith ('.apk'):continue #line:514
			if not OO00O00O0OO000OOO .find ('_')==-1 :continue #line:515
			try :#line:516
				O00O0OOO0O0OO0O0O =name .split ('-')#line:517
				O0OOOOOO00OO0OOO0 ="[COLOR %s]%s v%s %s[/COLOR] [COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,O00O0OOO0O0OO0O0O [0 ].title (),O00O0OOO0O0OO0O0O [1 ],O00O0OOO0O0OO0O0O [2 ],COLOR2 ,OO000000OO00OOOO0 .replace (' ',''),COLOR1 ,O0O00O0OOOOOO00OO )#line:518
				OO0OO00OO000O0OOO =urljoin (OOO00OO0O0O0OO00O ,OO00O00O0OO000OOO )#line:519
				addFile (O0OOOOOO00OO0OOO0 ,'apkinstall',"%s v%s %s"%(O00O0OOO0O0OO0O0O [0 ].title (),O00O0OOO0O0OO0O0O [1 ],O00O0OOO0O0OO0O0O [2 ]),OO0OO00OO000O0OOO )#line:520
				OO000OOO0OO0O00O0 +=1 #line:521
			except :#line:522
				wiz .log ("Error on: %s"%name )#line:523
		if OO000OOO0OO0O00O0 ==0 :addFile ("Error Kodi Scraper Is Currently Down.")#line:524
	elif name =='spmc':#line:525
		OOO000OO000OOO000 ='https://github.com/koying/SPMC/releases'#line:526
		O00O00O00O0OOO0OO =wiz .openURL (OOO000OO000OOO000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:527
		OO000OOO0OO0O00O0 =0 #line:528
		OO000O0O00O00OOOO =re .compile ('<div.+?lass="release-body.+?div class="release-header".+?a href=.+?>(.+?)</a>.+?ul class="release-downloads">(.+?)</ul>.+?/div>').findall (O00O00O00O0OOO0OO )#line:529
		addFile ("Official SPMC Apk\'s",themeit =THEME1 )#line:530
		for name ,O0000OO0OO0OO00O0 in OO000O0O00O00OOOO :#line:531
			O00OOOOO0O0O00OOO =''#line:532
			OO0OO0O000O0OOO00 =re .compile ('<li>.+?<a href="(.+?)" rel="nofollow">.+?<small class="text-gray float-right">(.+?)</small>.+?strong>(.+?)</strong>.+?</a>.+?</li>').findall (O0000OO0OO0OO00O0 )#line:533
			for OOOO0O0O0000O0O00 ,OO00O0O0OO0OO00OO ,OOOO0000O0OOO0O0O in OO0OO0O000O0OOO00 :#line:534
				if OOOO0000O0OOO0O0O .find ('armeabi')==-1 :continue #line:535
				if OOOO0000O0OOO0O0O .find ('launcher')>-1 :continue #line:536
				O00OOOOO0O0O00OOO =urljoin ('https://github.com',OOOO0O0O0000O0O00 )#line:537
				break #line:538
			if O00OOOOO0O0O00OOO =='':continue #line:539
			try :#line:540
				name ="SPMC %s"%name #line:541
				O0OOOOOO00OO0OOO0 ="[COLOR %s]%s[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR1 ,name ,COLOR2 ,OO00O0O0OO0OO00OO .replace (' ',''))#line:542
				OO0OO00OO000O0OOO =O00OOOOO0O0O00OOO #line:543
				addFile (O0OOOOOO00OO0OOO0 ,'apkinstall',name ,OO0OO00OO000O0OOO )#line:544
				OO000OOO0OO0O00O0 =OO000OOO0OO0O00O0 +1 #line:545
			except Exception as O000OOOO0O00OOOOO :#line:546
				wiz .log ("Error on: %s / %s"%(name ,str (O000OOOO0O00OOOOO )))#line:547
		if OO000OOO0OO0O00O0 ==0 :addFile ("Error SPMC Scraper Is Currently Down.")#line:548
def apkMenu (name =None ,url =None ):#line:549
	if HIDESPACERS =='No':addFile (wiz .sep ('Apps from apkfiles.com'),'',themeit =THEME3 )#line:550
	addDir ('App Lists','apkfiles',icon =ICONSAVE ,themeit =THEME1 )#line:551
	if HIDESPACERS =='No':addFile (wiz .sep ('FTG Modded Apps'),'',themeit =THEME3 )#line:552
	addDir ('App Lists','ftgmod',icon =ICONSAVE ,themeit =THEME1 )#line:553
	setView ('files','viewType')#line:554
	if url ==None :#line:555
		if HIDESPACERS =='No':addFile (wiz .sep ('Official Kodi/SPMC'),'',themeit =THEME3 )#line:556
		addDir ('Kodi Apk\'s','apkscrape','kodi',icon =ICONAPK ,themeit =THEME1 )#line:557
		addDir ('SPMC Apk\'s','apkscrape','spmc',icon =ICONAPK ,themeit =THEME1 )#line:558
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:559
	if not APKFILE =='http://':#line:560
		if url ==None :#line:561
			OO0OO0OO00O0O0O0O =wiz .textCache (uservar .APKFILE )#line:562
			if OO0OO0OO00O0O0O0O ==False :O0OOOOOOO0OO0000O =wiz .workingURL (uservar .APKFILE )#line:563
		else :#line:564
			OO0OO0OO00O0O0O0O =wiz .textCache (url )#line:565
			if OO0OO0OO00O0O0O0O ==False :O0OOOOOOO0OO0000O =wiz .workingURL (url )#line:566
		if not OO0OO0OO00O0O0O0O ==False :#line:567
			OOOO0O00O000OOO00 =OO0OO0OO00O0O0O0O .replace ('\n','').replace ('\r','').replace ('\t','')#line:568
			OO00OOOO00OOOO0OO =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (OOOO0O00O000OOO00 )#line:569
			if len (OO00OOOO00OOOO0OO )>0 :#line:570
				OOOOOOO000OOO00O0 =0 #line:571
				for OO000OO0OO000O0O0 ,OOOOO0O0O00O0OOO0 ,url ,OOO00O0O00000O0OO ,OO0OOO0OOO00O0O0O ,OOO000OO0000OO0OO ,O0O0OO0O0OO0OO000 in OO00OOOO00OOOO0OO :#line:572
					if not SHOWADULT =='true'and OOO000OO0000OO0OO .lower ()=='yes':continue #line:573
					if OOOOO0O0O00O0OOO0 .lower ()=='yes':#line:574
						OOOOOOO000OOO00O0 +=1 #line:575
						addDir ("[B]%s[/B]"%OO000OO0OO000O0O0 ,'apk',OO000OO0OO000O0O0 ,url ,description =O0O0OO0O0OO0OO000 ,icon =OOO00O0O00000O0OO ,fanart =OO0OOO0OOO00O0O0O ,themeit =THEME3 )#line:576
					elif OOOOO0O0O00O0OOO0 .lower ()=='yes':#line:577
						OOOOOOO000OOO00O0 +=1 #line:578
						addFile (OO000OO0OO000O0O0 ,'rominstall',OO000OO0OO000O0O0 ,url ,description =O0O0OO0O0OO0OO000 ,icon =OOO00O0O00000O0OO ,fanart =OO0OOO0OOO00O0O0O ,themeit =THEME2 )#line:579
					else :#line:580
						OOOOOOO000OOO00O0 +=1 #line:581
						addFile (OO000OO0OO000O0O0 ,'apkinstall',OO000OO0OO000O0O0 ,url ,description =O0O0OO0O0OO0OO000 ,icon =OOO00O0O00000O0OO ,fanart =OO0OOO0OOO00O0O0O ,themeit =THEME2 )#line:582
					if OOOOOOO000OOO00O0 ==0 :#line:583
						addFile ("No addons added to this menu yet!",'',themeit =THEME2 )#line:584
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.",xbmc .LOGERROR )#line:585
		else :#line:586
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:587
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:588
			addFile ('%s'%O0OOOOOOO0OO0000O ,'',themeit =THEME3 )#line:589
		return #line:590
	else :wiz .log ("[APK Menu] No APK list added.")#line:591
	setView ('files','viewType')#line:592
def ftgmod ():#line:593
	if not APKFILE =='http://':#line:594
		OO00000OO0OO0O000 =wiz .workingURL (APKFILE )#line:595
		if OO00000OO0OO0O000 ==True :#line:596
			OO0000OOO00000O0O =wiz .openURL (APKFILE ).replace ('\n','').replace ('\r','').replace ('\t','')#line:597
			OOOOOOO0O0000O0OO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (OO0000OOO00000O0O )#line:598
			if len (OOOOOOO0O0000O0OO )>0 :#line:599
				for OO0O0OO00OO0O0O00 ,O00O0O000OOO00OOO ,O0OO0OO0O0O0O00O0 ,O0O00000OOO0000OO in OOOOOOO0O0000O0OO :#line:600
					addDir (OO0O0OO00OO0O0O00 ,'GetList',OO0O0OO00OO0O0O00 ,O00O0O000OOO00OOO ,icon =O0OO0OO0O0O0O00O0 ,fanart =O0O00000OOO0000OO ,themeit =THEME1 )#line:602
			else :wiz .log ("[APK Menu] ERROR: Invalid Format.")#line:603
		else :#line:604
			wiz .log ("[APK Menu] ERROR: URL for apk list not working.",xbmc .LOGERROR )#line:605
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:606
			addFile ('%s'%OO00000OO0OO0O000 ,'',themeit =THEME3 )#line:607
		return #line:608
	else :wiz .log ("[APK Menu] No APK list added.")#line:609
def GetList (OOO0OOO0OO00O0000 ):#line:610
	if not wiz .workingURL (OOO0OOO0OO00O0000 )==True :return False #line:611
	O0O000OO0O000O00O =wiz .openURL (OOO0OOO0OO00O0000 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:612
	OOO0OO0OO00O00OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O0O000OO0O000O00O )#line:613
	if len (OOO0OO0OO00O00OO0 )>0 :#line:614
		for O0O0OOOOO0OO0O000 ,OOO0OOO0OO00O0000 ,O0O0000O0O0OO0OO0 ,O000000000O00OO00 in OOO0OO0OO00O00OO0 :#line:615
			addFile (O0O0OOOOO0OO0O000 ,'apkinstall',O0O0OOOOO0OO0O000 ,OOO0OOO0OO00O0000 ,icon =O0O0000O0O0OO0OO0 ,fanart =O000000000O00OO00 ,themeit =THEME1 )#line:616
		else :wiz .log ("[APK Menu] ERROR: Invalid Format.")#line:617
	else :wiz .log ("[APK Menu] ERROR: URL for emu list not working.")#line:618
def apkfiles ():#line:619
	if HIDESPACERS =='No':addFile (wiz .sep ('Apps from apkfiles.com'),'',themeit =THEME3 )#line:620
	O00O00OO0OOO00O0O =wiz .openURL ('https://www.apkfiles.com/')#line:621
	OOO00O00O0OO00OOO =re .compile ('href="([^"]*)">Applications(.+?)</a>').findall (O00O00OO0OOO00O0O )#line:622
	O0000OOO0000OO0O0 =re .compile ('href="([^"]*)">Games(.+?)</a>').findall (O00O00OO0OOO00O0O )#line:623
	for O000O0O0OOOOO0O00 ,OO0OOOOO0000O0O00 in OOO00O00O0OO00OOO :#line:624
		addDir2 ('[COLOR blue]Android Apps[/COLOR]','https://www.apkfiles.com'+O000O0O0OOOOO0O00 ,'apkgame',ICONAPK ,FANART )#line:625
	for O000O0O0OOOOO0O00 ,OO0OOOOO0000O0O00 in O0000OOO0000OO0O0 :#line:626
		addDir2 ('[COLOR blue]Android Games[/COLOR]','https://www.apkfiles.com'+O000O0O0OOOOO0O00 ,'apkgame',ICONAPK ,FANART )#line:627
	setView ('movies','MAIN')#line:628
def apkshowMenu (O00OO0O000OO0O0O0 ):#line:629
	if not wiz .workingURL (O00OO0O000OO0O0O0 )==True :return False #line:630
	OO0OO0O00OO000O00 =wiz .openURL (O00OO0O000OO0O0O0 ).replace ('\n','').replace ('\r','').replace ('\t','')#line:631
	O00OOOOOO0OO00OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (OO0OO0O00OO000O00 )#line:632
	if len (O00OOOOOO0OO00OOO )>0 :#line:633
		for OOOO000O0OOO0O0O0 ,O00OO0O000OO0O0O0 ,OO00OO0OO0OO0O0OO ,OOOOO00000O0OO000 in O00OOOOOO0OO00OOO :#line:634
			addFile (OOOO000O0OOO0O0O0 ,'apkinstall',OOOO000O0OOO0O0O0 ,O00OO0O000OO0O0O0 ,icon =OO00OO0OO0OO0O0OO ,fanart =OOOOO00000O0OO000 ,themeit =THEME1 )#line:635
		else :wiz .log ("[APK Menu] ERROR: Invalid Format.")#line:636
	else :wiz .log ("[APK Menu] ERROR: URL for emu list not working.")#line:637
def APKGAME (O000OO00O000O000O ):#line:638
	O00OO00O00O0OO0OO =wiz .openURL (O000OO00O000O000O )#line:639
	OOOOO000OOO000000 =re .compile ('<a href="([^"]*)" >(.+?)</a>').findall (O00OO00O00O0OO0OO )#line:640
	for O000OO00O000O000O ,OO00O0OO0OO0O0OO0 in OOOOO000OOO000000 :#line:641
		if '/cat'in O000OO00O000O000O :#line:642
			addDir2 ((OO00O0OO0OO0O0OO0 ).replace ('&amp;',' - '),'https://www.apkfiles.com'+O000OO00O000O000O ,'select',ART +'APK.png',FANART )#line:643
def APKSELECT2 (O000O0O00OO00O0OO ):#line:644
	O0O0OOO0O000OO0OO =wiz .openURL (O000O0O00OO00O0OO )#line:645
	O0OO000OO000OOO0O =O000O0O00OO00O0OO #line:646
	if "page="in str (O000O0O00OO00O0OO ):#line:647
		O0OO000OO000OOO0O =O000O0O00OO00O0OO .split ('?')[0 ]#line:648
	O0O0O0OO000O0000O =re .compile ('<a href="([^"]*)".+?<img src="([^"]*)" class="file_list_icon".+?alt="([^"]*)"',re .DOTALL ).findall (O0O0OOO0O000OO0OO )#line:649
	OO0OOOOO0OO00O000 =re .compile ('class="[^"]*".+?ref="([^"]*)".+?yle=.+?</a>').findall (O0O0OOO0O000OO0OO )#line:650
	for O000O0O00OO00O0OO ,O0O00O0OOOOO0OOO0 ,O0OO0OO000O00OO00 in O0O0O0OO000O0000O :#line:651
		if 'apk'in O000O0O00OO00O0OO :#line:652
			addDir2 ((O0OO0OO000O00OO00 ).replace ('&#39;','').replace ('&amp;',' - ').replace ('&#174;:',': ').replace ('&#174;',' '),'https://www.apkfiles.com'+O000O0O00OO00O0OO ,'grab','http:'+O0O00O0OOOOO0OOO0 ,FANART )#line:653
	if len (OO0OOOOO0OO00O000 )>1 :#line:654
		OO0OOOOO0OO00O000 =str (OO0OOOOO0OO00O000 [len (OO0OOOOO0OO00O000 )-1 ])#line:655
	addDir2 ('Next Page',O0OO000OO000OOO0O +str (OO0OOOOO0OO00O000 ),'select',ART +'Next.png',FANART )#line:656
def APKGRAB (OOO00O0O0OOOO00OO ,O00OOOOO0000OO0O0 ):#line:657
	O0OOO0000OO0OO0OO =wiz .openURL (O00OOOOO0000OO0O0 )#line:658
	OOO00O0O0OOOO00OO =OOO00O0O0OOOO00OO #line:659
	OOOO0O0000OO00OO0 =re .compile ('href="([^"]*)".+?lass="yellow_button".+?itle=').findall (O0OOO0000OO0OO0OO )#line:660
	for O00OOOOO0000OO0O0 in OOOO0O0000OO00OO0 :#line:661
		O00OOOOO0000OO0O0 ='https://www.apkfiles.com'+O00OOOOO0000OO0O0 #line:662
		apkInstaller1 (OOO00O0O0OOOO00OO ,O00OOOOO0000OO0O0 )#line:663
def retromenu ():#line:666
	MKDIRS ()#line:667
	if HIDESPACERS =='No':addFile (wiz .sep ('Emulators'),'',themeit =THEME3 )#line:668
	if wiz .platform ()=='android'or DEVELOPER =='true':addDir ('Emulator APKs','emumenu',icon =ICONSAVE ,themeit =THEME1 )#line:669
	if wiz .platform ()=='windows'or DEVELOPER =='true':addDir ('Emulator APPs','emumenu',icon =ICONSAVE ,themeit =THEME1 )#line:670
	if HIDESPACERS =='No':addFile (wiz .sep ('Rom Packs'),'',themeit =THEME3 )#line:671
	addDir ('Rom Pack Zips','rompackmenu',icon =ICONSAVE ,themeit =THEME1 )#line:672
def emumenu ():#line:673
	O0O0O0O00000OO00O =wiz .openURL (EMUAPKS ).replace ('\n','').replace ('\r','').replace ('\t','')#line:674
	O0OOOOOOO00O00OO0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O0O0O0O00000OO00O )#line:675
	if len (O0OOOOOOO00O00OO0 )>0 :#line:676
		if wiz .platform ()=='android':#line:677
			for O0O00OOOO0000O00O ,OO00OO0OO0OOO000O ,O0O000OO0OOO0O0O0 ,OO0OO000O00OOOO00 in O0OOOOOOO00O00OO0 :#line:678
				addFile (O0O00OOOO0000O00O ,'apkinstall',O0O00OOOO0000O00O ,OO00OO0OO0OOO000O ,icon =O0O000OO0OOO0O0O0 ,fanart =OO0OO000O00OOOO00 ,themeit =THEME1 )#line:679
		elif wiz .platform ()=='windows':#line:680
			DIALOG .ok (ADDONTITLE ,"[COLOR yellow]Please go download RetroArch for PC[/COLOR]"," Goto http://tinyurl.com/RetroFTG for a full tutorial")#line:681
		elif wiz .platform ()=='linux':#line:682
			DIALOG .ok (ADDONTITLE ,"[COLOR yellow]Please go download RetroArch for PC[/COLOR]"," Goto http://tinyurl.com/RetroFTG for a full tutorial")#line:683
def rompackmenu ():#line:684
	O0OOO0OOO0OOO0OOO =wiz .openURL (ROMPACK ).replace ('\n','').replace ('\r','').replace ('\t','')#line:685
	OOO0O0O00OOO00OOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)"').findall (O0OOO0OOO0OOO0OOO )#line:686
	if len (OOO0O0O00OOO00OOO )>0 :#line:687
		for O000OO0OO0O0O0OO0 ,O0OO00OO00OO0O000 ,OOOO0O0000OOOO000 ,OO0000O0O0OOOO0O0 in OOO0O0O00OOO00OOO :#line:688
			addFile (O000OO0OO0O0O0OO0 ,'UNZIPROM',O000OO0OO0O0O0OO0 ,O0OO00OO00OO0O000 ,icon =OOOO0O0000OOOO000 ,fanart =OO0000O0O0OOOO0O0 ,themeit =THEME1 )#line:689
def UNZIPROM ():#line:690
	O00OO0000O0OOO000 =xbmc .translatePath (BACKUPROMS )#line:691
	if O00OO0000O0OOO000 =='':#line:692
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that you do not have an extract location setup for Rom Packs"%COLOR2 ,"Would you like to set one?[/COLOR]",yeslabel ="[COLOR green][B]Set Location[/B][/COLOR]",nolabel ="[COLOR red][B]Cancel Download[/B][/COLOR]"):#line:693
			wiz .openS ('rompath')#line:694
			O00OO0000O0OOO000 =wiz .getS ('rompath')#line:695
			if O00OO0000O0OOO000 =='':return #line:696
	O0OO00OO00OO0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you would like to download and extract [COLOR %s]%s[/COLOR] to:"%(COLOR2 ,COLOR1 ,name ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,O00OO0000O0OOO000 ),yeslabel ="[B][COLOR green]Download[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:697
	if not O0OO00OO00OO0OOOO :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:698
	OOO0OOOOO000O00O0 =name #line:699
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:700
	if not wiz .workingURL (url )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Rom Installer: Invalid Rom Url![/COLOR]'%COLOR2 );return #line:701
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OOOOO000O00O0 ),'','Please Wait')#line:702
	OOO0O000OO0O0O00O =os .path .join (PACKAGES ,"%s.zip"%name .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:703
	try :os .remove (OOO0O000OO0O0O00O )#line:704
	except :pass #line:705
	downloader .download (url ,OOO0O000OO0O0O00O ,DP )#line:706
	xbmc .sleep (100 )#line:707
	OO0O0O0O0O00O000O ,O0O000OO0O0O0000O ,OOO0000O0OO00000O =extract .all (OOO0O000OO0O0O00O ,O00OO0000O0OOO000 ,DP ,title =OOO0OOOOO000O00O0 )#line:708
	try :os .remove (OOO0O000OO0O0O00O )#line:709
	except :pass #line:710
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Rom Pack Installed[/COLOR]'%COLOR2 )#line:711
	DP .close ()#line:712
def MKDIRS ():#line:713
	if not os .path .exists (ROMLOC ):os .makedirs (ROMLOC )#line:714
def buildVideo (OOO00OO0O0000000O ):#line:718
	if wiz .workingURL (BUILDFILE )==True :#line:719
		OO0OO0O00OO00000O =wiz .checkBuild (OOO00OO0O0000000O ,'preview')#line:720
		wiz .FTGlog ('Name %s'%OOO00OO0O0000000O )#line:721
		wiz .FTGlog ('URL %s'%OO0OO0O00OO00000O )#line:722
		if OO0OO0O00OO00000O and not OO0OO0O00OO00000O =='http://':playVideoB (OO0OO0O00OO00000O )#line:723
		else :wiz .log ("[%s]Unable to find url for video preview"%OOO00OO0O0000000O )#line:724
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:725
def playVideo (OOO000O0OOO00O000 ):#line:728
	if 'watch?v='in OOO000O0OOO00O000 :#line:729
		O00OOO000OOOOOO0O ,O000O00OO0OOO0OO0 =OOO000O0OOO00O000 .split ('?')#line:730
		OO0O00O0O0O00000O =O000O00OO0OOO0OO0 .split ('&')#line:731
		for O0OOOO00OO00OOO0O in OO0O00O0O0O00000O :#line:732
			if O0OOOO00OO00OOO0O .startswith ('v='):#line:733
				OOO000O0OOO00O000 =O0OOOO00OO00OOO0O [2 :]#line:734
				break #line:735
			else :continue #line:736
	elif 'embed'in OOO000O0OOO00O000 or 'youtu.be'in OOO000O0OOO00O000 :#line:737
		O00OOO000OOOOOO0O =OOO000O0OOO00O000 .split ('/')#line:738
		if len (O00OOO000OOOOOO0O [-1 ])>5 :#line:739
			OOO000O0OOO00O000 =O00OOO000OOOOOO0O [-1 ]#line:740
		elif len (O00OOO000OOOOOO0O [-2 ])>5 :#line:741
			OOO000O0OOO00O000 =O00OOO000OOOOOO0O [-2 ]#line:742
	wiz .log ("YouTube URL: %s"%OOO000O0OOO00O000 )#line:743
	if wiz .getCond ('System.HasAddon(plugin.video.youtube)')==1 :#line:744
		OOO000O0OOO00O000 ='plugin://plugin.video.youtube/play/?video_id=%s'%OOO000O0OOO00O000 #line:745
		xbmc .Player ().play (OOO000O0OOO00O000 )#line:746
	xbmc .sleep (2000 )#line:747
	if xbmc .Player ().isPlayingVideo ()==0 :#line:748
		 yt .PlayVideo (OOO000O0OOO00O000 )#line:749
def addonMenu (name =None ,url =None ):#line:751
	if not ADDONFILE =='http://':#line:752
		if url ==None :#line:753
			O0OO0O0O00OO000O0 =wiz .textCache (uservar .ADDONFILE )#line:754
			if O0OO0O0O00OO000O0 ==False :O000OO00O0O00OOO0 =wiz .workingURL (uservar .ADDONFILE )#line:755
		else :#line:756
			O0OO0O0O00OO000O0 =wiz .textCache (url )#line:757
			if O0OO0O0O00OO000O0 ==False :O000OO00O0O00OOO0 =wiz .workingURL (url )#line:758
		if not O0OO0O0O00OO000O0 ==False :#line:759
			O0O00OO000OOO0O0O =O0OO0O0O00OO000O0 .replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:760
			OO0OO00000OO0000O =re .compile ('name="(.+?)".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"').findall (O0O00OO000OOO0O0O )#line:761
			if len (OO0OO00000OO0000O )>0 :#line:762
				OO000000O000000OO =0 #line:763
				for O0O000000OOOOO0OO ,OOO0O00O0OO0O0O0O ,O0OO0OO0000OO0OO0 ,O00OOOOO0OOO0000O ,OO0OO00000OO0O000 ,O0OO0OOO00OO0OOO0 ,OOO00OOO00O000OOO ,O00OO000O0O000O00 ,O0OOO0O00O000OO0O ,O0000OOO00000OO0O in OO0OO00000OO0000O :#line:764
					if OOO0O00O0OO0O0O0O .lower ()=='section':#line:765
						addonMenu (name ,url )#line:766
					elif OOO0O00O0OO0O0O0O .lower ()=='skin':#line:767
						skinInstaller (name ,url )#line:768
					elif OOO0O00O0OO0O0O0O .lower ()=='pack':#line:769
						packInstaller (name ,url )#line:770
					else :#line:771
						if not SHOWADULT =='true'and O0OOO0O00O000OO0O .lower ()=='yes':continue #line:772
						try :#line:773
							OO00O00O00OOOO0OO =xbmcaddon .Addon (id =OOO0O00O0OO0O0O0O ).getAddonInfo ('path')#line:774
							if os .path .exists (OO00O00O00OOOO0OO ):#line:775
								O0O000000OOOOO0OO ="[COLOR green][מותקן][/COLOR] %s"%O0O000000OOOOO0OO #line:776
						except :#line:777
							pass #line:778
						addonInstaller (OOO0O00O0OO0O0O0O ,url )#line:779
					if OO000000O000000OO <1 :#line:780
						wiz .LogNotify ("[COLOR %s]אין הרחבות[/COLOR]"%COLOR1 )#line:781
			else :#line:782
				addFile ('Text File not formated correctly!','',themeit =THEME3 )#line:783
				wiz .log ("[Addon Menu] ERROR: Invalid Format.")#line:784
		else :#line:785
			wiz .log ("[Addon Menu] ERROR: URL for Addon list not working.")#line:786
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:787
			addFile ('%s'%O000OO00O0O00OOO0 ,'',themeit =THEME3 )#line:788
	else :wiz .log ("[Addon Menu] No Addon list added.")#line:789
def packInstaller (OOOOO0OOO000O00OO ,O0OO000OOO0OO0000 ):#line:793
	if not wiz .workingURL (O0OO000OOO0OO0000 )==True :wiz .LogNotify ("[COLOR %s]התקנת הרחבה [/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]כתובת זיפ שגויה[/COLOR]'%(COLOR1 ,OOOOO0OOO000O00OO ,COLOR2 ));return #line:794
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:795
	DP .create (ADDONTITLE ,'[COLOR %s][B]הורדה מתבצעת [/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0OOO000O00OO ),'','[COLOR %s] אנא המתן [/COLOR]'%COLOR2 )#line:796
	O00000OOO00OOO0O0 =O0OO000OOO0OO0000 .split ('/')#line:797
	OO00OO00OOOOO0OO0 =xbmc .makeLegalFilename (os .path .join (PACKAGES ,O00000OOO00OOO0O0 [-1 ]))#line:798
	try :os .remove (OO00OO00OOOOO0OO0 )#line:799
	except :pass #line:800
	downloader .download (O0OO000OOO0OO0000 ,OO00OO00OOOOO0OO0 ,DP )#line:801
	O000OOOO0O0OO0OO0 ='[COLOR %s][B] מתקין: [/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOOOO0OOO000O00OO )#line:802
	DP .update (0 ,O000OOOO0O0OO0OO0 ,'','[COLOR %s]אנא המתן [/COLOR]'%COLOR2 )#line:803
	OO0OOO0OO000OO000 ,O0O0OOO00O0O000O0 ,OOOO00O00000OO00O =extract .all (OO00OO00OOOOO0OO0 ,ADDONS ,DP ,title =O000OOOO0O0OO0OO0 )#line:804
	OO00OOO00OO0OO0OO =grabAddons (OO00OO00OOOOO0OO0 )#line:805
	if KODIV >=17 :wiz .addonDatabase (OO00OOO00OO0OO0OO ,1 ,True )#line:806
	DP .close ()#line:807
	wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s: Installed![/COLOR]'%(COLOR2 ,OOOOO0OOO000O00OO ))#line:808
	wiz .ebi ('UpdateAddonRepos()')#line:809
	wiz .ebi ('UpdateLocalAddons()')#line:810
	wiz .refresh ()#line:811
def skinInstaller (OOO0O0OOO0O0OOO0O ,O000OOOOO0OO0OOO0 ):#line:812
	if not wiz .workingURL (O000OOOOO0OO0OOO0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]Invalid Zip Url![/COLOR]'%(COLOR1 ,OOO0O0OOO0O0OOO0O ,COLOR2 ));return #line:813
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:814
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0OOO0O0OOO0O ),'','[COLOR %s]Please Wait[/COLOR]'%COLOR2 )#line:815
	OOO0OOOOOO0OOO0O0 =O000OOOOO0OO0OOO0 .split ('/')#line:816
	O0OOO00OOOOOO0OO0 =xbmc .makeLegalFilename (os .path .join (PACKAGES ,OOO0OOOOOO0OOO0O0 [-1 ]))#line:817
	try :os .remove (O0OOO00OOOOOO0OO0 )#line:818
	except :pass #line:819
	downloader .download (O000OOOOO0OO0OOO0 ,O0OOO00OOOOOO0OO0 ,DP )#line:820
	O000OO000O0OOOOOO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0O0OOO0O0OOO0O )#line:821
	DP .update (0 ,O000OO000O0OOOOOO ,'','[COLOR %s]Please Wait[/COLOR]'%COLOR2 )#line:822
	O0O0O000O0O0OO0O0 ,OO0O0000O00O00O00 ,OOO0O00OOO00O000O =extract .all (O0OOO00OOOOOO0OO0 ,HOME ,DP ,title =O000OO000O0OOOOOO )#line:823
	OOOO0O0OOOOO0OOO0 =grabAddons (O0OOO00OOOOOO0OO0 )#line:824
	if KODIV >=17 :wiz .addonDatabase (OOOO0O0OOOOO0OOO0 ,1 ,True )#line:825
	DP .close ()#line:826
	wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s: Installed![/COLOR]'%(COLOR2 ,OOO0O0OOO0O0OOO0O ))#line:827
	wiz .ebi ('UpdateAddonRepos()')#line:828
	wiz .ebi ('UpdateLocalAddons()')#line:829
	for OO0O0000OOOO0O00O in OOOO0O0OOOOO0OOO0 :#line:830
		if OO0O0000OOOO0O00O .startswith ('skin.')==True and not OO0O0000OOOO0O00O =='skin.shortcuts':#line:831
			if not BUILDNAME ==''and DEFAULTIGNORE =='true':wiz .setS ('defaultskinignore','true')#line:832
			wiz .swapSkins (OO0O0000OOOO0O00O ,'Skin Installer')#line:833
	wiz .refresh ()#line:834
def addonInstaller (O0OO000OO00O00O00 ,OOOOOO0000OOOO0OO ):#line:835
	if not ADDONFILE =='http://'or '':#line:836
		OOOOOO0000OOOO0OO =ADDONFILE #line:837
		O00000O00000O0O0O =wiz .workingURL (OOOOOO0000OOOO0OO )#line:838
		if O00000O00000O0O0O ==True :#line:839
			OO0OOOOO00OO0O0O0 =wiz .textCache (OOOOOO0000OOOO0OO ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:840
			O0O00000O0000O000 =re .compile ('name="(.+?)".+?lugin="%s".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%O0OO000OO00O00O00 ).findall (OO0OOOOO00OO0O0O0 )#line:841
			if len (O0O00000O0000O000 )>0 :#line:842
				for OOO0000OOOO00O0OO ,OOOOOO0000OOOO0OO ,OOOOOO0OOOOOO00OO ,OO0O00O00OOO00OOO ,O0O00OO0O00O0O0O0 ,OO0O0OO0000OO0O0O ,OOO0O0OO0OO0O0O0O ,O0O0O0OO000O00OOO ,OOO000O00000O0O00 in O0O00000O0000O000 :#line:843
					if os .path .exists (os .path .join (ADDONS ,O0OO000OO00O00O00 )):#line:844
						OOOOOOOO00O000OOO =['Launch Addon','Remove Addon']#line:845
						O0OOO000OOO00O0O0 =DIALOG .select ("[COLOR %s] נראה  שההרחבה מותקנת, מה ברצונך לעשות?[/COLOR]"%COLOR2 ,OOOOOOOO00O000OOO )#line:846
						if O0OOO000OOO00O0O0 ==0 :#line:847
							wiz .ebi ('RunAddon(%s)'%O0OO000OO00O00O00 )#line:848
							xbmc .sleep (500 )#line:849
							return True #line:850
						elif O0OOO000OOO00O0O0 ==1 :#line:851
							wiz .cleanHouse (os .path .join (ADDONS ,O0OO000OO00O00O00 ))#line:852
							try :wiz .removeFolder (os .path .join (ADDONS ,O0OO000OO00O00O00 ))#line:853
							except :pass #line:854
							if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to remove the addon_data for:"%COLOR2 ,"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,O0OO000OO00O00O00 ),yeslabel ="[B][COLOR green]Yes Remove[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:855
								removeAddonData (O0OO000OO00O00O00 )#line:856
							wiz .refresh ()#line:857
							return True #line:858
						else :#line:859
							return False #line:860
					O000O0OO0O0OOOOOO =os .path .join (ADDONS ,OOOOOO0OOOOOO00OO )#line:861
					if not OOOOOO0OOOOOO00OO .lower ()=='none'and not os .path .exists (O000O0OO0O0OOOOOO ):#line:862
						wiz .log ("Repository not installed, installing it")#line:863
						if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך להתקין את מקור ההרחבה עובר הרחבה זו?  [COLOR %s]%s[/COLOR]:"%(COLOR2 ,COLOR1 ,O0OO000OO00O00O00 ),"[COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR1 ,OOOOOO0OOOOOO00OO ),yeslabel ="[B][COLOR green]Yes Install[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):#line:864
							OO00O000O0OO00OO0 =wiz .parseDOM (wiz .openURL (OO0O00O00OOO00OOO ),'addon',ret ='version',attrs ={'id':OOOOOO0OOOOOO00OO })#line:865
							if len (OO00O000O0OO00OO0 )>0 :#line:866
								O00O00O0O0O000O00 ='%s%s-%s.zip'%(O0O00OO0O00O0O0O0 ,OOOOOO0OOOOOO00OO ,OO00O000O0OO00OO0 [0 ])#line:867
								wiz .log (O00O00O0O0O000O00 )#line:868
								if KODIV >=17 :wiz .addonDatabase (OOOOOO0OOOOOO00OO ,1 )#line:869
								installAddon (OOOOOO0OOOOOO00OO ,O00O00O0O0O000O00 )#line:870
								wiz .ebi ('UpdateAddonRepos()')#line:871
								wiz .log ("Installing Addon from Kodi")#line:873
								O0O0OO0O0O0O0OOO0 =installFromKodi (O0OO000OO00O00O00 )#line:874
								wiz .log ("Install from Kodi: %s"%O0O0OO0O0O0O0OOO0 )#line:875
								if O0O0OO0O0O0O0OOO0 :#line:876
									wiz .refresh ()#line:877
									return True #line:878
							else :#line:879
								wiz .log ("[Addon Installer] Repository not installed: Unable to grab url! (%s)"%OOOOOO0OOOOOO00OO )#line:880
						else :wiz .log ("[Addon Installer] Repository for %s not installed: %s"%(O0OO000OO00O00O00 ,OOOOOO0OOOOOO00OO ))#line:881
					elif OOOOOO0OOOOOO00OO .lower ()=='none':#line:882
						wiz .log ("No repository, installing addon")#line:883
						OOO0OO0OOOOO00OOO =O0OO000OO00O00O00 #line:884
						OO00O000O0OO0000O =OOOOOO0000OOOO0OO #line:885
						installAddon (O0OO000OO00O00O00 ,OOOOOO0000OOOO0OO )#line:886
						wiz .refresh ()#line:887
						return True #line:888
					else :#line:889
						wiz .log ("Repository installed, installing addon")#line:890
						O0O0OO0O0O0O0OOO0 =installFromKodi (O0OO000OO00O00O00 ,False )#line:891
						if O0O0OO0O0O0O0OOO0 :#line:892
							wiz .refresh ()#line:893
							return True #line:894
					if os .path .exists (os .path .join (ADDONS ,O0OO000OO00O00O00 )):return True #line:895
					O0O0000O000O0OOO0 =wiz .parseDOM (wiz .openURL (OO0O00O00OOO00OOO ),'addon',ret ='version',attrs ={'id':O0OO000OO00O00O00 })#line:896
					if len (O0O0000O000O0OOO0 )>0 :#line:897
						OOOOOO0000OOOO0OO ="%s%s-%s.zip"%(OOOOOO0000OOOO0OO ,O0OO000OO00O00O00 ,O0O0000O000O0OOO0 [0 ])#line:898
						wiz .log (str (OOOOOO0000OOOO0OO ))#line:899
						if KODIV >=17 :wiz .addonDatabase (O0OO000OO00O00O00 ,1 )#line:900
						installAddon (O0OO000OO00O00O00 ,OOOOOO0000OOOO0OO )#line:901
						wiz .refresh ()#line:902
					else :#line:903
						wiz .log ("no match");return False #line:904
			else :wiz .log ("[Addon Installer] Invalid Format")#line:905
		else :wiz .log ("[Addon Installer] Text File: %s"%O00000O00000O0O0O )#line:906
	else :wiz .log ("[Addon Installer] Not Enabled.")#line:907
def installFromKodi (O0OO0O0OOOOO0O000 ,over =True ):#line:908
	if over ==True :#line:909
		xbmc .sleep (2000 )#line:910
	wiz .ebi ('RunPlugin(plugin://%s)'%O0OO0O0OOOOO0O000 )#line:912
	if not wiz .whileWindow ('yesnodialog'):#line:913
		return False #line:914
	xbmc .sleep (500 )#line:915
	if wiz .whileWindow ('okdialog'):#line:916
		return False #line:917
	wiz .whileWindow ('progressdialog')#line:918
	if os .path .exists (os .path .join (ADDONS ,O0OO0O0OOOOO0O000 )):return True #line:919
	else :return False #line:920
def installAddon (OOO0OO0000OO00000 ,OO0O0OO000OOO0OO0 ):#line:921
	if not wiz .workingURL (OO0O0OO000OOO0OO0 )==True :wiz .LogNotify ("[COLOR %s]Addon Installer[/COLOR]"%COLOR1 ,'[COLOR %s]%s:[/COLOR] [COLOR %s]Invalid Zip Url![/COLOR]'%(COLOR1 ,OOO0OO0000OO00000 ,COLOR2 ));return #line:922
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:923
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0000OO00000 ),'','[COLOR %s]Please Wait[/COLOR]'%COLOR2 )#line:924
	O00OO0O00000O00OO =OO0O0OO000OOO0OO0 .split ('/')#line:925
	O0OOO00O0000000O0 =os .path .join (PACKAGES ,O00OO0O00000O00OO [-1 ])#line:926
	try :os .remove (O0OOO00O0000000O0 )#line:927
	except :pass #line:928
	downloader .download (OO0O0OO000OOO0OO0 ,O0OOO00O0000000O0 ,DP )#line:929
	O00O00O000000OOO0 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0OO0000OO00000 )#line:930
	DP .update (0 ,O00O00O000000OOO0 ,'','[COLOR %s]Please Wait[/COLOR]'%COLOR2 )#line:931
	OO0O000OOOO00OO0O ,O0OOOO0O0O0000O0O ,O0OOO00O000OO00OO =extract .all (O0OOO00O0000000O0 ,ADDONS ,DP ,title =O00O00O000000OOO0 )#line:932
	DP .update (0 ,O00O00O000000OOO0 ,'','[COLOR %s]Installing Dependencies[/COLOR]'%COLOR2 )#line:933
	installed (OOO0OO0000OO00000 )#line:934
	O0O0000000000O000 =grabAddons (O0OOO00O0000000O0 )#line:935
	wiz .log (str (O0O0000000000O000 ))#line:936
	if KODIV >=17 :wiz .addonDatabase (O0O0000000000O000 ,1 ,True )#line:937
	installDep (OOO0OO0000OO00000 ,DP )#line:938
	DP .close ()#line:939
	wiz .ebi ('UpdateAddonRepos()')#line:940
	wiz .ebi ('UpdateLocalAddons()')#line:941
	wiz .refresh ()#line:942
	for OOOOO00O0OO0O0O00 in O0O0000000000O000 :#line:943
		if OOOOO00O0OO0O0O00 .startswith ('skin.')==True and not OOOOO00O0OO0O0O00 =='skin.shortcuts':#line:944
			if not BUILDNAME ==''and DEFAULTIGNORE =='true':wiz .setS ('defaultskinignore','true')#line:945
			wiz .swapSkins (OOOOO00O0OO0O0O00 ,'Skin Installer')#line:946
def installDep (O00OO0O0OO0OO0OOO ,DP =None ):#line:947
	OO0O0000OO00O0O00 =os .path .join (ADDONS ,O00OO0O0OO0OO0OOO ,'addon.xml')#line:948
	if os .path .exists (OO0O0000OO00O0O00 ):#line:949
		OOO0OOO00OO0O0OOO =open (OO0O0000OO00O0O00 ,mode ='r');OO0O0000O00O0OO0O =OOO0OOO00OO0O0OOO .read ();OOO0OOO00OO0O0OOO .close ();#line:950
		O00OOO0OO00000000 =wiz .parseDOM (OO0O0000O00O0OO0O ,'import',ret ='addon')#line:951
		for OOO000000000OO0O0 in O00OOO0OO00000000 :#line:952
			if not 'xbmc.python'in OOO000000000OO0O0 :#line:953
				if not DP ==None :#line:954
					DP .update (0 ,'','[COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO000000000OO0O0 ))#line:955
				try :#line:956
					OOO0O00OOOOOO0O00 =xbmcaddon .Addon (id =OOO000000000OO0O0 )#line:957
					OOO0OOOOOOOO000OO =OOO0O00OOOOOO0O00 .getAddonInfo ('name')#line:958
				except :#line:959
					wiz .createTemp (OOO000000000OO0O0 )#line:960
					if KODIV >=17 :wiz .addonDatabase (OOO000000000OO0O0 ,1 )#line:961
def installed (O000O00OOO0OO0OOO ):#line:962
	O00O0O00OOO0O0000 =os .path .join (ADDONS ,O000O00OOO0OO0OOO ,'addon.xml')#line:963
	if os .path .exists (O00O0O00OOO0O0000 ):#line:964
		try :#line:965
			OOOO000O0O0O00OO0 =open (O00O0O00OOO0O0000 ,mode ='r');O0O00O0OO00OO0000 =OOOO000O0O0O00OO0 .read ();OOOO000O0O0O00OO0 .close ()#line:966
			OO0O00OOO0O00O0O0 =wiz .parseDOM (O0O00O0OO00OO0000 ,'addon',ret ='name',attrs ={'id':O000O00OOO0OO0OOO })#line:967
			OO00O0O00O0000O0O =os .path .join (ADDONS ,O000O00OOO0OO0OOO ,'icon.png')#line:968
			wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O00OOO0O00O0O0 [0 ]),'[COLOR %s]Addon Enabled[/COLOR]'%COLOR2 ,'2000',OO00O0O00O0000O0O )#line:969
		except :pass #line:970
def youtubeMenu (name =None ,url =None ):#line:971
	if not YOUTUBEFILE =='http://':#line:972
		if url ==None :#line:973
			O0O000OOO0O000OO0 =wiz .textCache (uservar .YOUTUBEFILE )#line:974
			if O0O000OOO0O000OO0 ==False :O000O0OOO0000O0OO =wiz .workingURL (uservar .YOUTUBEFILE )#line:975
		else :#line:976
			O0O000OOO0O000OO0 =wiz .textCache (url )#line:977
			if O0O000OOO0O000OO0 ==False :O000O0OOO0000O0OO =wiz .workingURL (url )#line:978
		if not O0O000OOO0O000OO0 ==False :#line:979
			OO00O00000O000O00 =O0O000OOO0O000OO0 .replace ('\n','').replace ('\r','').replace ('\t','')#line:980
			OO000OOOO00O0OOOO =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO00O00000O000O00 )#line:981
			if len (OO000OOOO00O0OOOO )>0 :#line:982
				for name ,url ,O00O00O0OO0O0000O ,OOO00O00O0OOOOO0O ,OOO00OO000O0OO000 in OO000OOOO00O0OOOO :#line:983
					addFile (name ,'viewVideo',url =url ,description =OOO00OO000O0OO000 ,icon =O00O00O0OO0O0000O ,fanart =OOO00O00O0OOOOO0O ,themeit =THEME2 )#line:984
			else :wiz .log ("[YouTube Menu] ERROR: Invalid Format.")#line:985
		else :#line:986
			wiz .log ("[YouTube Menu] ERROR: URL for YouTube list not working.")#line:987
			addFile ('Url for txt file not valid','',themeit =THEME3 )#line:988
			addFile ('%s'%O000O0OOO0000O0OO ,'',themeit =THEME3 )#line:989
	else :wiz .log ("[YouTube Menu] No YouTube list added.")#line:990
	setView ('files','viewType')#line:991
def maintMenu (view =None ):#line:992
	O000OO000O0OOO0O0 ='[B][COLOR green]ON[/COLOR][/B]';O00000O00OOOOOOOO ='[B][COLOR red]OFF[/COLOR][/B]'#line:993
	if wiz .Grab_Log (True )==False :OOO0000OOO0O00000 =0 #line:994
	else :OOO0000OOO0O00000 =errorChecking (wiz .Grab_Log (True ),True )#line:995
	if wiz .Grab_Log (True ,True )==False :O0OOO0O0000OO00O0 =0 #line:996
	else :O0OOO0O0000OO00O0 =errorChecking (wiz .Grab_Log (True ,True ),True )#line:997
	O0OO00O0OO00OO0O0 =int (OOO0000OOO0O00000 )+int (O0OOO0O0000OO00O0 )#line:998
	O0O00O0OOOO0OO0OO =': [COLOR red]לא נמצא[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:999
	OOO000000OO0O00O0 =wiz .getSize (PACKAGES )#line:1000
	O0O000OO0OO00O00O =wiz .getSize (THUMBS )#line:1001
	OOOOOOO0OO000OOOO =wiz .getCacheSize ()#line:1002
	O00OOO0OO0O00O00O =OOO000000OO0O00O0 +O0O000OO0OO00O00O +OOOOOOO0OO000OOOO #line:1003
	addFile ('Total Clean Up: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O00OOO0OO0O00O00O ),'fullclean',icon =ICONMAINT ,themeit =THEME3 )#line:1004
	addFile ('Clear Cache: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOOOOOO0OO000OOOO ),'clearcache',icon =ICONMAINT ,themeit =THEME3 )#line:1005
	addFile ('Clear Packages: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (OOO000000OO0O00O0 ),'clearpackages',icon =ICONMAINT ,themeit =THEME3 )#line:1006
	addFile ('Clear Thumbnails: [COLOR green][B]%s[/B][/COLOR]'%wiz .convertSize (O0O000OO0OO00O00O ),'clearthumb',icon =ICONMAINT ,themeit =THEME3 )#line:1007
	addFile ('Clear Old Thumbnails','oldThumbs',icon =ICONMAINT ,themeit =THEME3 )#line:1008
	addFile ('Clear Crash Logs','clearcrash',icon =ICONMAINT ,themeit =THEME3 )#line:1009
	addFile ('Purge Databases','purgedb',icon =ICONMAINT ,themeit =THEME3 )#line:1010
	addDir ('[B]Back up/Restore[/B]','backup',icon =ICONMAINT ,themeit =THEME1 )#line:1011
	addDir ('[B]Advanced Settings Tool[/B]','autoconfig',icon =ICONMAINT ,themeit =THEME1 )#line:1012
	addDir ('[B]Addon Tools[/B]','addon',icon =ICONMAINT ,themeit =THEME1 )#line:1013
	addDir ('[B]Misc Maintenance[/B]','misc',icon =ICONMAINT ,themeit =THEME1 )#line:1014
	addDir ('[B]System Tweaks/Fixes[/B]','tweaks',icon =ICONMAINT ,themeit =THEME1 )#line:1015
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1016
	addFile ('!!!>>Fresh Start<<!!!','freshstart',icon =ICONMAINT ,themeit =THEME6 )#line:1017
def backup ():#line:1018
		addFile ('Back Up Location: [COLOR %s]%s[/COLOR]'%(COLOR2 ,MYBUILDS ),'settings','בדיקת מהירןת',icon =ICONMAINT ,themeit =THEME3 )#line:1019
		if HIDESPACERS =='No':addFile (wiz .sep ('Backup'),'',themeit =THEME1 )#line:1020
		addFile ('[Back Up]: Build','backupbuild',icon =ICONMAINT ,themeit =THEME3 )#line:1021
		addFile ('[Back Up]: GuiFix','backupgui',icon =ICONMAINT ,themeit =THEME3 )#line:1022
		addFile ('[Back Up]: Theme','backuptheme',icon =ICONMAINT ,themeit =THEME3 )#line:1023
		addFile ('[Back Up]: Addon Pack','backupaddonpack',icon =ICONMAINT ,themeit =THEME3 )#line:1024
		addFile ('[Back Up]: Addon_data','backupaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1025
		if HIDESPACERS =='No':addFile (wiz .sep ('Restore'),'',themeit =THEME1 )#line:1026
		addFile ('[Restore]: Local Build','restorezip',icon =ICONMAINT ,themeit =THEME3 )#line:1027
		addFile ('[Restore]: Local GuiFix','restoregui',icon =ICONMAINT ,themeit =THEME3 )#line:1028
		addFile ('[Restore]: Local Addon_data','restoreaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1029
		addFile ('[Restore]: External Build','restoreextzip',icon =ICONMAINT ,themeit =THEME3 )#line:1030
		addFile ('[Restore]: External GuiFix','restoreextgui',icon =ICONMAINT ,themeit =THEME3 )#line:1031
		addFile ('[Restore]: External Addon_data','restoreextaddon',icon =ICONMAINT ,themeit =THEME3 )#line:1032
		if HIDESPACERS =='No':addFile (wiz .sep ('Delete All Backups'),'',themeit =THEME1 )#line:1033
		addFile ('Clean Up Back Up Folder','clearbackup',icon =ICONMAINT ,themeit =THEME3 )#line:1034
def addon ():#line:1035
		addFile ('Remove Addons','removeaddons',icon =ICONMAINT ,themeit =THEME3 )#line:1036
		addDir ('Remove Addon Data','removeaddondata',icon =ICONMAINT ,themeit =THEME3 )#line:1037
		addDir ('Enable/Disable Addons','enableaddons',icon =ICONMAINT ,themeit =THEME3 )#line:1038
		addFile ('Enable/Disable Adult Addons','toggleadult',icon =ICONMAINT ,themeit =THEME3 )#line:1039
		addFile ('Force Update Addons','forceupdate',icon =ICONMAINT ,themeit =THEME3 )#line:1040
		addFile ('Hide Passwords On Keyboard Entry','hidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:1041
		addFile ('Unhide Passwords On Keyboard Entry','unhidepassword',icon =ICONMAINT ,themeit =THEME3 )#line:1042
def misc ():#line:1043
		OOOOOO0O0OOOO0O00 =int (errorChecking (count =True ))#line:1044
		O0OO0OO0OOOOO00OO =str (OOOOOO0O0OOOO0O00 )#line:1045
		O0OOOOO000000O0O0 ='[COLOR red]%s[/COLOR] Error(s) נמצא/ו'%(O0OO0OO0OOOOO00OO )if OOOOOO0O0OOOO0O00 >0 else 'אין שגיאות'#line:1046
		O00OOOO0000000O00 =': [COLOR red]לא נמצא[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:1047
		addFile ('Kodi 17 Fix','kodi17fix',icon =ICONMAINT ,themeit =THEME3 )#line:1048
		addDir ('Speed Test','speedtest',icon =ICONMAINT ,themeit =THEME3 )#line:1049
		addFile ('Enable Unknown Sources','unknownsources',icon =ICONMAINT ,themeit =THEME3 )#line:1050
		addFile ('Reload Skin','forceskin',icon =ICONMAINT ,themeit =THEME3 )#line:1051
		addFile ('Reload Profile','forceprofile',icon =ICONMAINT ,themeit =THEME3 )#line:1052
		addFile ('Force Close Kodi','forceclose',icon =ICONMAINT ,themeit =THEME3 )#line:1053
		addFile ('Upload Log File','uploadlog',icon =ICONMAINT ,themeit =THEME3 )#line:1054
		addFile ('View Errors in Log: %s'%(O0OOOOO000000O0O0 ),'viewerrorlog',icon =ICONMAINT ,themeit =THEME3 )#line:1055
		if OOOOOO0O0OOOO0O00 >0 :addFile ('View Last Error In Log','viewerrorlast',icon =ICONMAINT ,themeit =THEME3 )#line:1056
		addFile ('View Log File','viewlog',icon =ICONMAINT ,themeit =THEME3 )#line:1057
		addFile ('View Wizard Log File','viewwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:1058
		addFile ('Clear Wizard Log File%s'%O00OOOO0000000O00 ,'clearwizlog',icon =ICONMAINT ,themeit =THEME3 )#line:1059
def autoconfig ():#line:1060
	if not ADVANCEDFILE =='http://'and not ADVANCEDFILE =='':#line:1061
			addDir ('Advanced Settings','advancedsetting',icon =ICONMAINT ,themeit =THEME3 )#line:1062
	else :#line:1063
		if os .path .exists (ADVANCED ):#line:1064
			addFile ('View Current AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:1065
			addFile ('Remove Current AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1066
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1067
		addFile ('Full Configure AdvancedSettings.xml','autoadvanced1',icon =ICONMAINT ,themeit =THEME3 )#line:1068
def tweaks ():#line:1069
	OO0000O0O0O0O0O0O ='[B][COLOR green]ON[/COLOR][/B]';OOOOO0OO0OO00O0O0 ='[B][COLOR red]OFF[/COLOR][/B]'#line:1070
	OO0O0OOO000O0OOO0 ='true'if AUTOCLEANUP =='true'else 'false'#line:1071
	OOO0000OO0000OOOO ='true'if AUTOCACHE =='true'else 'false'#line:1072
	O00O0OO000OOO0O0O ='true'if AUTOPACKAGES =='true'else 'false'#line:1073
	OO0O00OO000OO0000 ='true'if AUTOTHUMBS =='true'else 'false'#line:1074
	O0OO0O0O0O0O0O00O ='true'if SHOWMAINT =='true'else 'false'#line:1075
	O0O0O0OOOOOOO0O0O ='true'if INCLUDEVIDEO =='true'else 'false'#line:1076
	O0O00OO00OOO00000 ='true'if INCLUDEALL =='true'else 'false'#line:1077
	OOOO0OOO00000OOOO ='true'if THIRDPARTY =='true'else 'false'#line:1078
	addDir ('System Information','systeminfo',icon =ICONMAINT ,themeit =THEME1 )#line:1079
	addFile ('Scan Sources for broken links','checksources',icon =ICONMAINT ,themeit =THEME3 )#line:1080
	addFile ('Scan For Broken Repositories','checkrepos',icon =ICONMAINT ,themeit =THEME3 )#line:1081
	addFile ('Fix Addons Not Updating','fixaddonupdate',icon =ICONMAINT ,themeit =THEME3 )#line:1082
	addFile ('Remove Non-Ascii filenames','asciicheck',icon =ICONMAINT ,themeit =THEME3 )#line:1083
	addFile ('Convert Paths to special','convertpath',icon =ICONMAINT ,themeit =THEME3 )#line:1084
	addFile ('Third Party Wizards: %s'%OOOO0OOO00000OOOO .replace ('true',OO0000O0O0O0O0O0O ).replace ('false',OOOOO0OO0OO00O0O0 ),'togglesetting','enable3rd',fanart =FANART ,icon =ICONMAINT ,themeit =THEME1 )#line:1085
	if OOOO0OOO00000OOOO =='true':#line:1086
		O00000O0OOO0O0OO0 =THIRD1NAME if not THIRD1NAME ==''else 'Not Set'#line:1087
		OOO00O0O0OO0OO0OO =THIRD2NAME if not THIRD2NAME ==''else 'Not Set'#line:1088
		O00O000000OO0O000 =THIRD3NAME if not THIRD3NAME ==''else 'Not Set'#line:1089
		addFile ('Edit Third Party Wizard 1: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00000O0OOO0O0OO0 ),'editthird','1',icon =ICONMAINT ,themeit =THEME3 )#line:1090
		addFile ('Edit Third Party Wizard 2: [COLOR %s]%s[/COLOR]'%(COLOR2 ,OOO00O0O0OO0OO0OO ),'editthird','2',icon =ICONMAINT ,themeit =THEME3 )#line:1091
		addFile ('Edit Third Party Wizard 3: [COLOR %s]%s[/COLOR]'%(COLOR2 ,O00O000000OO0O000 ),'editthird','3',icon =ICONMAINT ,themeit =THEME3 )#line:1092
def net_tools (view =None ):#line:1093
	addDir ('Speed Tester','speedtest',icon =ICONAPK ,themeit =THEME1 )#line:1094
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1095
	addDir ('View IP Address & MAC Address','viewIP',icon =ICONMAINT ,themeit =THEME1 )#line:1096
	setView ('files','viewType')#line:1097
def viewIP ():#line:1098
	OOO0O0O0OOO0OO0O0 =['Network.IPAddress','Network.MacAddress',]#line:1100
	O0O0OO0OO0000O0OO =[];OO00OOO0O00OOOO00 =0 #line:1101
	for O0000000OOOOO000O in OOO0O0O0OOO0OO0O0 :#line:1102
		OOOOOOO00OOO0OOOO =wiz .getInfo (O0000000OOOOO000O )#line:1103
		O0O0O00O000O000OO =0 #line:1104
		while OOOOOOO00OOO0OOOO =="Busy"and O0O0O00O000O000OO <10 :#line:1105
			OOOOOOO00OOO0OOOO =wiz .getInfo (O0000000OOOOO000O );O0O0O00O000O000OO +=1 ;wiz .log ("%s sleep %s"%(O0000000OOOOO000O ,str (O0O0O00O000O000OO )));xbmc .sleep (200 )#line:1106
		O0O0OO0OO0000O0OO .append (OOOOOOO00OOO0OOOO )#line:1107
		OO00OOO0O00OOOO00 +=1 #line:1108
		OO0O00OO00O0O0O0O =wiz .getConfig ()#line:1109
		OO00OO00OOOOOO0O0 ='%(ip)s'%OO0O00OO00O0O0O0O ['client']#line:1110
		O0OOOOO0000OOOOO0 ='%(isp)s'%OO0O00OO00O0O0O0O ['client']#line:1111
		OO00OO0O00O0000O0 ='%(country)s'%OO0O00OO00O0O0O0O ['client']#line:1112
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO0OO0000O0OO [0 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1113
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO00OOOOOO0O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1114
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOOOO0000OOOOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1115
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO00OO0O00O0000O0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1116
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0O0OO0OO0000O0OO [1 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1117
def speedTest ():#line:1118
	addFile ('Run Speed Test','speed',icon =ICONMAINT ,themeit =THEME3 )#line:1119
	if os .path .exists (SPEEDTESTFOLD ):#line:1120
		O0O0OO000OO0000OO =glob .glob (os .path .join (SPEEDTESTFOLD ,'*.png'))#line:1121
		O0O0OO000OO0000OO .sort (key =lambda OOO000OOO000OOOOO :os .path .getmtime (OOO000OOO000OOOOO ),reverse =True )#line:1122
		if len (O0O0OO000OO0000OO )>0 :#line:1123
			addFile ('Clear Results','clearspeedtest',icon =ICONMAINT ,themeit =THEME3 )#line:1124
			addFile (wiz .sep ('Previous Runs'),'',icon =ICONMAINT ,themeit =THEME3 )#line:1125
			for OOOO0OO00O0OOO0O0 in O0O0OO000OO0000OO :#line:1126
				O00000OO0OOO00O0O =datetime .fromtimestamp (os .path .getmtime (OOOO0OO00O0OOO0O0 )).strftime ('%m/%d/%Y %H:%M:%S')#line:1127
				OOOO000OOOO0000OO =OOOO0OO00O0OOO0O0 .replace (os .path .join (SPEEDTESTFOLD ,''),'')#line:1128
				addFile ('[B]%s[/B]: [I]Ran %s[/I]'%(OOOO000OOOO0000OO ,O00000OO0OOO00O0O ),'viewspeedtest',OOOO000OOOO0000OO ,icon =ICONMAINT ,themeit =THEME3 )#line:1129
def clearSpeedTest ():#line:1130
	O0O0O00O0OO00OOO0 =glob .glob (os .path .join (SPEEDTESTFOLD ,'*.png'))#line:1131
	for O000000000O0OOOOO in O0O0O00O0OO00OOO0 :#line:1132
		wiz .removeFile (O000000000O0OOOOO )#line:1133
def viewSpeedTest (img =None ):#line:1134
	img =os .path .join (SPEEDTESTFOLD ,img )#line:1135
	notify .speedTest (img )#line:1136
def speed ():#line:1137
	try :#line:1138
		O00O0O0OOOO000O0O =speedtest .speedtest ()#line:1139
		if not os .path .exists (SPEEDTESTFOLD ):os .makedirs (SPEEDTESTFOLD )#line:1140
		OO000OO0O00OO0O0O =O00O0O0OOOO000O0O [0 ].split ('/')#line:1141
		OOOO0O0O0O00O0000 =os .path .join (SPEEDTESTFOLD ,OO000OO0O00OO0O0O [-1 ])#line:1142
		urllib .urlretrieve (O00O0O0OOOO000O0O [0 ],OOOO0O0O0O00O0000 )#line:1143
		viewSpeedTest (OO000OO0O00OO0O0O [-1 ])#line:1144
	except :#line:1145
		wiz .log ("[Speed Test] Error Running Speed Test")#line:1146
		pass #line:1147
def advancedWindow (url =None ):#line:1148
	if not ADVANCEDFILE =='http://':#line:1149
		if url ==None :#line:1150
			O0OO0OOOOO00000O0 =wiz .textCache (uservar .ADVANCEDFILE )#line:1151
			if O0OO0OOOOO00000O0 ==False :O000O0000O0O0O0OO =wiz .workingURL (uservar .ADVANCEDFILE )#line:1152
		else :#line:1153
			O0OO0OOOOO00000O0 =wiz .textCache (url )#line:1154
			if O0OO0OOOOO00000O0 ==False :O000O0000O0O0O0OO =wiz .workingURL (url )#line:1155
		addFile ('Configure AdvancedSettings.xml','autoadvanced1',icon =ICONMAINT ,themeit =THEME3 )#line:1156
		addFile ('Quick Configure AdvancedSettings.xml','autoadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1157
		if os .path .exists (ADVANCED ):#line:1158
			addFile ('View Current AdvancedSettings.xml','currentsettings',icon =ICONMAINT ,themeit =THEME3 )#line:1159
			addFile ('Remove Current AdvancedSettings.xml','removeadvanced',icon =ICONMAINT ,themeit =THEME3 )#line:1160
		if not O0OO0OOOOO00000O0 ==False :#line:1161
			if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONMAINT ,themeit =THEME3 )#line:1162
			OO0OO000O0OOO0O00 =O0OO0OOOOO00000O0 .replace ('\n','').replace ('\r','').replace ('\t','')#line:1163
			OO00OOO0OO000O000 =re .compile ('name="(.+?)".+?ection="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OO0OO000O0OOO0O00 )#line:1164
			if len (OO00OOO0OO000O000 )>0 :#line:1165
				for O0O0OOO00OOO00O00 ,OOO0OOOO0OO0OO00O ,url ,O0O00OO0OO0O0O0OO ,OOO000O0O0O0O0O0O ,OOO0OOO000O000OO0 in OO00OOO0OO000O000 :#line:1166
					if OOO0OOOO0OO0OO00O .lower ()=="yes":#line:1167
						addDir ("[B]%s[/B]"%O0O0OOO00OOO00O00 ,'advancedsetting',url ,description =OOO0OOO000O000OO0 ,icon =O0O00OO0OO0O0O0OO ,fanart =OOO000O0O0O0O0O0O ,themeit =THEME3 )#line:1168
					else :#line:1169
						addFile (O0O0OOO00OOO00O00 ,'writeadvanced',O0O0OOO00OOO00O00 ,url ,description =OOO0OOO000O000OO0 ,icon =O0O00OO0OO0O0O0OO ,fanart =OOO000O0O0O0O0O0O ,themeit =THEME2 )#line:1170
			else :wiz .log ("[Advanced Settings] ERROR: Invalid Format.")#line:1171
		else :wiz .log ("[Advanced Settings] URL not working: %s"%O000O0000O0O0O0OO )#line:1172
	else :wiz .log ("[Advanced Settings] not Enabled")#line:1173
def writeAdvanced (O000OO0O0O000O000 ,O0O0O0000O00O000O ):#line:1174
	O0000O000OO0O0O0O =wiz .workingURL (O0O0O0000O00O000O )#line:1175
	if O0000O000OO0O0O0O ==True :#line:1176
		if os .path .exists (ADVANCED ):OO0OO0OOO0O0O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]האם ברצונך לשכתב הגדרות אלו במקום אלו הקיימות?  [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000OO0O0O000O000 ),yeslabel ="[B][COLOR green]שכתב[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:1177
		else :OO0OO0OOO0O0O00O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to download and install [COLOR %s]%s[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,O000OO0O0O000O000 ),yeslabel ="[B][COLOR green]Install[/COLOR][/B]",nolabel ="[B][COLOR red]ביטול[/COLOR][/B]")#line:1178
		if OO0OO0OOO0O0O00O0 ==1 :#line:1179
			OOO0O00O00O0OOOO0 =wiz .openURL (O0O0O0000O00O000O )#line:1180
			OOOOOO0OOO0000OO0 =open (ADVANCED ,'w');#line:1181
			OOOOOO0OOO0000OO0 .write (OOO0O00O00O0OOOO0 )#line:1182
			OOOOOO0OOO0000OO0 .close ()#line:1183
			DIALOG .ok (ADDONTITLE ,'[COLOR %s]AdvancedSettings.xml הקובת שוכתב בהצלחה, לאחר שתאשר תוכנת הקודי תסגר[/COLOR]'%COLOR2 )#line:1184
			wiz .killxbmc (True )#line:1185
		else :wiz .log ("[Advanced Settings] install canceled");wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]כתיבה בוטלה![/COLOR]"%COLOR2 );return #line:1186
	else :wiz .log ("[Advanced Settings] URL not working: %s"%O0000O000OO0O0O0O );wiz .LogNotify ('[COLOR %s]%s[/COLOR]'%(COLOR1 ,ADDONTITLE ),"[COLOR %s]הקישור אינו תקין[/COLOR]"%COLOR2 )#line:1187
def viewAdvanced ():#line:1188
	if os .path .exists (ADVANCED ):#line:1189
		O0O000OOO0O0O0O0O =open (ADVANCED )#line:1190
		O000O0OO0O0OOOO00 =O0O000OOO0O0O0O0O .read ().replace ('\t','    ')#line:1191
		wiz .TextBox (ADDONTITLE ,O000O0OO0O0OOOO00 )#line:1192
		O0O000OOO0O0O0O0O .close ()#line:1193
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml לא נמצא[/COLOR]")#line:1194
def removeAdvanced ():#line:1195
	if os .path .exists (ADVANCED ):#line:1196
		wiz .removeFile (ADVANCED )#line:1197
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]AdvancedSettings.xml לא נמצא[/COLOR]")#line:1198
def showAutoAdvanced ():#line:1199
	notify .autoConfig2 ()#line:1200
def showAutoAdvanced1 ():#line:1201
	notify .autoConfig ()#line:1202
def getIP ():#line:1203
		OOO000OO0O0OOO000 =wiz .getConfig ()#line:1204
		O0OOO0OOO00000OO0 ='%(ip)s'%OOO000OO0O0OOO000 ['client']#line:1205
		O0OO00O0000000000 ='%(isp)s'%OOO000OO0O0OOO000 ['client']#line:1206
		O000000O0OO0O0000 ='%(country)s]'%OOO000OO0O0OOO000 ['client']#line:1207
		return O0OOO0OOO00000OO0 ,O0OO00O0000000000 ,O000000O0OO0O0000 #line:1208
def systemInfo ():#line:1209
	OO0000OO0OO0OOOO0 =['System.FriendlyName','System.BuildVersion','System.CpuUsage','System.ScreenMode','Network.IPAddress','Network.MacAddress','System.Uptime','System.TotalUptime','System.FreeSpace','System.UsedSpace','System.TotalSpace','System.Memory(free)','System.Memory(used)','System.Memory(total)']#line:1223
	OO0OO0OOOO00OO00O =[];O0OO0000OOOOOO0O0 =0 #line:1224
	for O000O0OOOOO0O0O0O in OO0000OO0OO0OOOO0 :#line:1225
		OOO0000000000O000 =wiz .getInfo (O000O0OOOOO0O0O0O )#line:1226
		OO000OOO000O0O000 =0 #line:1227
		while OOO0000000000O000 =="Busy"and OO000OOO000O0O000 <10 :#line:1228
			OOO0000000000O000 =wiz .getInfo (O000O0OOOOO0O0O0O );OO000OOO000O0O000 +=1 ;wiz .log ("%s sleep %s"%(O000O0OOOOO0O0O0O ,str (OO000OOO000O0O000 )));xbmc .sleep (200 )#line:1229
		OO0OO0OOOO00OO00O .append (OOO0000000000O000 )#line:1230
		O0OO0000OOOOOO0O0 +=1 #line:1231
	O0OOO0O0O0O0O000O =OO0OO0OOOO00OO00O [8 ]if 'Una'in OO0OO0OOOO00OO00O [8 ]else wiz .convertSize (int (float (OO0OO0OOOO00OO00O [8 ][:-8 ]))*1024 *1024 )#line:1232
	OO0OO00O0O00O0O00 =OO0OO0OOOO00OO00O [9 ]if 'Una'in OO0OO0OOOO00OO00O [9 ]else wiz .convertSize (int (float (OO0OO0OOOO00OO00O [9 ][:-8 ]))*1024 *1024 )#line:1233
	OOO000OO0OO0O00OO =OO0OO0OOOO00OO00O [10 ]if 'Una'in OO0OO0OOOO00OO00O [10 ]else wiz .convertSize (int (float (OO0OO0OOOO00OO00O [10 ][:-8 ]))*1024 *1024 )#line:1234
	O00OOOOOOOO0OOO00 =wiz .convertSize (int (float (OO0OO0OOOO00OO00O [11 ][:-2 ]))*1024 *1024 )#line:1235
	OOOO0O0OOOO0O0O00 =wiz .convertSize (int (float (OO0OO0OOOO00OO00O [12 ][:-2 ]))*1024 *1024 )#line:1236
	OOO0000OOO00OO0OO =wiz .convertSize (int (float (OO0OO0OOOO00OO00O [13 ][:-2 ]))*1024 *1024 )#line:1237
	O000OOO0OOO00OOO0 ,OOOO0O000000OOO0O ,OO000000OOOOO0OOO =getIP ()#line:1238
	OO0O0O0O0O0O0OOO0 =[];OO0OOOO00O0OO00O0 =[];OO0O0000000000OOO =[];O000OO0O0OO00O0O0 =[];O000O00O0OOOOOOO0 =[];OO00000O000OOO0O0 =[];OO00O00OOO0OO0O0O =[]#line:1239
	O00OO0O0OO000000O =glob .glob (os .path .join (ADDONS ,'*/'))#line:1240
	for OO00000OO000000O0 in sorted (O00OO0O0OO000000O ,key =lambda OO0OO0OOOOO00O000 :OO0OO0OOOOO00O000 ):#line:1241
		OOOOOOO0OOOO0O0O0 =os .path .split (OO00000OO000000O0 [:-1 ])[1 ]#line:1242
		if OOOOOOO0OOOO0O0O0 =='packages':continue #line:1243
		OO00OO000000O0OOO =os .path .join (OO00000OO000000O0 ,'addon.xml')#line:1244
		if os .path .exists (OO00OO000000O0OOO ):#line:1245
			OO0000O0OO0000OO0 =open (OO00OO000000O0OOO )#line:1246
			OO00O0O000O0O0O00 =OO0000O0OO0000OO0 .read ()#line:1247
			O0O000OO000O0OOO0 =re .compile ("<provides>(.+?)</provides>").findall (OO00O0O000O0O0O00 )#line:1248
			if len (O0O000OO000O0OOO0 )==0 :#line:1249
				if OOOOOOO0OOOO0O0O0 .startswith ('skin'):OO00O00OOO0OO0O0O .append (OOOOOOO0OOOO0O0O0 )#line:1250
				elif OOOOOOO0OOOO0O0O0 .startswith ('repo'):O000O00O0OOOOOOO0 .append (OOOOOOO0OOOO0O0O0 )#line:1251
				else :OO00000O000OOO0O0 .append (OOOOOOO0OOOO0O0O0 )#line:1252
			elif not (O0O000OO000O0OOO0 [0 ]).find ('executable')==-1 :O000OO0O0OO00O0O0 .append (OOOOOOO0OOOO0O0O0 )#line:1253
			elif not (O0O000OO000O0OOO0 [0 ]).find ('video')==-1 :OO0O0000000000OOO .append (OOOOOOO0OOOO0O0O0 )#line:1254
			elif not (O0O000OO000O0OOO0 [0 ]).find ('audio')==-1 :OO0OOOO00O0OO00O0 .append (OOOOOOO0OOOO0O0O0 )#line:1255
			elif not (O0O000OO000O0OOO0 [0 ]).find ('image')==-1 :OO0O0O0O0O0O0OOO0 .append (OOOOOOO0OOOO0O0O0 )#line:1256
	addFile ('[B]Media Center Info:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1257
	addFile ('[COLOR %s]Name:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0OOOO00OO00O [0 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1258
	addFile ('[COLOR %s]Version:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0OOOO00OO00O [1 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1259
	addFile ('[COLOR %s]Platform:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,wiz .platform ().title ()),'',icon =ICONMAINT ,themeit =THEME3 )#line:1260
	addFile ('[COLOR %s]CPU Usage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0OOOO00OO00O [2 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1261
	addFile ('[COLOR %s]Screen Mode:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0OOOO00OO00O [3 ]),'',icon =ICONMAINT ,themeit =THEME3 )#line:1262
	addFile ('[B]Uptime:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1263
	addFile ('[COLOR %s]Current Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0OOOO00OO00O [6 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1264
	addFile ('[COLOR %s]Total Uptime:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0OOOO00OO00O [7 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1265
	addFile ('[B]Local Storage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1266
	addFile ('[COLOR %s]Used Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O0OOO0O0O0O0O000O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1267
	addFile ('[COLOR %s]Free Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO00O0O00O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1268
	addFile ('[COLOR %s]Total Storage:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO000OO0OO0O00OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1269
	addFile ('[B]Ram Usage:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1270
	addFile ('[COLOR %s]Used Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O00OOOOOOOO0OOO00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1271
	addFile ('[COLOR %s]Free Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O0OOOO0O0O00 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1272
	addFile ('[COLOR %s]Total Memory:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOO0000OOO00OO0OO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1273
	addFile ('[B]Network:[/B]','',icon =ICONMAINT ,themeit =THEME2 )#line:1274
	addFile ('[COLOR %s]Local IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0OOOO00OO00O [4 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1275
	addFile ('[COLOR %s]External IP:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,O000OOO0OOO00OOO0 ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1276
	addFile ('[COLOR %s]Provider:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OOOO0O000000OOO0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1277
	addFile ('[COLOR %s]Location:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO000000OOOOO0OOO ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1278
	addFile ('[COLOR %s]MacAddress:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,OO0OO0OOOO00OO00O [5 ]),'',icon =ICONMAINT ,themeit =THEME2 )#line:1279
	OOO0OOOOO00000O0O =len (OO0O0O0O0O0O0OOO0 )+len (OO0OOOO00O0OO00O0 )+len (OO0O0000000000OOO )+len (O000OO0O0OO00O0O0 )+len (OO00000O000OOO0O0 )+len (OO00O00OOO0OO0O0O )+len (O000O00O0OOOOOOO0 )#line:1280
	addFile ('[B]Addons([COLOR %s]%s[/COLOR]):[/B]'%(COLOR1 ,OOO0OOOOO00000O0O ),'',icon =ICONMAINT ,themeit =THEME2 )#line:1281
	addFile ('[COLOR %s]Video Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0000000000OOO ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1282
	addFile ('[COLOR %s]Program Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000OO0O0OO00O0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1283
	addFile ('[COLOR %s]Music Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0OOOO00O0OO00O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1284
	addFile ('[COLOR %s]Picture Addons:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO0O0O0O0O0O0OOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1285
	addFile ('[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (O000O00O0OOOOOOO0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1286
	addFile ('[COLOR %s]Skins:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00O00OOO0OO0O0O ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1287
	addFile ('[COLOR %s]Scripts/Modules:[/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR1 ,COLOR2 ,str (len (OO00000O000OOO0O0 ))),'',icon =ICONMAINT ,themeit =THEME2 )#line:1288
def saveMenu ():#line:1289
	O0000OOO0O0O00000 ='[COLOR green]ON[/COLOR]';O0O00O000000O00O0 ='[COLOR red]OFF[/COLOR]'#line:1290
	O000OOOOO0OO0OO00 ='true'if KEEPTRAKT =='true'else 'false'#line:1291
	OOO0000OO000OOO0O ='true'if KEEPALLUC =='true'else 'false'#line:1292
	OOO0000OO0O0O0OO0 ='true'if KEEPREAL =='true'else 'false'#line:1293
	O00O0OOO000000O0O ='true'if KEEPLOGIN =='true'else 'false'#line:1294
	O00O0000O0OOOO000 ='true'if KEEPSOURCES =='true'else 'false'#line:1295
	OOOOOO0O0O0OO0O0O ='true'if KEEPADVANCED =='true'else 'false'#line:1296
	O0O0O0O0O0OO0000O ='true'if KEEPPROFILES =='true'else 'false'#line:1297
	O0O000000O00O00O0 ='true'if KEEPFAVS =='true'else 'false'#line:1298
	OOOO00OOO00O00OOO ='true'if KEEPREPOS =='true'else 'false'#line:1299
	OO000O00O000OOO00 ='true'if KEEPSUPER =='true'else 'false'#line:1300
	OO00OO0O00OO00OO0 ='true'if KEEPWHITELIST =='true'else 'false'#line:1301
	addFile ('Keep My \'WhiteList\': %s'%OO00OO0O00OO00OO0 .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keepwhitelist',icon =ICONSAVE ,themeit =THEME1 )#line:1302
	if OO00OO0O00OO00OO0 =='true':#line:1303
		addFile ('    Edit My Whitelist','whitelist','edit',icon =ICONSAVE ,themeit =THEME1 )#line:1304
		addFile ('    View My Whitelist','whitelist','view',icon =ICONSAVE ,themeit =THEME1 )#line:1305
		addFile ('    Clear My Whitelist','whitelist','clear',icon =ICONSAVE ,themeit =THEME1 )#line:1306
		addFile ('    Import My Whitelist','whitelist','import',icon =ICONSAVE ,themeit =THEME1 )#line:1307
		addFile ('    Export My Whitelist','whitelist','export',icon =ICONSAVE ,themeit =THEME1 )#line:1308
	addDir ('Keep Favourites','FavsMenu',icon =ICONREAL ,themeit =THEME1 )#line:1309
	addDir ('Keep Trakt Data','trakt',icon =ICONTRAKT ,themeit =THEME1 )#line:1310
	addDir ('Keep Real Debrid','realdebrid',icon =ICONREAL ,themeit =THEME1 )#line:1311
	addDir ('Keep Alluc Login','alluc',icon =ICONLOGIN ,themeit =THEME1 )#line:1312
	addDir ('Keep Login Info','login',icon =ICONLOGIN ,themeit =THEME1 )#line:1313
	addFile ('Import Save Data','managedata','import',icon =ICONSAVE ,themeit =THEME1 )#line:1314
	addFile ('Export Save Data','managedata','export',icon =ICONSAVE ,themeit =THEME1 )#line:1315
	addFile ('- Click to toggle settings -','',themeit =THEME3 )#line:1316
	addFile ('Save Trakt: %s'%O000OOOOO0OO0OO00 .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME1 )#line:1317
	addFile ('Save Real Debrid: %s'%OOO0000OO0O0O0OO0 .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME1 )#line:1318
	addFile ('Save Alluc Login: %s'%OOO0000OO000OOO0O .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keepalluc',icon =ICONREAL ,themeit =THEME1 )#line:1319
	addFile ('Save Login Info: %s'%O00O0OOO000000O0O .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME1 )#line:1320
	addFile ('Keep \'Profiles.xml\': %s'%O0O0O0O0O0OO0000O .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keepprofiles',icon =ICONSAVE ,themeit =THEME1 )#line:1322
	addFile ('Keep \'Advancedsettings.xml\': %s'%OOOOOO0O0O0OO0O0O .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keepadvanced',icon =ICONSAVE ,themeit =THEME1 )#line:1323
	addFile ('Keep \'Favourites.xml\': %s'%O0O000000O00O00O0 .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keepfavourites',icon =ICONSAVE ,themeit =THEME1 )#line:1324
	addFile ('Keep Super Favourites: %s'%OO000O00O000OOO00 .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keepsuper',icon =ICONSAVE ,themeit =THEME1 )#line:1325
	addFile ('Keep Installed Repo\'s: %s'%OOOO00OOO00O00OOO .replace ('true',O0000OOO0O0O00000 ).replace ('false',O0O00O000000O00O0 ),'togglesetting','keeprepos',icon =ICONSAVE ,themeit =THEME1 )#line:1326
	setView ('files','viewType')#line:1327
def FavsMenu ():#line:1328
	OOOO00O00000O00O0 ='[COLOR green]ON[/COLOR]';OOO0OO00OO0OO0O0O ='[COLOR red]OFF[/COLOR]'#line:1329
	O0OOO00OOOO00O00O ='[COLOR green]ON[/COLOR]'if KEEPFAVS =='true'else '[COLOR red]OFF[/COLOR]'#line:1330
	O000O000O0O0O0OOO =str (FAVSsave )if not FAVSsave ==''else 'Favourites hasnt been saved yet.'#line:1331
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1332
	addFile ('Save Favourites: %s'%O0OOO00OOOO00O00O ,'togglesetting','keepfavourites',icon =ICONTRAKT ,themeit =THEME3 )#line:1333
	if KEEPFAVS =='true':addFile ('Last Save: %s'%str (O000O000O0O0O0OOO ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:1334
	if HIDESPACERS =='No':addFile (wiz .sep ('Backs up a copy'),'',themeit =THEME3 )#line:1335
	addFile ('Save Favourites','savefav',icon =ICONTRAKT ,themeit =THEME1 )#line:1336
	addFile ('Recover Favourites','restorefav',icon =ICONTRAKT ,themeit =THEME1 )#line:1337
	addFile ('Clear Favourite Backup','clearfav',icon =ICONTRAKT ,themeit =THEME1 )#line:1338
	setView ('files','viewType')#line:1339
def traktMenu ():#line:1340
	O0OO0O0O00O00O00O ='[COLOR green]ON[/COLOR]'if KEEPTRAKT =='true'else '[COLOR red]OFF[/COLOR]'#line:1341
	OO00000000OO0000O =str (TRAKTSAVE )if not TRAKTSAVE ==''else 'Trakt hasnt been saved yet.'#line:1342
	addFile ('[I]Register FREE Account at http://trakt.tv[/I]','',icon =ICONTRAKT ,themeit =THEME3 )#line:1343
	addFile ('Save Trakt Data: %s'%O0OO0O0O00O00O00O ,'togglesetting','keeptrakt',icon =ICONTRAKT ,themeit =THEME3 )#line:1344
	if KEEPTRAKT =='true':addFile ('Last Save: %s'%str (OO00000000OO0000O ),'',icon =ICONTRAKT ,themeit =THEME3 )#line:1345
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONTRAKT ,themeit =THEME3 )#line:1346
	for O0OO0O0O00O00O00O in traktit .ORDER :#line:1347
		OOOO0O00O0O0O00O0 =TRAKTID [O0OO0O0O00O00O00O ]['name']#line:1348
		OO0OO000000OO0OOO =TRAKTID [O0OO0O0O00O00O00O ]['path']#line:1349
		OO0O00O000OO000OO =TRAKTID [O0OO0O0O00O00O00O ]['saved']#line:1350
		OOOOOO00OO00O0O0O =TRAKTID [O0OO0O0O00O00O00O ]['file']#line:1351
		O00OOO00OO0O0OOOO =wiz .getS (OO0O00O000OO000OO )#line:1352
		O0OO0O00O0O0OOOOO =traktit .traktUser (O0OO0O0O00O00O00O )#line:1353
		O00000000O00O000O =TRAKTID [O0OO0O0O00O00O00O ]['icon']if os .path .exists (OO0OO000000OO0OOO )else ICONTRAKT #line:1354
		OO0OOOO0OOOOOO0OO =TRAKTID [O0OO0O0O00O00O00O ]['fanart']if os .path .exists (OO0OO000000OO0OOO )else FANART #line:1355
		O0O0O00O00OO0OOO0 =createMenu ('saveaddon','Trakt',O0OO0O0O00O00O00O )#line:1356
		O00O0O00OOO00OOOO =createMenu ('save','Trakt',O0OO0O0O00O00O00O )#line:1357
		O0O0O00O00OO0OOO0 .append ((THEME2 %'%s Settings'%OOOO0O00O0O0O00O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=trakt)'%(ADDON_ID ,O0OO0O0O00O00O00O )))#line:1358
		addFile ('[+]-> %s'%OOOO0O00O0O0O00O0 ,'',icon =O00000000O00O000O ,fanart =OO0OOOO0OOOOOO0OO ,themeit =THEME3 )#line:1359
		if not os .path .exists (OO0OO000000OO0OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O00000000O00O000O ,fanart =OO0OOOO0OOOOOO0OO ,menu =O0O0O00O00OO0OOO0 )#line:1360
		elif not O0OO0O00O0O0OOOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authtrakt',O0OO0O0O00O00O00O ,icon =O00000000O00O000O ,fanart =OO0OOOO0OOOOOO0OO ,menu =O0O0O00O00OO0OOO0 )#line:1361
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%O0OO0O00O0O0OOOOO ,'authtrakt',O0OO0O0O00O00O00O ,icon =O00000000O00O000O ,fanart =OO0OOOO0OOOOOO0OO ,menu =O0O0O00O00OO0OOO0 )#line:1362
		if O00OOO00OO0O0OOOO =="":#line:1363
			if os .path .exists (OOOOOO00OO00O0O0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importtrakt',O0OO0O0O00O00O00O ,icon =O00000000O00O000O ,fanart =OO0OOOO0OOOOOO0OO ,menu =O00O0O00OOO00OOOO )#line:1364
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savetrakt',O0OO0O0O00O00O00O ,icon =O00000000O00O000O ,fanart =OO0OOOO0OOOOOO0OO ,menu =O00O0O00OOO00OOOO )#line:1365
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00OOO00OO0O0OOOO ,'',icon =O00000000O00O000O ,fanart =OO0OOOO0OOOOOO0OO ,menu =O00O0O00OOO00OOOO )#line:1366
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1367
	addFile ('Save All Trakt Data','savetrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1368
	addFile ('Recover All Saved Trakt Data','restoretrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1369
	addFile ('Import Trakt Data','importtrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1370
	addFile ('Clear All Saved Trakt Data','cleartrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1371
	addFile ('Clear All Addon Data','addontrakt','all',icon =ICONTRAKT ,themeit =THEME3 )#line:1372
	setView ('files','viewType')#line:1373
def realMenu ():#line:1374
	O00O0OO0OO0000OOO ='[COLOR green]ON[/COLOR]'if KEEPREAL =='true'else '[COLOR red]OFF[/COLOR]'#line:1375
	O0000000O00OOO0OO =str (REALSAVE )if not REALSAVE ==''else 'Real Debrid hasnt been saved yet.'#line:1376
	addFile ('[I]http://real-debrid.com is a PAID service.[/I]','',icon =ICONREAL ,themeit =THEME3 )#line:1377
	addFile ('Save Real Debrid Data: %s'%O00O0OO0OO0000OOO ,'togglesetting','keepdebrid',icon =ICONREAL ,themeit =THEME3 )#line:1378
	if KEEPREAL =='true':addFile ('Last Save: %s'%str (O0000000O00OOO0OO ),'',icon =ICONREAL ,themeit =THEME3 )#line:1379
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONREAL ,themeit =THEME3 )#line:1380
	for O0OOOOO000O0OOO0O in debridit .ORDER :#line:1381
		O00OO0000O000O0O0 =DEBRIDID [O0OOOOO000O0OOO0O ]['name']#line:1382
		O0O0OOOO00OOOOO00 =DEBRIDID [O0OOOOO000O0OOO0O ]['path']#line:1383
		O0O0O0000OOOOOO00 =DEBRIDID [O0OOOOO000O0OOO0O ]['saved']#line:1384
		O0000O00OO0O0O000 =DEBRIDID [O0OOOOO000O0OOO0O ]['file']#line:1385
		O00O000O0000O000O =wiz .getS (O0O0O0000OOOOOO00 )#line:1386
		OOO0O0OO0O00OOOO0 =debridit .debridUser (O0OOOOO000O0OOO0O )#line:1387
		OO00O0OOO000000OO =DEBRIDID [O0OOOOO000O0OOO0O ]['icon']if os .path .exists (O0O0OOOO00OOOOO00 )else ICONREAL #line:1388
		O00OOOOO00000OOO0 =DEBRIDID [O0OOOOO000O0OOO0O ]['fanart']if os .path .exists (O0O0OOOO00OOOOO00 )else FANART #line:1389
		OO0OOO0O00O0O0OOO =createMenu ('saveaddon','Debrid',O0OOOOO000O0OOO0O )#line:1390
		OOO0O0O000OOO00O0 =createMenu ('save','Debrid',O0OOOOO000O0OOO0O )#line:1391
		OO0OOO0O00O0O0OOO .append ((THEME2 %'%s Settings'%O00OO0000O000O0O0 ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=debrid)'%(ADDON_ID ,O0OOOOO000O0OOO0O )))#line:1392
		addFile ('[+]-> %s'%O00OO0000O000O0O0 ,'',icon =OO00O0OOO000000OO ,fanart =O00OOOOO00000OOO0 ,themeit =THEME3 )#line:1393
		if not os .path .exists (O0O0OOOO00OOOOO00 ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OO00O0OOO000000OO ,fanart =O00OOOOO00000OOO0 ,menu =OO0OOO0O00O0O0OOO )#line:1394
		elif not OOO0O0OO0O00OOOO0 :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authdebrid',O0OOOOO000O0OOO0O ,icon =OO00O0OOO000000OO ,fanart =O00OOOOO00000OOO0 ,menu =OO0OOO0O00O0O0OOO )#line:1395
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0O0OO0O00OOOO0 ,'authdebrid',O0OOOOO000O0OOO0O ,icon =OO00O0OOO000000OO ,fanart =O00OOOOO00000OOO0 ,menu =OO0OOO0O00O0O0OOO )#line:1396
		if O00O000O0000O000O =="":#line:1397
			if os .path .exists (O0000O00OO0O0O000 ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importdebrid',O0OOOOO000O0OOO0O ,icon =OO00O0OOO000000OO ,fanart =O00OOOOO00000OOO0 ,menu =OOO0O0O000OOO00O0 )#line:1398
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savedebrid',O0OOOOO000O0OOO0O ,icon =OO00O0OOO000000OO ,fanart =O00OOOOO00000OOO0 ,menu =OOO0O0O000OOO00O0 )#line:1399
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00O000O0000O000O ,'',icon =OO00O0OOO000000OO ,fanart =O00OOOOO00000OOO0 ,menu =OOO0O0O000OOO00O0 )#line:1400
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1401
	addFile ('Save All Real Debrid Data','savedebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1402
	addFile ('Recover All Saved Real Debrid Data','restoredebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1403
	addFile ('Import Real Debrid Data','importdebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1404
	addFile ('Clear All Saved Real Debrid Data','cleardebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1405
	addFile ('Clear All Addon Data','addondebrid','all',icon =ICONREAL ,themeit =THEME3 )#line:1406
	setView ('files','viewType')#line:1407
def allucMenu ():#line:1408
	O00OOOO0OO0OO0OOO ='[COLOR green]ON[/COLOR]'if KEEPALLUC =='true'else '[COLOR red]OFF[/COLOR]'#line:1409
	OOOO0O00OOOO0OO0O =str (ALLUCSAVE )if not ALLUCSAVE ==''else 'Alluc Login hasnt been saved yet.'#line:1410
	addFile ('[I]http://accounts.alluc.com/ is a Free service.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:1411
	addFile ('Save Alluc Login Data: %s'%O00OOOO0OO0OO0OOO ,'togglesetting','keepalluc',icon =ICONLOGIN ,themeit =THEME3 )#line:1412
	if KEEPALLUC =='true':addFile ('Last Save: %s'%str (OOOO0O00OOOO0OO0O ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1413
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1414
	for O00OOOO0OO0OO0OOO in allucit .ORDER :#line:1415
		O0O0OOO0OOOO00OOO =ALLUCID [O00OOOO0OO0OO0OOO ]['name']#line:1416
		OOOOO00000O000OOO =ALLUCID [O00OOOO0OO0OO0OOO ]['path']#line:1417
		OOOOOO00OOOO0OO00 =ALLUCID [O00OOOO0OO0OO0OOO ]['saved']#line:1418
		OOOOOO0OO0O0O0O0O =ALLUCID [O00OOOO0OO0OO0OOO ]['file']#line:1419
		O00OOOO0O0O0OO00O =wiz .getS (OOOOOO00OOOO0OO00 )#line:1420
		OOO0OOO0O000OOO0O =allucit .allucUser (O00OOOO0OO0OO0OOO )#line:1421
		O0O0O00O000OOO000 =ALLUCID [O00OOOO0OO0OO0OOO ]['icon']if os .path .exists (OOOOO00000O000OOO )else ICONLOGIN #line:1422
		OOO000OOO000OO0OO =ALLUCID [O00OOOO0OO0OO0OOO ]['fanart']if os .path .exists (OOOOO00000O000OOO )else FANART #line:1423
		O0O0O0O0O0OOO0OO0 =createMenu ('saveaddon','ALLUC',O00OOOO0OO0OO0OOO )#line:1424
		O00OO0O00O00000O0 =createMenu ('save','Alluc',O00OOOO0OO0OO0OOO )#line:1425
		O0O0O0O0O0OOO0OO0 .append ((THEME2 %'%s Settings'%O0O0OOO0OOOO00OOO ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=alluc)'%(ADDON_ID ,O00OOOO0OO0OO0OOO )))#line:1426
		addFile ('[+]-> %s'%O0O0OOO0OOOO00OOO ,'',icon =O0O0O00O000OOO000 ,fanart =OOO000OOO000OO0OO ,themeit =THEME3 )#line:1427
		if not os .path .exists (OOOOO00000O000OOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =O0O0O00O000OOO000 ,fanart =OOO000OOO000OO0OO ,menu =O0O0O0O0O0OOO0OO0 )#line:1428
		elif not OOO0OOO0O000OOO0O :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authalluc',O00OOOO0OO0OO0OOO ,icon =O0O0O00O000OOO000 ,fanart =OOO000OOO000OO0OO ,menu =O0O0O0O0O0OOO0OO0 )#line:1429
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOO0OOO0O000OOO0O ,'authalluc',O00OOOO0OO0OO0OOO ,icon =O0O0O00O000OOO000 ,fanart =OOO000OOO000OO0OO ,menu =O0O0O0O0O0OOO0OO0 )#line:1430
		if O00OOOO0O0O0OO00O =="":#line:1431
			if os .path .exists (OOOOOO0OO0O0O0O0O ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importalluc',O00OOOO0OO0OO0OOO ,icon =O0O0O00O000OOO000 ,fanart =OOO000OOO000OO0OO ,menu =O00OO0O00O00000O0 )#line:1432
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savealluc',O00OOOO0OO0OO0OOO ,icon =O0O0O00O000OOO000 ,fanart =OOO000OOO000OO0OO ,menu =O00OO0O00O00000O0 )#line:1433
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O00OOOO0O0O0OO00O ,'',icon =O0O0O00O000OOO000 ,fanart =OOO000OOO000OO0OO ,menu =O00OO0O00O00000O0 )#line:1434
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1435
	addFile ('Save All Alluc Login Data','savealluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1436
	addFile ('Recover All Saved Alluc Login Data','restorealluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1437
	addFile ('Import Alluc Login Data','importalluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1438
	addFile ('Clear All Saved Alluc Login Data','clearalluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1439
	addFile ('Clear All Addon Data','addonalluc','all',icon =ICONREAL ,themeit =THEME3 )#line:1440
	setView ('files','viewType')#line:1441
def loginMenu ():#line:1442
	OOOO00OOOOO000OOO ='[COLOR green]ON[/COLOR]'if KEEPLOGIN =='true'else '[COLOR red]OFF[/COLOR]'#line:1443
	OOO00O0OOOO00OOO0 =str (LOGINSAVE )if not LOGINSAVE ==''else 'Login data hasnt been saved yet.'#line:1444
	addFile ('[I]Several of these addons are PAID services.[/I]','',icon =ICONLOGIN ,themeit =THEME3 )#line:1445
	addFile ('Save Login Data: %s'%OOOO00OOOOO000OOO ,'togglesetting','keeplogin',icon =ICONLOGIN ,themeit =THEME3 )#line:1446
	if KEEPLOGIN =='true':addFile ('Last Save: %s'%str (OOO00O0OOOO00OOO0 ),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1447
	if HIDESPACERS =='No':addFile (wiz .sep (),'',icon =ICONLOGIN ,themeit =THEME3 )#line:1448
	for OOOO00OOOOO000OOO in loginit .ORDER :#line:1449
		O00O0000O00OOO00O =LOGINID [OOOO00OOOOO000OOO ]['name']#line:1450
		OO0O00O000O00OOOO =LOGINID [OOOO00OOOOO000OOO ]['path']#line:1451
		O0O00OOO00O00OOOO =LOGINID [OOOO00OOOOO000OOO ]['saved']#line:1452
		O000000O0O000OOOO =LOGINID [OOOO00OOOOO000OOO ]['file']#line:1453
		O0O000OO0OO0OO0OO =wiz .getS (O0O00OOO00O00OOOO )#line:1454
		OOOO0000OO00OOOOO =loginit .loginUser (OOOO00OOOOO000OOO )#line:1455
		OOO0O0O0OOOOOO0O0 =LOGINID [OOOO00OOOOO000OOO ]['icon']if os .path .exists (OO0O00O000O00OOOO )else ICONLOGIN #line:1456
		OOO00O000OOOO00O0 =LOGINID [OOOO00OOOOO000OOO ]['fanart']if os .path .exists (OO0O00O000O00OOOO )else FANART #line:1457
		O00O0OOOOOOO0000O =createMenu ('saveaddon','Login',OOOO00OOOOO000OOO )#line:1458
		O000O00OOO0OO0OO0 =createMenu ('save','Login',OOOO00OOOOO000OOO )#line:1459
		O00O0OOOOOOO0000O .append ((THEME2 %'%s Settings'%O00O0000O00OOO00O ,'RunPlugin(plugin://%s/?mode=opensettings&name=%s&url=login)'%(ADDON_ID ,OOOO00OOOOO000OOO )))#line:1460
		addFile ('[+]-> %s'%O00O0000O00OOO00O ,'',icon =OOO0O0O0OOOOOO0O0 ,fanart =OOO00O000OOOO00O0 ,themeit =THEME3 )#line:1461
		if not os .path .exists (OO0O00O000O00OOOO ):addFile ('[COLOR red]Addon Data: Not Installed[/COLOR]','',icon =OOO0O0O0OOOOOO0O0 ,fanart =OOO00O000OOOO00O0 ,menu =O00O0OOOOOOO0000O )#line:1462
		elif not OOOO0000OO00OOOOO :addFile ('[COLOR red]Addon Data: Not Registered[/COLOR]','authlogin',OOOO00OOOOO000OOO ,icon =OOO0O0O0OOOOOO0O0 ,fanart =OOO00O000OOOO00O0 ,menu =O00O0OOOOOOO0000O )#line:1463
		else :addFile ('[COLOR green]Addon Data: %s[/COLOR]'%OOOO0000OO00OOOOO ,'authlogin',OOOO00OOOOO000OOO ,icon =OOO0O0O0OOOOOO0O0 ,fanart =OOO00O000OOOO00O0 ,menu =O00O0OOOOOOO0000O )#line:1464
		if O0O000OO0OO0OO0OO =="":#line:1465
			if os .path .exists (O000000O0O000OOOO ):addFile ('[COLOR red]Saved Data: Save File Found(Import Data)[/COLOR]','importlogin',OOOO00OOOOO000OOO ,icon =OOO0O0O0OOOOOO0O0 ,fanart =OOO00O000OOOO00O0 ,menu =O000O00OOO0OO0OO0 )#line:1466
			else :addFile ('[COLOR red]Saved Data: Not Saved[/COLOR]','savelogin',OOOO00OOOOO000OOO ,icon =OOO0O0O0OOOOOO0O0 ,fanart =OOO00O000OOOO00O0 ,menu =O000O00OOO0OO0OO0 )#line:1467
		else :addFile ('[COLOR green]Saved Data: %s[/COLOR]'%O0O000OO0OO0OO0OO ,'',icon =OOO0O0O0OOOOOO0O0 ,fanart =OOO00O000OOOO00O0 ,menu =O000O00OOO0OO0OO0 )#line:1468
	if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1469
	addFile ('Save All Login Data','savelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1470
	addFile ('Recover All Saved Login Data','restorelogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1471
	addFile ('Import Login Data','importlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1472
	addFile ('Clear All Saved Login Data','clearlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1473
	addFile ('Clear All Addon Data','addonlogin','all',icon =ICONLOGIN ,themeit =THEME3 )#line:1474
	setView ('files','viewType')#line:1475
def fixUpdate ():#line:1476
	if KODIV <17 :#line:1477
		OOO0OO0O0O0O0000O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:1478
		try :#line:1479
			os .remove (OOO0OO0O0O0O0000O )#line:1480
		except Exception as OO0O00OO0OO00O0O0 :#line:1481
			wiz .log ("Unable to remove %s, Purging DB"%OOO0OO0O0O0O0000O )#line:1482
			wiz .purgeDb (OOO0OO0O0O0O0000O )#line:1483
	else :#line:1484
		if os .path .exists (os .path .join (USERDATA ,'autoexec.py')):#line:1485
			O00OO0OOO0O00O00O =os .path .join (USERDATA ,'autoexec_temp.py')#line:1486
			if os .path .exists (O00OO0OOO0O00O00O ):xbmcvfs .delete (O00OO0OOO0O00O00O )#line:1487
			xbmcvfs .rename (os .path .join (USERDATA ,'autoexec.py'),O00OO0OOO0O00O00O )#line:1488
		xbmcvfs .copy (os .path .join (PLUGIN ,'resources','libs','autoexec.py'),os .path .join (USERDATA ,'autoexec.py'))#line:1489
		OOO0OO0O0O0O0000O =os .path .join (DATABASE ,wiz .latestDB ('Addons'))#line:1490
		try :#line:1491
			os .remove (OOO0OO0O0O0O0000O )#line:1492
		except Exception as OO0O00OO0OO00O0O0 :#line:1493
			wiz .log ("Unable to remove %s, Purging DB"%OOO0OO0O0O0O0000O )#line:1494
			wiz .purgeDb (OOO0OO0O0O0O0000O )#line:1495
		wiz .killxbmc (True )#line:1496
def removeAddonMenu ():#line:1497
	OOO00000O0OOOO00O =glob .glob (os .path .join (ADDONS ,'*/'))#line:1498
	OOOO0OO0000OO0OO0 =[];OO00OO0O0OOOO0OO0 =[]#line:1499
	for OO000000OO0OO0OOO in sorted (OOO00000O0OOOO00O ,key =lambda OOO00OO000OO0000O :OOO00OO000OO0000O ):#line:1500
		O0OOO0O0O0OOO00OO =os .path .split (OO000000OO0OO0OOO [:-1 ])[1 ]#line:1501
		if O0OOO0O0O0OOO00OO in EXCLUDES :continue #line:1502
		elif O0OOO0O0O0OOO00OO in DEFAULTPLUGINS :continue #line:1503
		elif O0OOO0O0O0OOO00OO =='packages':continue #line:1504
		OO00O0O000O0OOOOO =os .path .join (OO000000OO0OO0OOO ,'addon.xml')#line:1505
		if os .path .exists (OO00O0O000O0OOOOO ):#line:1506
			O0OOOO0OOO0OO00OO =open (OO00O0O000O0OOOOO )#line:1507
			O000OO00OO0O00OO0 =O0OOOO0OOO0OO00OO .read ()#line:1508
			O00O000OO000O0OOO =wiz .parseDOM (O000OO00OO0O00OO0 ,'addon',ret ='id')#line:1509
			O0OOO00O0000O00OO =O0OOO0O0O0OOO00OO if len (O00O000OO000O0OOO )==0 else O00O000OO000O0OOO [0 ]#line:1510
			try :#line:1511
				O0000O00OO00O0OOO =xbmcaddon .Addon (id =O0OOO00O0000O00OO )#line:1512
				OOOO0OO0000OO0OO0 .append (O0000O00OO00O0OOO .getAddonInfo ('name'))#line:1513
				OO00OO0O0OOOO0OO0 .append (O0OOO00O0000O00OO )#line:1514
			except :#line:1515
				pass #line:1516
	if len (OOOO0OO0000OO0OO0 )==0 :#line:1517
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין הרחבות להסרה[/COLOR]"%COLOR2 )#line:1518
		return #line:1519
	if KODIV >16 :#line:1520
		O00O00O0OOOOO00OO =DIALOG .multiselect ("%s: בחר את ההרחבות שברצונך להוריד"%ADDONTITLE ,OOOO0OO0000OO0OO0 )#line:1521
	else :#line:1522
		O00O00O0OOOOO00OO =[];OO0000OO00O0OO00O =0 #line:1523
		OO000OOOOO0O000O0 =["-- לחץ כאן להמשך --"]+OOOO0OO0000OO0OO0 #line:1524
		while not OO0000OO00O0OO00O ==-1 :#line:1525
			OO0000OO00O0OO00O =DIALOG .select ("%s: בחר את ההרחבות שברצונך להסיר"%ADDONTITLE ,OO000OOOOO0O000O0 )#line:1526
			if OO0000OO00O0OO00O ==-1 :break #line:1527
			elif OO0000OO00O0OO00O ==0 :break #line:1528
			else :#line:1529
				OOO0O00OOOO000000 =(OO0000OO00O0OO00O -1 )#line:1530
				if OOO0O00OOOO000000 in O00O00O0OOOOO00OO :#line:1531
					O00O00O0OOOOO00OO .remove (OOO0O00OOOO000000 )#line:1532
					OO000OOOOO0O000O0 [OO0000OO00O0OO00O ]=OOOO0OO0000OO0OO0 [OOO0O00OOOO000000 ]#line:1533
				else :#line:1534
					O00O00O0OOOOO00OO .append (OOO0O00OOOO000000 )#line:1535
					OO000OOOOO0O000O0 [OO0000OO00O0OO00O ]="[B][COLOR %s]%s[/COLOR][/B]"%(COLOR1 ,OOOO0OO0000OO0OO0 [OOO0O00OOOO000000 ])#line:1536
	if O00O00O0OOOOO00OO ==None :return #line:1537
	if len (O00O00O0OOOOO00OO )>0 :#line:1538
		wiz .addonUpdates ('set')#line:1539
		for OO0O0OOO000O00000 in O00O00O0OOOOO00OO :#line:1540
			removeAddon (OO00OO0O0OOOO0OO0 [OO0O0OOO000O00000 ],OOOO0OO0000OO0OO0 [OO0O0OOO000O00000 ],True )#line:1541
		xbmc .sleep (500 )#line:1542
		if INSTALLMETHOD ==1 :O00OO0OO000O0OOOO =1 #line:1543
		elif INSTALLMETHOD ==2 :O00OO0OO000O0OOOO =0 #line:1544
		else :O00OO0OO000O0OOOO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]פרופיל מחדש? [COLOR %s]לטעון [/COLOR] לסגור את הקודי או  [COLOR %s]האם ברצונך [/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),nolabel ="[B][COLOR red]סגור קודי[/COLOR][/B]")#line:1545
		if O00OO0OO000O0OOOO ==1 :wiz .reloadFix ('remove addon')#line:1546
		else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:1547
def removeAddonDataMenu ():#line:1548
	if os .path .exists (ADDOND ):#line:1549
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data','removedata','all',themeit =THEME2 )#line:1550
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Addon_Data for Uninstalled Addons','removedata','uninstalled',themeit =THEME2 )#line:1551
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] All Empty Folders in Addon_Data','removedata','empty',themeit =THEME2 )#line:1552
		addFile ('[COLOR red][B][REMOVE][/B][/COLOR] %s Addon_Data'%ADDONTITLE ,'resetaddon',themeit =THEME2 )#line:1553
		if HIDESPACERS =='No':addFile (wiz .sep (),'',themeit =THEME3 )#line:1554
		OOOO0O0O0O0OOOO0O =glob .glob (os .path .join (ADDOND ,'*/'))#line:1555
		for OOO0O0O0OOO0O000O in sorted (OOOO0O0O0O0OOOO0O ,key =lambda O0O00OOOOO0O0000O :O0O00OOOOO0O0000O ):#line:1556
			OO0OOO00OOO000O0O =OOO0O0O0OOO0O000O .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:1557
			OOO00O00O0OO0000O =os .path .join (OOO0O0O0OOO0O000O .replace (ADDOND ,ADDONS ),'icon.png')#line:1558
			O00000OOO000O000O =os .path .join (OOO0O0O0OOO0O000O .replace (ADDOND ,ADDONS ),'fanart.png')#line:1559
			OO000OOO00OO0OO00 =OO0OOO00OOO000O0O #line:1560
			OOO0OO0O0OOO0OO0O ={'audio.':'[COLOR orange][AUDIO] [/COLOR]','metadata.':'[COLOR cyan][METADATA] [/COLOR]','module.':'[COLOR orange][MODULE] [/COLOR]','plugin.':'[COLOR blue][PLUGIN] [/COLOR]','program.':'[COLOR orange][PROGRAM] [/COLOR]','repository.':'[COLOR gold][REPO] [/COLOR]','script.':'[COLOR green][SCRIPT] [/COLOR]','service.':'[COLOR green][SERVICE] [/COLOR]','skin.':'[COLOR dodgerblue][SKIN] [/COLOR]','video.':'[COLOR orange][VIDEO] [/COLOR]','weather.':'[COLOR yellow][WEATHER] [/COLOR]'}#line:1561
			for O0000OOO00OO000OO in OOO0OO0O0OOO0OO0O :#line:1562
				OO000OOO00OO0OO00 =OO000OOO00OO0OO00 .replace (O0000OOO00OO000OO ,OOO0OO0O0OOO0OO0O [O0000OOO00OO000OO ])#line:1563
			if OO0OOO00OOO000O0O in EXCLUDES :OO000OOO00OO0OO00 ='[COLOR green][B][PROTECTED][/B][/COLOR] %s'%OO000OOO00OO0OO00 #line:1564
			else :OO000OOO00OO0OO00 ='[COLOR red][B][REMOVE][/B][/COLOR] %s'%OO000OOO00OO0OO00 #line:1565
			addFile (' %s'%OO000OOO00OO0OO00 ,'removedata',OO0OOO00OOO000O0O ,icon =OOO00O00O0OO0000O ,fanart =O00000OOO000O000O ,themeit =THEME2 )#line:1566
	else :#line:1567
		addFile ('No Addon data folder found.','',themeit =THEME3 )#line:1568
	setView ('files','viewType')#line:1569
def enableAddons ():#line:1570
	addFile ("[I][B][COLOR red]!!Notice: Disabling Some Addons Can Cause Issues!![/COLOR][/B][/I]",'',icon =ICONMAINT )#line:1571
	OO00OOO0OOO0O0O0O =glob .glob (os .path .join (ADDONS ,'*/'))#line:1572
	O00OO0000O0OOOOO0 =0 #line:1573
	for OO00O0OOOOO00O00O in sorted (OO00OOO0OOO0O0O0O ,key =lambda O0OOO0OO00O0000O0 :O0OOO0OO00O0000O0 ):#line:1574
		OO0OOO0O000O0OO0O =os .path .split (OO00O0OOOOO00O00O [:-1 ])[1 ]#line:1575
		if OO0OOO0O000O0OO0O in EXCLUDES :continue #line:1576
		if OO0OOO0O000O0OO0O in DEFAULTPLUGINS :continue #line:1577
		O00O000000O00O0OO =os .path .join (OO00O0OOOOO00O00O ,'addon.xml')#line:1578
		if os .path .exists (O00O000000O00O0OO ):#line:1579
			O00OO0000O0OOOOO0 +=1 #line:1580
			OO00OOO0OOO0O0O0O =OO00O0OOOOO00O00O .replace (ADDONS ,'')[1 :-1 ]#line:1581
			O0000000OO0O00O0O =open (O00O000000O00O0OO )#line:1582
			OOOO00O0OO000000O =O0000000OO0O00O0O .read ().replace ('\n','').replace ('\r','').replace ('\t','')#line:1583
			OOO0O0O000O00OO00 =wiz .parseDOM (OOOO00O0OO000000O ,'addon',ret ='id')#line:1584
			OO0O0OO0OO0O0O00O =wiz .parseDOM (OOOO00O0OO000000O ,'addon',ret ='name')#line:1585
			try :#line:1586
				O0O00O0O0O0O0O0O0 =OOO0O0O000O00OO00 [0 ]#line:1587
				OO00O0OO000O000OO =OO0O0OO0OO0O0O00O [0 ]#line:1588
			except :#line:1589
				continue #line:1590
			try :#line:1591
				O000000O00000O0OO =xbmcaddon .Addon (id =O0O00O0O0O0O0O0O0 )#line:1592
				OO000OOO0000O0O0O ="[COLOR green][Enabled][/COLOR]"#line:1593
				O0000OOO00O0OOOOO ="false"#line:1594
			except :#line:1595
				OO000OOO0000O0O0O ="[COLOR red][Disabled][/COLOR]"#line:1596
				O0000OOO00O0OOOOO ="true"#line:1597
				pass #line:1598
			OOOO0O0O0O0O000OO =os .path .join (OO00O0OOOOO00O00O ,'icon.png')if os .path .exists (os .path .join (OO00O0OOOOO00O00O ,'icon.png'))else ICON #line:1599
			O0O0OOOOO0O00OOOO =os .path .join (OO00O0OOOOO00O00O ,'fanart.jpg')if os .path .exists (os .path .join (OO00O0OOOOO00O00O ,'fanart.jpg'))else FANART #line:1600
			addFile ("%s %s"%(OO000OOO0000O0O0O ,OO00O0OO000O000OO ),'toggleaddon',OO00OOO0OOO0O0O0O ,O0000OOO00O0OOOOO ,icon =OOOO0O0O0O0O000OO ,fanart =O0O0OOOOO0O00OOOO )#line:1601
			O0000000OO0O00O0O .close ()#line:1602
	if O00OO0000O0OOOOO0 ==0 :#line:1603
		addFile ("No Addons Found to Enable or Disable.",'',icon =ICONMAINT )#line:1604
	setView ('files','viewType')#line:1605
def changeFeq ():#line:1606
	O00000OO0O00O000O =['Every Startup','Every Day','Every Three Days','Every Weekly']#line:1607
	O00O0OO0OOOOO000O =DIALOG .select ("[COLOR %s]How often would you list to Auto Clean on Startup?[/COLOR]"%COLOR2 ,O00000OO0O00O000O )#line:1608
	if not O00O0OO0OOOOO000O ==-1 :#line:1609
		wiz .setS ('autocleanfeq',str (O00O0OO0OOOOO000O ))#line:1610
		wiz .LogNotify ('[COLOR %s]Auto Clean Up[/COLOR]'%COLOR1 ,'[COLOR %s]Fequency Now %s[/COLOR]'%(COLOR2 ,O00000OO0O00O000O [O00O0OO0OOOOO000O ]))#line:1611
def developer ():#line:1612
	addFile ('Skin Swap Popup','sswap',themeit =THEME1 )#line:1613
	addFile ('Create QR Code','createqr',themeit =THEME1 )#line:1614
	addFile ('Test Notifications','testnotify',themeit =THEME1 )#line:1615
	addFile ('Test Update','testupdate',themeit =THEME1 )#line:1616
	addFile ('Test First Run','testfirst',themeit =THEME1 )#line:1617
	addFile ('Test First Run Settings','testfirstrun',themeit =THEME1 )#line:1618
	addFile ('Test Auto ADV Settings','autoadvanced',themeit =THEME1 )#line:1619
	setView ('files','viewType')#line:1620
def buildWizard (O0O0OOOO0000O0OOO ,O00000O0OO0O0OOO0 ,theme =None ,over =False ):#line:1624
	if over ==False :#line:1627
		OOOOOO0O00O0OO00O =wiz .checkBuild (O0O0OOOO0000O0OOO ,'url')#line:1628
		if OOOOOO0O00O0OO00O ==False :#line:1629
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]אין אפשרות למצא בילד מותקן [/COLOR]"%COLOR2 )#line:1630
			return #line:1631
		OO00OOOO0OOO00OOO =wiz .workingURL (OOOOOO0O00O0OO00O )#line:1632
		if OO00OOOO0OOO00OOO ==False :#line:1633
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Build Zip Error: %s[/COLOR]"%(COLOR2 ,OO00OOOO0OOO00OOO ))#line:1634
			return #line:1635
	if O00000O0OO0O0OOO0 =='gui':#line:1636
		if O0O0OOOO0000O0OOO ==BUILDNAME :#line:1637
			if over ==True :OO0O000OO0OOOOO0O =1 #line:1638
			else :OO0O000OO0OOOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s] האם לבצע תהליך עדכון מהיר עבור: '%COLOR2 ,'[COLOR %s]%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0O0OOOO0000O0OOO ),nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]בצע עדכון[/COLOR][/B]')#line:1639
		else :#line:1640
			OO0O000OO0OOOOO0O =DIALOG .yesno ("%s - [COLOR red]WARNING!![/COLOR]"%ADDONTITLE ,"[COLOR %s][COLOR %s]%s[/COLOR] community build is not currently installed."%(COLOR2 ,COLOR1 ,O0O0OOOO0000O0OOO ),"האם לאשר למרות זאת שינוי הממשק?[/COLOR]",nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]Apply Fix[/COLOR][/B]')#line:1641
		if OO0O000OO0OOOOO0O :#line:1642
			O0O000O00O0000O0O =wiz .checkBuild (O0O0OOOO0000O0OOO ,'gui')#line:1643
			OO000OO0OOO0O0O00 =O0O0OOOO0000O0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:1644
			if not wiz .workingURL (O0O000O00O0000O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:1645
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1646
			DP .create (ADDONTITLE ,'[COLOR %s][B] הורדת עדכון [/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOOO0000O0OOO ),'','Please Wait')#line:1647
			OOO0O00OO0OOO00O0 =os .path .join (PACKAGES ,'%s_guisettings.zip'%OO000OO0OOO0O0O00 )#line:1648
			try :os .remove (OOO0O00OO0OOO00O0 )#line:1649
			except :pass #line:1650
			downloader .download (O0O000O00O0000O0O ,OOO0O00OO0OOO00O0 ,DP )#line:1651
			xbmc .sleep (500 )#line:1652
			OOOOO00OOOO00O0OO ='[COLOR %s][B] התקנה [/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOOO0000O0OOO )#line:1653
			DP .update (0 ,OOOOO00OOOO00O0OO ,'','אנא המתן')#line:1654
			extract .all (OOO0O00OO0OOO00O0 ,USERDATA ,DP ,title =OOOOO00OOOO00O0OO )#line:1655
			DP .update (0 ,OOOOO00OOOO00O0OO ,'','אנא המתן')#line:1656
			extract .all (OOO0O00OO0OOO00O0 ,HOME ,DP ,title =OOOOO00OOOO00O0OO )#line:1657
			DP .close ()#line:1658
			wiz .defaultSkin ()#line:1659
			wiz .lookandFeelData ('save')#line:1660
			wiz .kodi17Fix ()#line:1662
			if INSTALLMETHOD ==1 :O0OOO0O000000O00O =1 #line:1663
			elif INSTALLMETHOD ==2 :O0OOO0O000000O00O =0 #line:1664
			else :DP .close ()#line:1665
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]עדכון מהיר בוצע בהצלחה![/COLOR]'%COLOR2 )#line:1666
		else :#line:1667
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]GuiFix: Cancelled![/COLOR]'%COLOR2 )#line:1668
	elif O00000O0OO0O0OOO0 =='fresh':#line:1669
		freshStart (O0O0OOOO0000O0OOO )#line:1670
	elif O00000O0OO0O0OOO0 =='normal':#line:1671
		if url =='normal':#line:1672
			if KEEPTRAKT =='true':#line:1673
				traktit .autoUpdate ('all')#line:1674
				wiz .setS ('traktlastsave',str (THREEDAYS ))#line:1675
			if KEEPREAL =='true':#line:1676
				debridit .autoUpdate ('all')#line:1677
				wiz .setS ('debridlastsave',str (THREEDAYS ))#line:1678
			if KEEPALLUC =='true':#line:1679
				allucit .autoUpdate ('all')#line:1680
				wiz .setS ('allucnlastsave',str (THREEDAYS ))#line:1681
			if KEEPLOGIN =='true':#line:1682
				loginit .autoUpdate ('all')#line:1683
				wiz .setS ('loginlastsave',str (THREEDAYS ))#line:1684
		O0O0O0O00O0O000OO =int (KODIV );OOO0OO00OOOOO0000 =int (float (wiz .checkBuild (O0O0OOOO0000O0OOO ,'kodi')))#line:1685
		if not O0O0O0O00O0O000OO ==OOO0OO00OOOOO0000 :#line:1686
			if O0O0O0O00O0O000OO ==16 and OOO0OO00OOOOO0000 <=15 :OO00OO0OO0O0O000O =False #line:1687
			else :OO00OO0OO0O0O000O =True #line:1688
		else :OO00OO0OO0O0O000O =False #line:1689
		if OO00OO0OO0O0O000O ==True :#line:1690
			O0O000OO00OOOO0OO =DIALOG .yesno ("%s - [COLOR red]WARNING!![/COLOR]"%ADDONTITLE ,'[COLOR %s]There is a chance that the skin will not appear correctly'%COLOR2 ,'When installing a %s build on a Kodi %s install'%(wiz .checkBuild (O0O0OOOO0000O0OOO ,'kodi'),KODIV ),'Would you still like to install: [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0O0OOOO0000O0OOO ,wiz .checkBuild (O0O0OOOO0000O0OOO ,'version')),nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]Yes, Install[/COLOR][/B]')#line:1691
		else :#line:1692
			if not over ==False :O0O000OO00OOOO0OO =1 #line:1693
			else :O0O000OO00OOOO0OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם ברצונך להוריד ולהתקין את: '%COLOR2 ,'[COLOR %s]%s v%s[/COLOR] ?[/COLOR]'%(COLOR1 ,O0O0OOOO0000O0OOO ,wiz .checkBuild (O0O0OOOO0000O0OOO ,'version')),nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]כן, התקן[/COLOR][/B]')#line:1694
		if O0O000OO00OOOO0OO :#line:1695
			wiz .clearS ('build')#line:1696
			O0O000O00O0000O0O =wiz .checkBuild (O0O0OOOO0000O0OOO ,'url')#line:1717
			OO000OO0OOO0O0O00 =O0O0OOOO0000O0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:1718
			if not wiz .workingURL (O0O000O00O0000O0O )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Invalid Zip Url![/COLOR]'%COLOR2 );return #line:1719
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1720
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOOO0000O0OOO ,wiz .checkBuild (O0O0OOOO0000O0OOO ,'version')),'','Please Wait')#line:1721
			OOO0O00OO0OOO00O0 =os .path .join (PACKAGES ,'%s.zip'%OO000OO0OOO0O0O00 )#line:1722
			try :os .remove (OOO0O00OO0OOO00O0 )#line:1723
			except :pass #line:1724
			downloader .download (O0O000O00O0000O0O ,OOO0O00OO0OOO00O0 ,DP )#line:1725
			xbmc .sleep (500 )#line:1726
			OOOOO00OOOO00O0OO ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOOO0000O0OOO ,wiz .checkBuild (O0O0OOOO0000O0OOO ,'version'))#line:1727
			DP .update (0 ,OOOOO00OOOO00O0OO ,'','Please Wait')#line:1728
			O000O00000OOOOO00 ,OO0O00000OOO0OO00 ,O0OO0O00OO00OOOO0 =extract .all (OOO0O00OO0OOO00O0 ,HOME ,DP ,title =OOOOO00OOOO00O0OO )#line:1729
			if int (float (O000O00000OOOOO00 ))>0 :#line:1730
				wiz .fixmetas ()#line:1731
				wiz .lookandFeelData ('save')#line:1732
				wiz .defaultSkin ()#line:1733
				wiz .setS ('buildname',O0O0OOOO0000O0OOO )#line:1735
				wiz .setS ('buildversion',wiz .checkBuild (O0O0OOOO0000O0OOO ,'version'))#line:1736
				wiz .setS ('buildtheme','')#line:1737
				wiz .setS ('latestversion',wiz .checkBuild (O0O0OOOO0000O0OOO ,'version'))#line:1738
				wiz .setS ('lastbuildcheck',str (NEXTCHECK ))#line:1739
				wiz .setS ('installed','true')#line:1740
				wiz .setS ('extract',str (O000O00000OOOOO00 ))#line:1741
				wiz .setS ('errors',str (OO0O00000OOO0OO00 ))#line:1742
				wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O000O00000OOOOO00 ,OO0O00000OOO0OO00 ))#line:1743
				try :os .remove (OOO0O00OO0OOO00O0 )#line:1744
				except :pass #line:1745
				if int (float (OO0O00000OOO0OO00 ))>0 :#line:1746
					OO0O000OO0OOOOO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s v%s[/COLOR]'%(COLOR2 ,COLOR1 ,O0O0OOOO0000O0OOO ,wiz .checkBuild (O0O0OOOO0000O0OOO ,'version')),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O000O00000OOOOO00 ,'%',COLOR1 ,OO0O00000OOO0OO00 ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:1747
					if OO0O000OO0OOOOO0O :#line:1748
						if isinstance (OO0O00000OOO0OO00 ,unicode ):#line:1749
							O0OO0O00OO00OOOO0 =O0OO0O00OO00OOOO0 .encode ('utf-8')#line:1750
						wiz .TextBox (ADDONTITLE ,O0OO0O00OO00OOOO0 )#line:1751
				DP .close ()#line:1752
				OOOOO0O0OOO00OOO0 =wiz .themeCount (O0O0OOOO0000O0OOO )#line:1753
				if not OOOOO0O0OOO00OOO0 ==False :#line:1754
					buildWizard (O0O0OOOO0000O0OOO ,'theme')#line:1755
				if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:1756
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]ההתקנה הסתיימה בהצלחה עליך ללחוץ על כפתור ה OK על מנת לסיים את ההתקנה.[/COLOR]"%COLOR2 );wiz .killxbmc ('true')#line:1757
			else :#line:1758
				if isinstance (OO0O00000OOO0OO00 ,unicode ):#line:1759
					O0OO0O00OO00OOOO0 =O0OO0O00OO00OOOO0 .encode ('utf-8')#line:1760
				wiz .TextBox ("%s: Error Installing Build"%ADDONTITLE ,O0OO0O00OO00OOOO0 )#line:1761
		else :#line:1762
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Build Install: Cancelled![/COLOR]'%COLOR2 )#line:1763
	elif O00000O0OO0O0OOO0 =='theme':#line:1764
		if theme ==None :#line:1765
			OOOOO0O0OOO00OOO0 =wiz .checkBuild (O0O0OOOO0000O0OOO ,'theme')#line:1766
			OOOO0000O00OOO0O0 =[]#line:1767
			if not OOOOO0O0OOO00OOO0 =='http://'and wiz .workingURL (OOOOO0O0OOO00OOO0 )==True :#line:1768
				OOOO0000O00OOO0O0 =wiz .themeCount (O0O0OOOO0000O0OOO ,False )#line:1769
				if len (OOOO0000O00OOO0O0 )>0 :#line:1770
					if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]The Build [COLOR %s]%s[/COLOR] comes with [COLOR %s]%s[/COLOR] different themes"%(COLOR2 ,COLOR1 ,O0O0OOOO0000O0OOO ,COLOR1 ,len (OOOO0000O00OOO0O0 )),"Would you like to install one now?[/COLOR]",yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]"):#line:1771
						wiz .log ("Theme List: %s "%str (OOOO0000O00OOO0O0 ))#line:1772
						O0O000OO00OO0OOOO =DIALOG .select (ADDONTITLE ,OOOO0000O00OOO0O0 )#line:1773
						wiz .log ("Theme install selected: %s"%O0O000OO00OO0OOOO )#line:1774
						if not O0O000OO00OO0OOOO ==-1 :theme =OOOO0000O00OOO0O0 [O0O000OO00OO0OOOO ];OOOOOOO0O0O0000OO =True #line:1775
						else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:1776
					else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 );return #line:1777
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: לא נמצא ![/COLOR]'%COLOR2 )#line:1778
		else :OOOOOOO0O0O0000OO =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the theme:'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,theme ),'for [COLOR %s]%s v%s[/COLOR]?[/COLOR]'%(COLOR1 ,O0O0OOOO0000O0OOO ,wiz .checkBuild (O0O0OOOO0000O0OOO ,'version')),yeslabel ="[B][COLOR green]Install Theme[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel Themes[/COLOR][/B]")#line:1779
		if OOOOOOO0O0O0000OO :#line:1780
			O0O0O0000OOOO0O00 =wiz .checkTheme (O0O0OOOO0000O0OOO ,theme ,'url')#line:1781
			OO000OO0OOO0O0O00 =O0O0OOOO0000O0OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:1782
			if not wiz .workingURL (O0O0O0000OOOO0O00 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Invalid Zip Url![/COLOR]'%COLOR2 );return False #line:1783
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1784
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme ),'','Please Wait')#line:1785
			OOO0O00OO0OOO00O0 =os .path .join (PACKAGES ,'%s.zip'%OO000OO0OOO0O0O00 )#line:1786
			try :os .remove (OOO0O00OO0OOO00O0 )#line:1787
			except :pass #line:1788
			downloader .download (O0O0O0000OOOO0O00 ,OOO0O00OO0OOO00O0 ,DP )#line:1789
			xbmc .sleep (500 )#line:1790
			DP .update (0 ,"","Installing %s "%O0O0OOOO0000O0OOO )#line:1791
			OO000000O0OO0OOOO =False #line:1792
			if url not in ["fresh","normal"]:#line:1793
				OO000000O0OO0OOOO =testTheme (OOO0O00OO0OOO00O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estuary']else False #line:1794
				O000000000OOOO00O =testGui (OOO0O00OO0OOO00O0 )if not wiz .currSkin ()in ['skin.confluence','skin.estuary']else False #line:1795
				if OO000000O0OO0OOOO ==True :#line:1796
					wiz .lookandFeelData ('save')#line:1797
					O00OOOOOOOOO0O000 =wiz .skinToDefault ('Theme Install')#line:1798
					if O00OOOOOOOOO0O000 ==False :return False #line:1799
					xbmc .sleep (500 )#line:1800
			OOOOO00OOOO00O0OO ='[COLOR %s][B]Installing Theme:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,theme )#line:1801
			DP .update (0 ,OOOOO00OOOO00O0OO ,'','Please Wait')#line:1802
			O000O00000OOOOO00 ,OO0O00000OOO0OO00 ,O0OO0O00OO00OOOO0 =extract .all (OOO0O00OO0OOO00O0 ,HOME ,DP ,title =OOOOO00OOOO00O0OO )#line:1803
			wiz .setS ('buildtheme',theme )#line:1804
			wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O000O00000OOOOO00 ,OO0O00000OOO0OO00 ))#line:1805
			DP .close ()#line:1806
			if url not in ["fresh","normal"]:#line:1807
				wiz .forceUpdate ()#line:1808
				if KODIV >=17 :#line:1809
					O00OOO0000OO0O00O =grabAddons (OOO0O00OO0OOO00O0 )#line:1810
					wiz .addonDatabase (O00OOO0000OO0O00O ,1 ,True )#line:1811
				if O000000000OOOO00O ==True :#line:1812
					wiz .lookandFeelData ('save')#line:1813
					wiz .defaultSkin ()#line:1814
					OOO000OOOOOOOOOOO =wiz .getS ('defaultskin')#line:1815
					wiz .swapSkins (OOO000OOOOOOOOOOO ,"Theme Installer")#line:1816
					wiz .lookandFeelData ('restore')#line:1817
				elif OO000000O0OO0OOOO ==True :#line:1818
					O000O000O00OOO0OO =wiz .swapSkins (OOO000OOOOOOOOOOO ,'Theme Install')#line:1819
					if O000O000O00OOO0OO ==False :return #line:1820
					wiz .lookandFeelData ('restore')#line:1821
				else :#line:1822
					wiz .ebi ("ReloadSkin()")#line:1823
					xbmc .sleep (1000 )#line:1824
					wiz .ebi ("Container.Refresh")#line:1825
		else :#line:1826
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Theme Install: Cancelled![/COLOR]'%COLOR2 )#line:1827
def thirdPartyInstall (OO0OOO0OOOO000O00 ,OO0OOO0O00O0O00OO ):#line:1828
	if not wiz .workingURL (OO0OOO0O00O0O00OO ):#line:1829
		LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Invalid URL for Build[/COLOR]'%COLOR2 );return #line:1830
	O000OOOOOOOO0O000 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to preform a [COLOR %s]Fresh Install[/COLOR] or [COLOR %s]Normal Install[/COLOR] for:[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO0OOO0OOOO000O00 ),yeslabel ="[B][COLOR green]Fresh Install[/COLOR][/B]",nolabel ="[B][COLOR red]Normal Install[/COLOR][/B]")#line:1831
	if O000OOOOOOOO0O000 ==1 :#line:1832
		freshStart ('third',True )#line:1833
	wiz .clearS ('build')#line:1834
	O00O00OOO000O00OO =OO0OOO0OOOO000O00 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|','')#line:1835
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1836
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0OOOO000O00 ),'','Please Wait')#line:1837
	O0OOO0OOO0O0O000O =os .path .join (PACKAGES ,'%s.zip'%O00O00OOO000O00OO )#line:1838
	try :os .remove (O0OOO0OOO0O0O000O )#line:1839
	except :pass #line:1840
	downloader .download (OO0OOO0O00O0O00OO ,O0OOO0OOO0O0O000O ,DP )#line:1841
	xbmc .sleep (500 )#line:1842
	OOOOO0OO0OOO00O00 ='[COLOR %s][B]Installing:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0OOOO000O00 )#line:1843
	DP .update (0 ,OOOOO0OO0OOO00O00 ,'','Please Wait')#line:1844
	O0O0000O00O0O0OO0 ,OOOO0OO000000O00O ,OOO0O0O00OOOOOO00 =extract .all (O0OOO0OOO0O0O000O ,HOME ,DP ,title =OOOOO0OO0OOO00O00 )#line:1845
	if int (float (O0O0000O00O0O0OO0 ))>0 :#line:1846
		wiz .fixmetas ()#line:1847
		wiz .lookandFeelData ('save')#line:1848
		wiz .defaultSkin ()#line:1849
		wiz .setS ('installed','true')#line:1851
		wiz .setS ('extract',str (O0O0000O00O0O0OO0 ))#line:1852
		wiz .setS ('errors',str (OOOO0OO000000O00O ))#line:1853
		wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O0O0000O00O0O0OO0 ,OOOO0OO000000O00O ))#line:1854
		try :os .remove (O0OOO0OOO0O0O000O )#line:1855
		except :pass #line:1856
		if int (float (OOOO0OO000000O00O ))>0 :#line:1857
			OOO000OOOO0O0OO0O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0OOO0OOOO000O00 ),'Completed: [COLOR %s]%s%s[/COLOR] [Errors:[COLOR %s]%s[/COLOR]]'%(COLOR1 ,O0O0000O00O0O0OO0 ,'%',COLOR1 ,OOOO0OO000000O00O ),'Would you like to view the errors?[/COLOR]',nolabel ='[B][COLOR red]No Thanks[/COLOR][/B]',yeslabel ='[B][COLOR green]View Errors[/COLOR][/B]')#line:1858
			if OOO000OOOO0O0OO0O :#line:1859
				if isinstance (OOOO0OO000000O00O ,unicode ):#line:1860
					OOO0O0O00OOOOOO00 =OOO0O0O00OOOOOO00 .encode ('utf-8')#line:1861
				wiz .TextBox (ADDONTITLE ,OOO0O0O00OOOOOO00 )#line:1862
	DP .close ()#line:1863
	if KODIV >=17 :wiz .addonDatabase (ADDON_ID ,1 )#line:1864
	if INSTALLMETHOD ==1 :O00OOO000OOO0O00O =1 #line:1865
	elif INSTALLMETHOD ==2 :O00OOO000OOO0O00O =0 #line:1866
	else :O00OOO000OOO0O00O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to [COLOR %s]Force close[/COLOR] kodi or [COLOR %s]Reload Profile[/COLOR]?[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR green]Reload Profile[/COLOR][/B]",nolabel ="[B][COLOR red]Force Close[/COLOR][/B]")#line:1867
	if O00OOO000OOO0O00O ==1 :wiz .reloadFix ()#line:1868
	else :wiz .killxbmc (True )#line:1869
def testTheme (OOOOOO0OOO0OOOOOO ):#line:1870
	OOOO0O00O0OOOOO00 =zipfile .ZipFile (OOOOOO0OOO0OOOOOO )#line:1871
	for O00000000O0O0OO00 in OOOO0O00O0OOOOO00 .infolist ():#line:1872
		wiz .log (str (O00000000O0O0OO00 .filename ))#line:1873
		if '/settings.xml'in O00000000O0O0OO00 .filename :#line:1874
			return True #line:1875
	return False #line:1876
def testGui (OO0OO0O0O0OO0OOOO ):#line:1877
	O0O00OO00OO00OO0O =zipfile .ZipFile (OO0OO0O0O0OO0OOOO )#line:1878
	for O000OO0O0000OO000 in O0O00OO00OO00OO0O .infolist ():#line:1879
		if '/guisettings.xml'in O000OO0O0000OO000 .filename :#line:1880
			return True #line:1881
	return False #line:1882
def grabAddons (OO0O0O0OOOOO0OO00 ):#line:1883
	O00OO000OOO0O0O0O =zipfile .ZipFile (OO0O0O0OOOOO0OO00 )#line:1884
	OO0OO0O00000OO0O0 =[]#line:1885
	for OOO0O00OOOOOO0O0O in O00OO000OOO0O0O0O .infolist ():#line:1886
		if str (OOO0O00OOOOOO0O0O .filename ).find ('addon.xml')==-1 :continue #line:1887
		O0OO0OO000OOOOO0O =str (OOO0O00OOOOOO0O0O .filename ).split ('/')#line:1888
		if not O0OO0OO000OOOOO0O [-2 ]in OO0OO0O00000OO0O0 :#line:1889
			OO0OO0O00000OO0O0 .append (O0OO0OO000OOOOO0O [-2 ])#line:1890
	return OO0OO0O00000OO0O0 #line:1891
def apkInstaller (OO00O0O0OOO0O00O0 ,OOO00O0OOO00O0OOO ):#line:1892
	wiz .log (OO00O0O0OOO0O00O0 )#line:1893
	wiz .log (OOO00O0OOO00O0OOO )#line:1894
	if wiz .platform ()=='android'or DEVELOPER =='true':#line:1895
		O0OO0O0O0OO00OO00 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to download and install:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O0O0OOO0O00O0 ),yeslabel ="[B][COLOR green]Download[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:1896
		if not O0OO0O0O0OO00OO00 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:1897
		OO0O000OOO00O0OO0 =OO00O0O0OOO0O00O0 #line:1898
		if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1899
		if not wiz .workingURL (OOO00O0OOO00O0OOO )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Apk Url![/COLOR]'%COLOR2 );return #line:1900
		DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OO0O000OOO00O0OO0 ),'','Please Wait')#line:1901
		OOOOO00OO0000O0OO =os .path .join (PACKAGES ,"%s.apk"%OO00O0O0OOO0O00O0 .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:1902
		try :os .remove (OOOOO00OO0000O0OO )#line:1903
		except :pass #line:1904
		downloader .download (OOO00O0OOO00O0OOO ,OOOOO00OO0000O0OO ,DP )#line:1905
		xbmc .sleep (100 )#line:1906
		DP .close ()#line:1907
		notify .apkInstaller (OO00O0O0OOO0O00O0 )#line:1908
		wiz .ebi ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+OOOOO00OO0000O0OO +'")')#line:1909
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: None Android Device[/COLOR]'%COLOR2 )#line:1910
def apkInstaller1 (OO000O00O00O00OOO ,O0OO0O00OO00OO0OO ):#line:1911
	if wiz .platform ()=='android'or DEVELOPER =='true':#line:1912
		O00OO0000OO000O0O =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like to download and install:"%COLOR2 ,"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO000O00O00O00OOO ),yeslabel ="[B][COLOR green]Download[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:1913
		if not O00OO0000OO000O0O :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:1914
		O0O0000O0O0O00OOO =OO000O00O00O00OOO #line:1915
		if O00OO0000OO000O0O :#line:1916
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1917
			if not wiz .workingURL (O0OO0O00OO00OO0OO )==True :wiz .LogNotify (ADDONTITLE ,'APK Installer: [COLOR red]Invalid Apk Url![/COLOR]');return #line:1918
			DP .create (ADDONTITLE ,'Downloading %s'%O0O0000O0O0O00OOO ,'','Please Wait')#line:1919
			O0000OOOOO00OO00O =os .path .join (PACKAGES ,"%s.apk"%OO000O00O00O00OOO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:1920
			try :os .remove (O0000OOOOO00OO00O )#line:1921
			except :pass #line:1922
			downloader .download (O0OO0O00OO00OO0OO ,O0000OOOOO00OO00O ,DP )#line:1923
			xbmc .sleep (500 )#line:1924
			DP .close ()#line:1925
			DIALOG .ok (ADDONTITLE ,"Launching the APK to be installed","Follow the install process to complete.")#line:1926
			xbmc .executebuiltin ('StartAndroidActivity("","android.intent.action.VIEW","application/vnd.android.package-archive","file:'+O0000OOOOO00OO00O +'")')#line:1927
		else :wiz .LogNotify (ADDONTITLE ,'[COLOR red]ERROR:[/COLOR] Install Cancelled')#line:1928
	else :wiz .LogNotify (ADDONTITLE ,'[COLOR red]ERROR:[/COLOR] None Android Device')#line:1929
def romInstaller (OO00OOO0O0O0OO0OO ,OO0O0OOOOO00OO000 ):#line:1930
	OO00O0O00O0OOO0OO =xbmc .translatePath (BACKUPROMS )#line:1931
	if OO00O0O00O0OOO0OO =='':#line:1932
		if DIALOG .yesno (ADDONTITLE ,"[COLOR %s]It seems that you do not have an extract location setup for Rom Packs"%COLOR2 ,"Would you like to set one?[/COLOR]",yeslabel ="[COLOR green][B]Set Location[/B][/COLOR]",nolabel ="[COLOR red][B]Cancel Download[/B][/COLOR]"):#line:1933
			wiz .openS ()#line:1934
			OO00O0O00O0OOO0OO =wiz .getS ('rompath')#line:1935
			if OO00O0O00O0OOO0OO =='':return #line:1936
	O0O0OOOO0OO000OO0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Are you sure you would like to download and extract [COLOR %s]%s[/COLOR] to:"%(COLOR2 ,COLOR1 ,OO00OOO0O0O0OO0OO ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00O0O00O0OOO0OO ),yeslabel ="[B][COLOR green]Download[/COLOR][/B]",nolabel ="[B][COLOR red]Cancel[/COLOR][/B]")#line:1937
	if not O0O0OOOO0OO000OO0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]ERROR: Install Cancelled[/COLOR]'%COLOR2 );return #line:1938
	O000O000O000OOO0O =OO00OOO0O0O0OO0OO #line:1939
	if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:1940
	if not wiz .workingURL (OO0O0OOOOO00OO000 )==True :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]APK Installer: Invalid Rom Url![/COLOR]'%COLOR2 );return #line:1941
	DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,O000O000O000OOO0O ),'','Please Wait')#line:1942
	O0OO000O0O0OOO000 =os .path .join (PACKAGES ,"%s.zip"%OO00OOO0O0O0OO0OO .replace ('\\','').replace ('/','').replace (':','').replace ('*','').replace ('?','').replace ('"','').replace ('<','').replace ('>','').replace ('|',''))#line:1943
	try :os .remove (O0OO000O0O0OOO000 )#line:1944
	except :pass #line:1945
	downloader .download (OO0O0OOOOO00OO000 ,O0OO000O0O0OOO000 ,DP )#line:1946
	xbmc .sleep (100 )#line:1947
	O0000O00O0O00O000 ,OO0O0O00OOOO0OO0O ,OO0000OOOO0000OOO =extract .all (O0OO000O0O0OOO000 ,OO00O0O00O0OOO0OO ,DP ,title =O000O000O000OOO0O )#line:1948
	try :os .remove (O0OO000O0O0OOO000 )#line:1949
	except :pass #line:1950
	wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Rom Pack Installed[/COLOR]'%COLOR2 )#line:1951
	DP .close ()#line:1952
def createMenu (OOO00O0OO0O00OO0O ,OOOO0OO00OOOO00OO ,OO0O0OO0OO000O00O ):#line:1956
	if OOO00O0OO0O00OO0O =='saveaddon':#line:1957
		O000O00000OO00OO0 =[]#line:1958
		OO0OO00000OOOO0O0 =urllib .quote_plus (OOOO0OO00OOOO00OO .lower ().replace (' ',''))#line:1959
		O0OOOOO00O0O00OOO =OOOO0OO00OOOO00OO .replace ('Debrid','Real Debrid')#line:1960
		OO0OO000OO0OO0OOO =urllib .quote_plus (OO0O0OO0OO000O00O .lower ().replace (' ',''))#line:1961
		OO0O0OO0OO000O00O =OO0O0OO0OO000O00O .replace ('url','URL Resolver')#line:1962
		O000O00000OO00OO0 .append ((THEME2 %OO0O0OO0OO000O00O .title (),' '))#line:1963
		O000O00000OO00OO0 .append ((THEME3 %'Save %s Data'%O0OOOOO00O0O00OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0OO00000OOOO0O0 ,OO0OO000OO0OO0OOO )))#line:1964
		O000O00000OO00OO0 .append ((THEME3 %'Restore %s Data'%O0OOOOO00O0O00OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0OO00000OOOO0O0 ,OO0OO000OO0OO0OOO )))#line:1965
		O000O00000OO00OO0 .append ((THEME3 %'Clear %s Data'%O0OOOOO00O0O00OOO ,'RunPlugin(plugin://%s/?mode=clear%s&name=%s)'%(ADDON_ID ,OO0OO00000OOOO0O0 ,OO0OO000OO0OO0OOO )))#line:1966
	elif OOO00O0OO0O00OO0O =='save':#line:1967
		O000O00000OO00OO0 =[]#line:1968
		OO0OO00000OOOO0O0 =urllib .quote_plus (OOOO0OO00OOOO00OO .lower ().replace (' ',''))#line:1969
		O0OOOOO00O0O00OOO =OOOO0OO00OOOO00OO .replace ('Debrid','Real Debrid')#line:1970
		OO0OO000OO0OO0OOO =urllib .quote_plus (OO0O0OO0OO000O00O .lower ().replace (' ',''))#line:1971
		OO0O0OO0OO000O00O =OO0O0OO0OO000O00O .replace ('url','URL Resolver')#line:1972
		O000O00000OO00OO0 .append ((THEME2 %OO0O0OO0OO000O00O .title (),' '))#line:1973
		O000O00000OO00OO0 .append ((THEME3 %'Register %s'%O0OOOOO00O0O00OOO ,'RunPlugin(plugin://%s/?mode=auth%s&name=%s)'%(ADDON_ID ,OO0OO00000OOOO0O0 ,OO0OO000OO0OO0OOO )))#line:1974
		O000O00000OO00OO0 .append ((THEME3 %'Save %s Data'%O0OOOOO00O0O00OOO ,'RunPlugin(plugin://%s/?mode=save%s&name=%s)'%(ADDON_ID ,OO0OO00000OOOO0O0 ,OO0OO000OO0OO0OOO )))#line:1975
		O000O00000OO00OO0 .append ((THEME3 %'Restore %s Data'%O0OOOOO00O0O00OOO ,'RunPlugin(plugin://%s/?mode=restore%s&name=%s)'%(ADDON_ID ,OO0OO00000OOOO0O0 ,OO0OO000OO0OO0OOO )))#line:1976
		O000O00000OO00OO0 .append ((THEME3 %'Import %s Data'%O0OOOOO00O0O00OOO ,'RunPlugin(plugin://%s/?mode=import%s&name=%s)'%(ADDON_ID ,OO0OO00000OOOO0O0 ,OO0OO000OO0OO0OOO )))#line:1977
		O000O00000OO00OO0 .append ((THEME3 %'Clear Addon %s Data'%O0OOOOO00O0O00OOO ,'RunPlugin(plugin://%s/?mode=addon%s&name=%s)'%(ADDON_ID ,OO0OO00000OOOO0O0 ,OO0OO000OO0OO0OOO )))#line:1978
	elif OOO00O0OO0O00OO0O =='install':#line:1979
		O000O00000OO00OO0 =[]#line:1980
		OO0OO000OO0OO0OOO =urllib .quote_plus (OO0O0OO0OO000O00O )#line:1981
		O000O00000OO00OO0 .append ((THEME2 %OO0O0OO0OO000O00O ,'RunAddon(%s, ?mode=viewbuild&name=%s)'%(ADDON_ID ,OO0OO000OO0OO0OOO )))#line:1982
		O000O00000OO00OO0 .append ((THEME3 %'Fresh Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=fresh)'%(ADDON_ID ,OO0OO000OO0OO0OOO )))#line:1983
		O000O00000OO00OO0 .append ((THEME3 %'Normal Install','RunPlugin(plugin://%s/?mode=install&name=%s&url=normal)'%(ADDON_ID ,OO0OO000OO0OO0OOO )))#line:1984
		O000O00000OO00OO0 .append ((THEME3 %'Apply guiFix','RunPlugin(plugin://%s/?mode=install&name=%s&url=gui)'%(ADDON_ID ,OO0OO000OO0OO0OOO )))#line:1985
		O000O00000OO00OO0 .append ((THEME3 %'Build Information','RunPlugin(plugin://%s/?mode=buildinfo&name=%s)'%(ADDON_ID ,OO0OO000OO0OO0OOO )))#line:1986
	O000O00000OO00OO0 .append ((THEME2 %'%s Settings'%ADDONTITLE ,'RunPlugin(plugin://%s/?mode=settings)'%ADDON_ID ))#line:1987
	return O000O00000OO00OO0 #line:1988
def toggleCache (O0O000000OO00O0OO ):#line:1989
	O0OOOO0OOO000000O =['includevideo','includeall','includebob','includezen,' 'includephoenix','includespecto','includegenesis','includeexodus','includeonechan','includesalts','includesaltslite']#line:1990
	O000OOOOO00OO000O =['Include Video Addons','Include All Addons','Include Bob','Include Zen','Include Phoenix','Include Specto','Include Genesis','Include Exodus','Include One Channel','Include Salts','Include Salts Lite HD']#line:1991
	if O0O000000OO00O0OO in ['true','false']:#line:1992
		for OO0OO000O0O0O000O in O0OOOO0OOO000000O :#line:1993
			wiz .setS (OO0OO000O0O0O000O ,O0O000000OO00O0OO )#line:1994
	else :#line:1995
		if not O0O000000OO00O0OO in ['includevideo','includeall']and wiz .getS ('includeall')=='true':#line:1996
			try :#line:1997
				OO0OO000O0O0O000O =O000OOOOO00OO000O [O0OOOO0OOO000000O .index (O0O000000OO00O0OO )]#line:1998
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]You will need to turn off [COLOR %s]Include All Addons[/COLOR] to disable[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ,OO0OO000O0O0O000O ))#line:1999
			except :#line:2000
				wiz .LogNotify ("[COLOR %s]Toggle Cache[/COLOR]"%COLOR1 ,"[COLOR %s]Invalid id: %s[/COLOR]"%(COLOR2 ,O0O000000OO00O0OO ))#line:2001
		else :#line:2002
			O0O0OO0O0OO00O00O ='true'if wiz .getS (O0O000000OO00O0OO )=='false'else 'false'#line:2003
			wiz .setS (O0O000000OO00O0OO ,O0O0OO0O0OO00O00O )#line:2004
def viewLogFile ():#line:2006
	OOOOO0O00000OO00O =wiz .Grab_Log (True )#line:2007
	OO0O0OOO0OOOO00O0 =wiz .Grab_Log (True ,True )#line:2008
	O0O0O00OO0O00OOO0 =0 ;O0000000OO0OOO0OO =OOOOO0O00000OO00O #line:2009
	if not OO0O0OOO0OOOO00O0 ==False and not OOOOO0O00000OO00O ==False :#line:2010
		O0O0O00OO0O00OOO0 =DIALOG .select (ADDONTITLE ,["View %s"%OOOOO0O00000OO00O .replace (LOG ,""),"View %s"%OO0O0OOO0OOOO00O0 .replace (LOG ,"")])#line:2011
		if O0O0O00OO0O00OOO0 ==-1 :wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]בוטלה תפיה בלוג[/COLOR]'%COLOR2 );return #line:2012
	elif OOOOO0O00000OO00O ==False and OO0O0OOO0OOOO00O0 ==False :#line:2013
		wiz .LogNotify ('[COLOR %s]View Log[/COLOR]'%COLOR1 ,'[COLOR %s]לא נמצא קובץ לוג[/COLOR]'%COLOR2 )#line:2014
		return #line:2015
	elif not OOOOO0O00000OO00O ==False :O0O0O00OO0O00OOO0 =0 #line:2016
	elif not OO0O0OOO0OOOO00O0 ==False :O0O0O00OO0O00OOO0 =1 #line:2017
	O0000000OO0OOO0OO =OOOOO0O00000OO00O if O0O0O00OO0O00OOO0 ==0 else OO0O0OOO0OOOO00O0 #line:2018
	O000O0O000OOOO0O0 =wiz .Grab_Log (False )if O0O0O00OO0O00OOO0 ==0 else wiz .Grab_Log (False ,True )#line:2019
	wiz .TextBox ("%s - %s"%(ADDONTITLE ,O0000000OO0OOO0OO ),O000O0O000OOOO0O0 )#line:2020
def errorList (O00OO00O0OO00000O ):#line:2021
	O00O0OOOO0O000O0O =[]#line:2022
	O0O00O0O0OO0O0O00 =open (O00OO00O0OO00000O ).read ()#line:2023
	OO000O0000O0O00O0 =O0O00O0O0OO0O0O00 .replace ('\n','[CR]').replace ('\r','')#line:2024
	O0O0O00OO0OOO0OO0 =re .compile ("-->Python callback/script returned the following error<--(.+?)-->End of Python script error report<--").findall (OO000O0000O0O00O0 )#line:2025
	for OO0OOO0O000O00OOO in O0O0O00OO0OOO0OO0 :#line:2026
		O00O0OOOO0O000O0O .append (OO0OOO0O000O00OOO )#line:2027
	return O00O0OOOO0O000O0O #line:2028
def errorChecking (log =None ,count =None ,last =None ):#line:2029
	OOO0O000OOOOOOO0O =[];OOO0000OO00OO0000 =[];OOOOOO0O0OO000OOO =[];#line:2030
	if log ==None :#line:2031
		OO000O000OO0OO00O =wiz .Grab_Log (True ,False )#line:2032
		O0OO0O00OOOOO0OO0 =wiz .Grab_Log (True ,True )#line:2033
		if O0OO0O00OOOOO0OO0 ==False and OO000O000OO0OO00O ==False :#line:2034
			if count ==None :#line:2035
				wiz .LogNotify ('[COLOR %s]View Error Log[/COLOR]'%COLOR1 ,'[COLOR %s]לא נמצא קובץ לוג[/COLOR]'%COLOR2 )#line:2036
				return #line:2037
			else :#line:2038
				return 0 #line:2039
		if not OO000O000OO0OO00O ==False :#line:2040
			OOO0000OO00OO0000 =errorList (OO000O000OO0OO00O )#line:2041
		if not O0OO0O00OOOOO0OO0 ==False :#line:2042
			OOOOOO0O0OO000OOO =errorList (O0OO0O00OOOOO0OO0 )#line:2043
		if len (OOOOOO0O0OO000OOO )>0 :#line:2044
			for O0O00OOOO0O00OOO0 in OOOOOO0O0OO000OOO :OOO0O000OOOOOOO0O =[O0O00OOOO0O00OOO0 ]+OOO0O000OOOOOOO0O #line:2045
		if len (OOO0000OO00OO0000 )>0 :#line:2046
			for O0O00OOOO0O00OOO0 in OOO0000OO00OO0000 :OOO0O000OOOOOOO0O =[O0O00OOOO0O00OOO0 ]+OOO0O000OOOOOOO0O #line:2047
	else :#line:2048
		OOO0000OO00OO0000 =errorList (log )#line:2049
		if len (OOO0000OO00OO0000 )>0 :#line:2050
			for O0O00OOOO0O00OOO0 in OOO0000OO00OO0000 :OOO0O000OOOOOOO0O =[O0O00OOOO0O00OOO0 ]+OOO0O000OOOOOOO0O #line:2051
	if not count ==None :#line:2052
		return len (OOO0O000OOOOOOO0O )#line:2053
	elif len (OOO0O000OOOOOOO0O )>0 :#line:2054
		if last ==None :#line:2055
			OOO00000O00OOO00O =0 ;OO00000OOO0O0000O =''#line:2056
			for O0O00OOOO0O00OOO0 in OOO0O000OOOOOOO0O :#line:2057
				OOO00000O00OOO00O +=1 #line:2058
				OO00000OOO0O0000O +="[B][COLOR red]ERROR NUMBER %s:[/B][/COLOR]%s\n"%(str (OOO00000O00OOO00O ),O0O00OOOO0O00OOO0 .replace (HOME ,'/').replace ('                                        ',''))#line:2059
		else :#line:2060
			OO00000OOO0O0000O ="[B][COLOR red]Last Error in Log:[/B][/COLOR]%s\n"%(OOO0O000OOOOOOO0O [0 ].replace (HOME ,'/').replace ('                                        ',''))#line:2061
		wiz .TextBox ("%s: Errors in Log"%ADDONTITLE ,OO00000OOO0O0000O )#line:2062
	else :#line:2063
		wiz .LogNotify ('[COLOR %s]View Error Log[/COLOR]'%COLOR1 ,'[COLOR %s]לא נמצאו שגיאות[/COLOR]'%COLOR2 )#line:2064
def log_tools ():#line:2066
	O00OOOO00OO00OOO0 =int (errorChecking (count =True ))#line:2067
	O00OOOO0000O0O000 =str (O00OOOO00OO00OOO0 )#line:2068
	OO0O00O000O0OO000 ='[COLOR red]%s[/COLOR] נמצא/ו '%(O00OOOO0000O0O000 )if O00OOOO00OO00OOO0 >0 else 'לא נמצא '#line:2069
	OOO0OO0000O0OO000 ='[B][COLOR green]פעיל[/COLOR][/B]';OOOOO0O0OOO000OO0 ='[B][COLOR red]כבוי[/COLOR][/B]'#line:2070
	if wiz .Grab_Log (True )==False :OO00OO0000O00OO0O =0 #line:2071
	else :OO00OO0000O00OO0O =errorChecking (wiz .Grab_Log (True ),True )#line:2072
	if wiz .Grab_Log (True ,True )==False :OOOO00O0O0O00O0O0 =0 #line:2073
	else :OOOO00O0O0O00O0O0 =errorChecking (wiz .Grab_Log (True ,True ),True )#line:2074
	OO00O00000OOO00O0 =int (OO00OO0000O00OO0O )+int (OOOO00O0O0O00O0O0 )#line:2075
	OOO0O0O0O0OO00OOO =': [COLOR red]לא נמצא[/COLOR]'if not os .path .exists (WIZLOG )else ": [COLOR green]%s[/COLOR]"%wiz .convertSize (os .path .getsize (WIZLOG ))#line:2076
	return OO0O00O000O0OO000 #line:2077
ACTION_PREVIOUS_MENU =10 #line:2081
ACTION_NAV_BACK =92 #line:2082
ACTION_MOVE_LEFT =1 #line:2083
ACTION_MOVE_RIGHT =2 #line:2084
ACTION_MOVE_UP =3 #line:2085
ACTION_MOVE_DOWN =4 #line:2086
ACTION_MOUSE_WHEEL_UP =104 #line:2087
ACTION_MOUSE_WHEEL_DOWN =105 #line:2088
ACTION_MOVE_MOUSE =107 #line:2089
ACTION_SELECT_ITEM =7 #line:2090
ACTION_BACKSPACE =110 #line:2091
ACTION_MOUSE_LEFT_CLICK =100 #line:2092
ACTION_MOUSE_LONG_CLICK =108 #line:2093
def LogViewer (default =None ):#line:2094
	class O000O00OOOO00OOOO (xbmcgui .WindowXMLDialog ):#line:2095
		def __init__ (O0OOOO0000OO00O0O ,*OO00O0O0O00000OOO ,**O0O000OOO00O0O0OO ):#line:2096
			O0OOOO0000OO00O0O .default =O0O000OOO00O0O0OO ['default']#line:2097
		def onInit (O0O0OOOOOOO0000O0 ):#line:2098
			O0O0OOOOOOO0000O0 .title =101 #line:2099
			O0O0OOOOOOO0000O0 .msg =102 #line:2100
			O0O0OOOOOOO0000O0 .scrollbar =103 #line:2101
			O0O0OOOOOOO0000O0 .upload =201 #line:2102
			O0O0OOOOOOO0000O0 .kodi =202 #line:2103
			O0O0OOOOOOO0000O0 .kodiold =203 #line:2104
			O0O0OOOOOOO0000O0 .wizard =204 #line:2105
			O0O0OOOOOOO0000O0 .okbutton =205 #line:2106
			OOOO0O000OO0000O0 =open (O0O0OOOOOOO0000O0 .default ,'r')#line:2107
			O0O0OOOOOOO0000O0 .logmsg =OOOO0O000OO0000O0 .read ()#line:2108
			OOOO0O000OO0000O0 .close ()#line:2109
			O0O0OOOOOOO0000O0 .titlemsg ="%s: %s"%(ADDONTITLE ,O0O0OOOOOOO0000O0 .default .replace (LOG ,'').replace (ADDONDATA ,''))#line:2110
			O0O0OOOOOOO0000O0 .showdialog ()#line:2111
		def showdialog (OOO00OOOO00O0OO0O ):#line:2112
			OOO00OOOO00O0OO0O .getControl (OOO00OOOO00O0OO0O .title ).setLabel (OOO00OOOO00O0OO0O .titlemsg )#line:2113
			OOO00OOOO00O0OO0O .getControl (OOO00OOOO00O0OO0O .msg ).setText (wiz .highlightText (OOO00OOOO00O0OO0O .logmsg ))#line:2114
			OOO00OOOO00O0OO0O .setFocusId (OOO00OOOO00O0OO0O .scrollbar )#line:2115
		def onClick (OOOOO00000OO000OO ,O0OOO0OOOOO00O000 ):#line:2116
			if O0OOO0OOOOO00O000 ==OOOOO00000OO000OO .okbutton :OOOOO00000OO000OO .close ()#line:2117
			elif O0OOO0OOOOO00O000 ==OOOOO00000OO000OO .upload :OOOOO00000OO000OO .close ();uploadLog .Main ()#line:2118
			elif O0OOO0OOOOO00O000 ==OOOOO00000OO000OO .kodi :#line:2119
				OOO00OO0OOOO000OO =wiz .Grab_Log (False )#line:2120
				OOO0OO000000O0OOO =wiz .Grab_Log (True )#line:2121
				if OOO00OO0OOOO000OO ==False :#line:2122
					OOOOO00000OO000OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:2123
					OOOOO00000OO000OO .getControl (OOOOO00000OO000OO .msg ).setText ("Log File Does Not Exists!")#line:2124
				else :#line:2125
					OOOOO00000OO000OO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0OO000000O0OOO .replace (LOG ,''))#line:2126
					OOOOO00000OO000OO .getControl (OOOOO00000OO000OO .title ).setLabel (OOOOO00000OO000OO .titlemsg )#line:2127
					OOOOO00000OO000OO .getControl (OOOOO00000OO000OO .msg ).setText (wiz .highlightText (OOO00OO0OOOO000OO ))#line:2128
					OOOOO00000OO000OO .setFocusId (OOOOO00000OO000OO .scrollbar )#line:2129
			elif O0OOO0OOOOO00O000 ==OOOOO00000OO000OO .kodiold :#line:2130
				OOO00OO0OOOO000OO =wiz .Grab_Log (False ,True )#line:2131
				OOO0OO000000O0OOO =wiz .Grab_Log (True ,True )#line:2132
				if OOO00OO0OOOO000OO ==False :#line:2133
					OOOOO00000OO000OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:2134
					OOOOO00000OO000OO .getControl (OOOOO00000OO000OO .msg ).setText ("Log File Does Not Exists!")#line:2135
				else :#line:2136
					OOOOO00000OO000OO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0OO000000O0OOO .replace (LOG ,''))#line:2137
					OOOOO00000OO000OO .getControl (OOOOO00000OO000OO .title ).setLabel (OOOOO00000OO000OO .titlemsg )#line:2138
					OOOOO00000OO000OO .getControl (OOOOO00000OO000OO .msg ).setText (wiz .highlightText (OOO00OO0OOOO000OO ))#line:2139
					OOOOO00000OO000OO .setFocusId (OOOOO00000OO000OO .scrollbar )#line:2140
			elif O0OOO0OOOOO00O000 ==OOOOO00000OO000OO .wizard :#line:2141
				OOO00OO0OOOO000OO =wiz .Grab_Log (False ,False ,True )#line:2142
				OOO0OO000000O0OOO =wiz .Grab_Log (True ,False ,True )#line:2143
				if OOO00OO0OOOO000OO ==False :#line:2144
					OOOOO00000OO000OO .titlemsg ="%s: View Log Error"%ADDONTITLE #line:2145
					OOOOO00000OO000OO .getControl (OOOOO00000OO000OO .msg ).setText ("Log File Does Not Exists!")#line:2146
				else :#line:2147
					OOOOO00000OO000OO .titlemsg ="%s: %s"%(ADDONTITLE ,OOO0OO000000O0OOO .replace (ADDONDATA ,''))#line:2148
					OOOOO00000OO000OO .getControl (OOOOO00000OO000OO .title ).setLabel (OOOOO00000OO000OO .titlemsg )#line:2149
					OOOOO00000OO000OO .getControl (OOOOO00000OO000OO .msg ).setText (wiz .highlightText (OOO00OO0OOOO000OO ))#line:2150
					OOOOO00000OO000OO .setFocusId (OOOOO00000OO000OO .scrollbar )#line:2151
		def onAction (OOO0OOOO0OO0OO0O0 ,OOO0OO00OOO0OOOO0 ):#line:2152
			if OOO0OO00OOO0OOOO0 ==ACTION_PREVIOUS_MENU :OOO0OOOO0OO0OO0O0 .close ()#line:2153
			elif OOO0OO00OOO0OOOO0 ==ACTION_NAV_BACK :OOO0OOOO0OO0OO0O0 .close ()#line:2154
	if default ==None :default =wiz .Grab_Log (True )#line:2155
	OOO000OO0O0O0O0O0 =O000O00OOOO00OOOO ("LogViewer.xml",ADDON .getAddonInfo ('path'),'DefaultSkin',default =default )#line:2156
	OOO000OO0O0O0O0O0 .doModal ()#line:2157
	del OOO000OO0O0O0O0O0 #line:2158
def removeAddon (O0OOO0OO0000O00O0 ,OOO0O0O00000O0O0O ,over =False ):#line:2168
	if not over ==False :#line:2169
		O000000O000OO00O0 =1 #line:2170
	else :#line:2171
		O000000O000OO00O0 =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Are you sure you want to delete the addon:'%COLOR2 ,'Name: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0O0O00000O0O0O ),'ID: [COLOR %s]%s[/COLOR][/COLOR]'%(COLOR1 ,O0OOO0OO0000O00O0 ),yeslabel ='[B][COLOR green]Remove Addon[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]')#line:2172
	if O000000O000OO00O0 ==1 :#line:2173
		O000OO0OOO00O00O0 =os .path .join (ADDONS ,O0OOO0OO0000O00O0 )#line:2174
		wiz .log ("Removing Addon %s"%O0OOO0OO0000O00O0 )#line:2175
		wiz .cleanHouse (O000OO0OOO00O00O0 )#line:2176
		xbmc .sleep (200 )#line:2177
		try :shutil .rmtree (O000OO0OOO00O00O0 )#line:2178
		except Exception as OOO0OO00O000OO0O0 :wiz .log ("Error removing %s"%O0OOO0OO0000O00O0 ,xbmc .LOGNOTICE )#line:2179
		removeAddonData (O0OOO0OO0000O00O0 ,OOO0O0O00000O0O0O ,over )#line:2180
	if over ==False :#line:2181
		wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]%s Removed[/COLOR]"%(COLOR2 ,OOO0O0O00000O0O0O ))#line:2182
def removeAddonData (OO0O0O0000000OO0O ,name =None ,over =False ):#line:2183
	if OO0O0O0000000OO0O =='all':#line:2184
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s] מידע ההרחבות מספריית היוזר דאטא- כל התפריטים ימחקו! [COLOR %s] כל [/COLOR]תהליך הסרת [/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]הסר מידע[/COLOR][/B]',nolabel ='[B][COLOR red]בטל הסרה[/COLOR][/B]'):#line:2185
			wiz .cleanHouse (ADDOND )#line:2186
		else :wiz .LogNotify ('[COLOR %s]הסרת נתוני הרחבות[/COLOR]'%COLOR1 ,'[COLOR %s] בוטלה![/COLOR]'%COLOR2 )#line:2187
	elif OO0O0O0000000OO0O =='uninstalled':#line:2188
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s] נתוני ההרחבות הלא פעילות מספריית היוזר דאטא?[COLOR %s] כל [/COLOR]  להסיר את  [/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]הסר מידע[/COLOR][/B]',nolabel ='[B][COLOR red]בטל הסרה[/COLOR][/B]'):#line:2189
			O00O0O000OOO00O0O =0 #line:2190
			for O000OOOOO000OOOO0 in glob .glob (os .path .join (ADDOND ,'*')):#line:2191
				O0OOOOOO0O000O0OO =O000OOOOO000OOOO0 .replace (ADDOND ,'').replace ('\\','').replace ('/','')#line:2192
				if O0OOOOOO0O000O0OO in EXCLUDES :pass #line:2193
				elif os .path .exists (os .path .join (ADDONS ,O0OOOOOO0O000O0OO )):pass #line:2194
				else :wiz .cleanHouse (O000OOOOO000OOOO0 );O00O0O000OOO00O0O +=1 ;wiz .log (O000OOOOO000OOOO0 );shutil .rmtree (O000OOOOO000OOOO0 )#line:2195
			wiz .LogNotify ('[COLOR %s]Clean up Uninstalled[/COLOR]'%COLOR1 ,'[COLOR %s]%s Folders(s) Removed[/COLOR]'%(COLOR2 ,O00O0O000OOO00O0O ))#line:2196
		else :wiz .LogNotify ('[COLOR %s]הסרת נתוני ההרחבות  [/COLOR]'%COLOR1 ,'[COLOR %s]בוטלה! [/COLOR]'%COLOR2 )#line:2197
	elif OO0O0O0000000OO0O =='empty':#line:2198
		if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]  ספריות ההרחבות הריקות מספריית היוזר דאטא?[COLOR %s] כל [/COLOR] האם להסיר את  [/COLOR]'%(COLOR2 ,COLOR1 ),yeslabel ='[B][COLOR green]הסר מידע[/COLOR][/B]',nolabel ='[B][COLOR red]בטל הסרה[/COLOR][/B]'):#line:2199
			O00O0O000OOO00O0O =wiz .emptyfolder (ADDOND )#line:2200
			wiz .LogNotify ('[COLOR %s]מסיר ספריות ריקות [/COLOR]'%COLOR1 ,'[COLOR %s]%s ספריה/יות הוסרו[/COLOR]'%(COLOR2 ,O00O0O000OOO00O0O ))#line:2201
		else :wiz .LogNotify ('[COLOR %s]הסרת ספריות ריקות [/COLOR]'%COLOR1 ,'[COLOR %s] בוטלה! [/COLOR]'%COLOR2 )#line:2202
	else :#line:2203
		O00OO00O0O0O00OO0 =os .path .join (USERDATA ,'addon_data',OO0O0O0000000OO0O )#line:2204
		if OO0O0O0000000OO0O in EXCLUDES :#line:2205
			wiz .LogNotify ("[COLOR %s]Protected Plugin[/COLOR]"%COLOR1 ,"[COLOR %s]Not allowed to remove Addon_Data[/COLOR]"%COLOR2 )#line:2206
		elif os .path .exists (O00OO00O0O0O00OO0 ):#line:2207
			if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you also like to remove the addon data for:[/COLOR]'%COLOR2 ,'[COLOR %s]%s[/COLOR]'%(COLOR1 ,OO0O0O0000000OO0O ),yeslabel ='[B][COLOR green]Remove Data[/COLOR][/B]',nolabel ='[B][COLOR red]Don\'t Remove[/COLOR][/B]'):#line:2208
				wiz .cleanHouse (O00OO00O0O0O00OO0 )#line:2209
				try :#line:2210
					shutil .rmtree (O00OO00O0O0O00OO0 )#line:2211
				except :#line:2212
					wiz .log ("Error deleting: %s"%O00OO00O0O0O00OO0 )#line:2213
			else :#line:2214
				wiz .log ('Addon data for %s was not removed'%OO0O0O0000000OO0O )#line:2215
	wiz .refresh ()#line:2216
def restoreit (O0000O00000O000O0 ):#line:2217
	if O0000O00000O000O0 =='build':#line:2218
		O0O000OOO00OO00O0 =freshStart ('restore')#line:2219
		if O0O000OOO00OO00O0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Local Restore Cancelled[/COLOR]"%COLOR2 );return #line:2220
	if not wiz .currSkin ()in ['skin.confluence','skin.estuary']:#line:2221
		wiz .skinToDefault ('Restore Backup')#line:2222
	wiz .restoreLocal (O0000O00000O000O0 )#line:2223
def restoreextit (OO0O00OO0OO00OOO0 ):#line:2224
	if OO0O00OO0OO00OOO0 =='build':#line:2225
		O00OO0OO000O0OOO0 =freshStart ('restore')#line:2226
		if O00OO0OO000O0OOO0 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]External Restore Cancelled[/COLOR]"%COLOR2 );return #line:2227
	wiz .restoreExternal (OO0O00OO0OO00OOO0 )#line:2228
def buildInfo (O0O00OO0OO000OO0O ):#line:2229
	if wiz .workingURL (BUILDFILE )==True :#line:2230
		if wiz .checkBuild (O0O00OO0OO000OO0O ,'url'):#line:2231
			O0O00OO0OO000OO0O ,OO000000000O0OOOO ,OO0OOO0OOO0O0000O ,OO0000OOOOO0O0O00 ,OO00OO0O00O00O00O ,O0OO0000OOO0OO0OO ,O000OO0000OOOOOOO ,O00O0000000OOO0OO ,O00OOOOOO00OOOO0O ,O000OO0000O00OO00 ,OO0OOO0O00OOO0O00 ,O000OO0O000O0O0OO ,O00OOOO0O00O0OO00 =wiz .checkBuild (O0O00OO0OO000OO0O ,'all')#line:2232
			OO0OOO0O00OOO0O00 ='Yes'if OO0OOO0O00OOO0O00 .lower ()=='yes'else 'No'#line:2233
			OOO000O0OOOOOOO0O =False #line:2234
			if not O000OO0O000O0O0OO =="http://":#line:2235
				try :#line:2236
					O00O0000OO00O0O00 ,OOO0O000O0O0OOOO0 ,OO000OOO0O0OOO000 ,O0OOO0000O0O000O0 ,O00O00OO00OOO00O0 ,O0O0O00000OOOOO00 ,OO000OOO0OO0OO00O ,O00OOO0OOOO0OO0OO ,O00O0O000O00O0OO0 ,O000O00OO0O00OO0O ,OOOO0O0O00O00O000 =wiz .checkInfo (O000OO0O000O0O0OO )#line:2237
					OOO000O0OOOOOOO0O =True #line:2238
				except :#line:2239
					OOO000O0OOOOOOO0O =False #line:2240
			if OOO000O0OOOOOOO0O ==True :#line:2241
				O00O00OO00OOOO00O ="[COLOR %s]Build Name:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O0O00OO0OO000OO0O )#line:2242
				O00O00OO00OOOO00O +="[COLOR %s]Build Version:[/COLOR] v[COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OO000000000O0OOOO )#line:2243
				O00O00OO00OOOO00O +="[COLOR %s]Latest Update:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O00O00OO00OOO00O0 )#line:2244
				if not O000OO0000OOOOOOO =="http://":#line:2245
					OO0O000OOOO00O000 =wiz .themeCount (O0O00OO0OO000OO0O ,False )#line:2246
					O00O00OO00OOOO00O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO0O000OOOO00O000 ))#line:2247
				O00O00OO00OOOO00O +="[COLOR %s]Kodi Version:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O0OO0000OOO0OO0OO )#line:2248
				O00O00OO00OOOO00O +="[COLOR %s]Extracted -גודל[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,wiz .convertSize (int (float (OOO0O000O0O0OOOO0 ))))#line:2249
				O00O00OO00OOOO00O +="[COLOR %s]Zip -גודל[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,wiz .convertSize (int (float (OO000OOO0O0OOO000 ))))#line:2250
				O00O00OO00OOOO00O +="[COLOR %s]Skin Name:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O0OOO0000O0O000O0 )#line:2251
				O00O00OO00OOOO00O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OO0OOO0O00OOO0O00 )#line:2252
				O00O00OO00OOOO00O +="[COLOR %s]Description:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O00OOOO0O00O0OO00 )#line:2253
				O00O00OO00OOOO00O +="[COLOR %s]Programs:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O0O0O00000OOOOO00 )#line:2254
				O00O00OO00OOOO00O +="[COLOR %s]Video:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,OO000OOO0OO0OO00O )#line:2255
				O00O00OO00OOOO00O +="[COLOR %s]Music:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O00OOO0OOOO0OO0OO )#line:2256
				O00O00OO00OOOO00O +="[COLOR %s]Pictures:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O00O0O000O00O0OO0 )#line:2257
				O00O00OO00OOOO00O +="[COLOR %s]Repositories:[/COLOR] [COLOR %s]%s[/COLOR][CR][CR]"%(COLOR2 ,COLOR1 ,O000O00OO0O00OO0O )#line:2258
				O00O00OO00OOOO00O +="[COLOR %s]Scripts:[/COLOR] [COLOR %s]%s[/COLOR]"%(COLOR2 ,COLOR1 ,OOOO0O0O00O00O000 )#line:2259
			else :#line:2260
				O00O00OO00OOOO00O ="[COLOR %s]Build Name:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0O00OO0OO000OO0O )#line:2261
				O00O00OO00OOOO00O +="[COLOR %s]Build Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO000000000O0OOOO )#line:2262
				if not O000OO0000OOOOOOO =="http://":#line:2263
					OO0O000OOOO00O000 =wiz .themeCount (O0O00OO0OO000OO0O ,False )#line:2264
					O00O00OO00OOOO00O +="[COLOR %s]Build Theme(s):[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,', '.join (OO0O000OOOO00O000 ))#line:2265
				O00O00OO00OOOO00O +="[COLOR %s]Kodi Version:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O0OO0000OOO0OO0OO )#line:2266
				O00O00OO00OOOO00O +="[COLOR %s]Adult Content:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,OO0OOO0O00OOO0O00 )#line:2267
				O00O00OO00OOOO00O +="[COLOR %s]Description:[/COLOR] [COLOR %s]%s[/COLOR][CR]"%(COLOR2 ,COLOR1 ,O00OOOO0O00O0OO00 )#line:2268
			wiz .TextBox (ADDONTITLE ,O00O00OO00OOOO00O )#line:2269
		else :wiz .log ("Invalid Build Name!")#line:2270
	else :wiz .log ("Build text file not working: %s"%WORKINGURL )#line:2271
def viewpack ():#line:2273
	OO00000OO00O00O0O =wiz .workingURL (ADDONPACK )#line:2274
	if not OO00000OO00O00O0O ==True :#line:2275
		addFile ('Url for txt file not valid','',themeit =THEME3 )#line:2276
		addFile ('%s'%OO00000OO00O00O0O ,'',themeit =THEME3 )#line:2277
		return #line:2278
	OOO0O0OO000O0OO00 =wiz .openURL (ADDONPACK ).replace ('\n','').replace ('\r','').replace ('\t','')#line:2279
	OOO0OOO00000O00O0 =re .compile ('name="(.+?)".+?rl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?escription="(.+?)"').findall (OOO0O0OO000O0OO00 )#line:2280
	for O0O0OO0OO000O0OO0 ,OO0OOO0O0O00O0O0O ,OOOOO0O0OOO00OOOO ,O00OOO000000OOO00 ,O0OO0000OO0OO000O in OOO0OOO00000O00O0 :#line:2281
		addFolder ('',O0O0OO0OO000O0OO0 ,OO0OOO0O0O00O0O0O ,'addonpackwiz',OOOOO0O0OOO00OOOO ,O00OOO000000OOO00 ,'')#line:2282
def addonpackwiz ():#line:2283
		OO0O0OO000OOOO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Would you like to install the:'%COLOR2 ,'[COLOR %s]%s[/COLOR]?[/COLOR]'%(COLOR1 ,name ),nolabel ='[B]לא, בטל[/B]',yeslabel ='[B]Install[/B]')#line:2284
		if OO0O0OO000OOOO00O :#line:2285
			if not os .path .exists (PACKAGES ):os .makedirs (PACKAGES )#line:2286
			DP .create (ADDONTITLE ,'[COLOR %s][B]Downloading:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,name ),'','Please Wait')#line:2287
			O000OOO0000O0O000 =os .path .join (PACKAGES ,'pack.zip')#line:2288
			try :os .remove (O000OOO0000O0O000 )#line:2289
			except :pass #line:2290
			downloader .download (url ,O000OOO0000O0O000 ,DP )#line:2291
			xbmc .sleep (500 )#line:2292
			DP .update (0 ,"","Installing %s "%name )#line:2293
			OO00000OO00OO0000 ='[COLOR %s][B]Installing Addon Pack:[/B][/COLOR] [COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,name )#line:2294
			DP .update (0 ,OO00000OO00OO0000 ,'','Please Wait')#line:2295
			O000O0OOOO000O00O ,O0O00OOOO0000OOO0 ,O0O00OO00O0O0OOO0 =extract .all (O000OOO0000O0O000 ,HOME ,DP ,title =OO00000OO00OO0000 )#line:2296
			wiz .log ('INSTALLED %s: [ERRORS:%s]'%(O000O0OOOO000O00O ,O0O00OOOO0000OOO0 ))#line:2297
			DP .close ()#line:2298
			OO0O0OO000OOOO00O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]Installed:'%COLOR2 ,'[COLOR %s]%s[/COLOR]?[/COLOR]'%(COLOR1 ,name ),'[COLOR green]Successfully[/COLOR]',nolabel ='[B]Reset[/B]',yeslabel ='[B]Force Close[/B]')#line:2300
			if OO0O0OO000OOOO00O ==1 :#line:2301
				wiz .killxbmc ('true')#line:2302
			elif OO0O0OO000OOOO00O ==0 :#line:2303
				wiz .RESET ()#line:2304
		else :#line:2305
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Addon Pack: Cancelled![/COLOR]'%COLOR2 )#line:2306
def dependsList (OO0O00OO00000OOOO ):#line:2307
	O0O000OO00OO0O0OO =os .path .join (ADDONS ,OO0O00OO00000OOOO ,'addon.xml')#line:2308
	if os .path .exists (O0O000OO00OO0O0OO ):#line:2309
		O0O0OO00O00OO0OOO =open (O0O000OO00OO0O0OO ,mode ='r');OOOOO00000OOOO0OO =O0O0OO00O00OO0OOO .read ();O0O0OO00O00OO0OOO .close ();#line:2310
		OO0000O0O0OOO00OO =wiz .parseDOM (OOOOO00000OOOO0OO ,'import',ret ='addon')#line:2311
		O00OOOOO0OO00O0OO =[]#line:2312
		for OOOOOO00OO0O0O000 in OO0000O0O0OOO00OO :#line:2313
			if not 'xbmc.python'in OOOOOO00OO0O0O000 :#line:2314
				O00OOOOO0OO00O0OO .append (OOOOOO00OO0O0O000 )#line:2315
		return O00OOOOO0OO00O0OO #line:2316
	return []#line:2317
def manageSaveData (OOOO00000O00000OO ):#line:2318
	if OOOO00000O00000OO =='import':#line:2319
		O00O00OO00O0O0OO0 =os .path .join (ADDONDATA ,'temp')#line:2320
		if not os .path .exists (O00O00OO00O0O0OO0 ):os .makedirs (O00O00OO00O0O0OO0 )#line:2321
		O00000000O0000000 =DIALOG .browse (1 ,'[COLOR %s]Select the location of the SaveData.zip[/COLOR]'%COLOR2 ,'files','.zip',False ,False ,HOME )#line:2322
		if not O00000000O0000000 .endswith ('.zip'):#line:2323
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Import Data Error![/COLOR]"%(COLOR2 ))#line:2324
			return #line:2325
		O0O0OOOOO00O0OOOO =os .path .join (MYBUILDS ,'SaveData.zip')#line:2326
		OO0OO000O0OOO000O =xbmcvfs .copy (O00000000O0000000 ,O0O0OOOOO00O0OOOO )#line:2327
		wiz .log ("%s"%str (OO0OO000O0OOO000O ))#line:2328
		extract .all (xbmc .translatePath (O0O0OOOOO00O0OOOO ),O00O00OO00O0O0OO0 )#line:2329
		OO0OOO000OOOO0000 =os .path .join (O00O00OO00O0O0OO0 ,'trakt')#line:2330
		OOO00OO0O0OOOO0OO =os .path .join (O00O00OO00O0O0OO0 ,'login')#line:2331
		OOOOO0000OO00O0O0 =os .path .join (O00O00OO00O0O0OO0 ,'debrid')#line:2332
		O00O000O00O00O00O =0 #line:2333
		if os .path .exists (OO0OOO000OOOO0000 ):#line:2334
			O00O000O00O00O00O +=1 #line:2335
			OOO000O00000O0OO0 =os .listdir (OO0OOO000OOOO0000 )#line:2336
			if not os .path .exists (traktit .TRAKTFOLD ):os .makedirs (traktit .TRAKTFOLD )#line:2337
			for OOO00O0000000O000 in OOO000O00000O0OO0 :#line:2338
				OOO000O0OOOOOOOOO =os .path .join (traktit .TRAKTFOLD ,OOO00O0000000O000 )#line:2339
				OO0OO00O0OOOOOOO0 =os .path .join (OO0OOO000OOOO0000 ,OOO00O0000000O000 )#line:2340
				if os .path .exists (OOO000O0OOOOOOOOO ):#line:2341
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO00O0000000O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:2342
					else :os .remove (OOO000O0OOOOOOOOO )#line:2343
				shutil .copy (OO0OO00O0OOOOOOO0 ,OOO000O0OOOOOOOOO )#line:2344
			traktit .importlist ('all')#line:2345
			traktit .traktIt ('restore','all')#line:2346
		if os .path .exists (OOO00OO0O0OOOO0OO ):#line:2347
			O00O000O00O00O00O +=1 #line:2348
			OOO000O00000O0OO0 =os .listdir (OOO00OO0O0OOOO0OO )#line:2349
			if not os .path .exists (loginit .LOGINFOLD ):os .makedirs (loginit .LOGINFOLD )#line:2350
			for OOO00O0000000O000 in OOO000O00000O0OO0 :#line:2351
				OOO000O0OOOOOOOOO =os .path .join (loginit .LOGINFOLD ,OOO00O0000000O000 )#line:2352
				OO0OO00O0OOOOOOO0 =os .path .join (OOO00OO0O0OOOO0OO ,OOO00O0000000O000 )#line:2353
				if os .path .exists (OOO000O0OOOOOOOOO ):#line:2354
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO00O0000000O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:2355
					else :os .remove (OOO000O0OOOOOOOOO )#line:2356
				shutil .copy (OO0OO00O0OOOOOOO0 ,OOO000O0OOOOOOOOO )#line:2357
			loginit .importlist ('all')#line:2358
			loginit .loginIt ('restore','all')#line:2359
		if os .path .exists (OOOOO0000OO00O0O0 ):#line:2360
			O00O000O00O00O00O +=1 #line:2361
			OOO000O00000O0OO0 =os .listdir (OOOOO0000OO00O0O0 )#line:2362
			if not os .path .exists (debridit .REALFOLD ):os .makedirs (debridit .REALFOLD )#line:2363
			for OOO00O0000000O000 in OOO000O00000O0OO0 :#line:2364
				OOO000O0OOOOOOOOO =os .path .join (debridit .REALFOLD ,OOO00O0000000O000 )#line:2365
				OO0OO00O0OOOOOOO0 =os .path .join (OOOOO0000OO00O0O0 ,OOO00O0000000O000 )#line:2366
				if os .path .exists (OOO000O0OOOOOOOOO ):#line:2367
					if not DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Would you like replace the current [COLOR %s]%s[/COLOR] file?"%(COLOR2 ,COLOR1 ,OOO00O0000000O000 ),yeslabel ="[B][COLOR green]Yes Replace[/COLOR][/B]",nolabel ="[B][COLOR red]No Skip[/COLOR][/B]"):continue #line:2368
					else :os .remove (OOO000O0OOOOOOOOO )#line:2369
				shutil .copy (OO0OO00O0OOOOOOO0 ,OOO000O0OOOOOOOOO )#line:2370
			debridit .importlist ('all')#line:2371
			debridit .debridIt ('restore','all')#line:2372
		wiz .cleanHouse (O00O00OO00O0O0OO0 )#line:2373
		wiz .removeFolder (O00O00OO00O0O0OO0 )#line:2374
		os .remove (O0O0OOOOO00O0OOOO )#line:2375
		if O00O000O00O00O00O ==0 :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Failed[/COLOR]"%COLOR2 )#line:2376
		else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Save Data Import Complete[/COLOR]"%COLOR2 )#line:2377
	elif OOOO00000O00000OO =='export':#line:2378
		OOOOO00OOOOOO0O0O =xbmc .translatePath (MYBUILDS )#line:2379
		O0OOO0OO00O00OOOO =[traktit .TRAKTFOLD ,debridit .REALFOLD ,loginit .LOGINFOLD ]#line:2380
		traktit .traktIt ('update','all')#line:2381
		loginit .loginIt ('update','all')#line:2382
		debridit .debridIt ('update','all')#line:2383
		O00000000O0000000 =DIALOG .browse (3 ,'[COLOR %s]Select where you wish to export the savedata zip?[/COLOR]'%COLOR2 ,'files','',False ,True ,HOME )#line:2384
		O00000000O0000000 =xbmc .translatePath (O00000000O0000000 )#line:2385
		OO00OO00O0000O0OO =os .path .join (OOOOO00OOOOOO0O0O ,'SaveData.zip')#line:2386
		O000O000000OO0O00 =zipfile .ZipFile (OO00OO00O0000O0OO ,mode ='w')#line:2387
		for OO00OOOO0O0OOOO0O in O0OOO0OO00O00OOOO :#line:2388
			if os .path .exists (OO00OOOO0O0OOOO0O ):#line:2389
				OOO000O00000O0OO0 =os .listdir (OO00OOOO0O0OOOO0O )#line:2390
				for O0OO0000OO0O0O00O in OOO000O00000O0OO0 :#line:2391
					O000O000000OO0O00 .write (os .path .join (OO00OOOO0O0OOOO0O ,O0OO0000OO0O0O00O ),os .path .join (OO00OOOO0O0OOOO0O ,O0OO0000OO0O0O00O ).replace (ADDONDATA ,''),zipfile .ZIP_DEFLATED )#line:2392
		O000O000000OO0O00 .close ()#line:2393
		if O00000000O0000000 ==OOOOO00OOOOOO0O0O :#line:2394
			DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO00O0000O0OO ))#line:2395
		else :#line:2396
			try :#line:2397
				xbmcvfs .copy (OO00OO00O0000O0OO ,os .path .join (O00000000O0000000 ,'SaveData.zip'))#line:2398
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,os .path .join (O00000000O0000000 ,'SaveData.zip')))#line:2399
			except :#line:2400
				DIALOG .ok (ADDONTITLE ,"[COLOR %s]Save data has been backed up to:[/COLOR]"%(COLOR2 ),"[COLOR %s]%s[/COLOR]"%(COLOR1 ,OO00OO00O0000O0OO ))#line:2401
def freshStart (install =None ,over =False ):#line:2405
	if KEEPTRAKT =='true':#line:2406
		traktit .autoUpdate ('all')#line:2407
		wiz .setS ('traktlastsave',str (THREEDAYS ))#line:2408
	if KEEPREAL =='true':#line:2409
		debridit .autoUpdate ('all')#line:2410
		wiz .setS ('debridlastsave',str (THREEDAYS ))#line:2411
	if KEEPLOGIN =='true':#line:2412
		loginit .autoUpdate ('all')#line:2413
		wiz .setS ('loginlastsave',str (THREEDAYS ))#line:2414
	if over ==True :O0OOOO0OOO0O000O0 =1 #line:2415
	elif install =='restore':O0OOOO0OOO0O000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]  [B][COLOR springgreen] -  עליך לאשר  - [/COLOR][/B]"%COLOR2 ,"מחיקת בילד נוכחי ולאחר מכן שחזר  מקובץ [/COLOR]",nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR springgreen]אשר[/COLOR][/B]')#line:2416
	elif install :O0OOOO0OOO0O000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s] [B][COLOR springgreen] שים לב!  [/COLOR][/B]"%COLOR2 ,"יותקן כעת לאחר מחיקה של קבצי הקודי הנוכחים  [COLOR %s]%s[/COLOR]!!!"%(COLOR1 ,install ),nolabel ='[B][COLOR red]לא, בטל [/COLOR][/B]',yeslabel ='[B][COLOR springgreen]כן, המשך [/COLOR][/B]')#line:2417
	else :O0OOOO0OOO0O000O0 =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]Do you wish to restore your"%COLOR2 ,"Configuration to default settings?[/COLOR]",nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR springgreen]Yes[/COLOR][/B]')#line:2418
	if O0OOOO0OOO0O000O0 :#line:2419
		if not wiz .currSkin ()in ['skin.confluence','skin.estuary','skin.pellucid','skin.myconfluence','skin.estuary','skin.eminence.2.mod','skin.aeon.nox.silvo','skin.phenomenal']:#line:2420
			OO0O0000O0OOOO00O ='skin.confluence'if KODIV <17 else 'skin.estuary'if KODIV <17 else 'skin.eminence.2.mod'if KODIV <17 else 'skin.myconfluence'if KODIV <17 else 'skin.phenomenal'if KODIV <17 else 'skin.aeon.nox.silvo'if KODIV <17 else 'skin.pellucid'#line:2421
			skinSwitch .swapSkins (OO0O0000O0OOOO00O )#line:2424
			O00OOO0O0000O0000 =0 #line:2425
			xbmc .sleep (1000 )#line:2426
			while not xbmc .getCondVisibility ("Window.isVisible(yesnodialog)")and O00OOO0O0000O0000 <150 :#line:2427
				O00OOO0O0000O0000 +=1 #line:2428
				xbmc .sleep (200 )#line:2429
				wiz .ebi ('SendAction(Select)')#line:2430
			if xbmc .getCondVisibility ("Window.isVisible(yesnodialog)"):#line:2431
				wiz .ebi ('SendClick(11)')#line:2432
			else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: תם זמן החלפת מעטפת [/COLOR]'%COLOR2 );return False #line:2433
			xbmc .sleep (1000 )#line:2434
		if not wiz .currSkin ()in ['skin.confluence','skin.estuary','skin.pellucid','skin.estuary','skin.eminence.2.mod','skin.aeon.nox.silvo','skin.phenomenal']:#line:2435
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]התקנה נקיה: החלפה נכשלה[/COLOR]'%COLOR2 )#line:2436
			return #line:2437
		wiz .addonUpdates ('set')#line:2438
		O00000OOO0OOO00OO =os .path .abspath (HOME )#line:2439
		DP .create (ADDONTITLE ,"[COLOR %s]מחשב קבצים וספריות"%COLOR2 ,'','אנא המתן![/COLOR]')#line:2440
		O000OO00O00O0O000 =sum ([len (O000O0OO000OOOOO0 )for OOOO0O0OO0OOOO0O0 ,OO000O0O0O0O000OO ,O000O0OO000OOOOO0 in os .walk (O00000OOO0OOO00OO )]);O000O0O00O0OO00OO =0 #line:2441
		DP .update (0 ,"[COLOR %s]Gathering Excludes list."%COLOR2 )#line:2442
		EXCLUDES .append ('My_Builds')#line:2443
		EXCLUDES .append ('archive_cache')#line:2444
		if KEEPREPOS =='true':#line:2445
			OOOOO000OO00000OO =glob .glob (os .path .join (ADDONS ,'repo*/'))#line:2446
			for O0OO0OOO000O0O0O0 in OOOOO000OO00000OO :#line:2447
				O00O00OOOO0O00OOO =os .path .split (O0OO0OOO000O0O0O0 [:-1 ])[1 ]#line:2448
				if not O00O00OOOO0O00OOO ==EXCLUDES :#line:2449
					EXCLUDES .append (O00O00OOOO0O00OOO )#line:2450
		if KEEPSUPER =='true':#line:2451
			EXCLUDES .append ('plugin.program.super.favourites')#line:2452
		if KEEPWHITELIST =='true':#line:2453
			O000OOO00O0O00OO0 =''#line:2454
			O00O0OOOOOO0OO000 =wiz .whiteList ('read')#line:2455
			if len (O00O0OOOOOO0OO000 )>0 :#line:2456
				for O0OO0OOO000O0O0O0 in O00O0OOOOOO0OO000 :#line:2457
					try :OOO0000O00OO0O000 ,O00OO00O0OO000OO0 ,OOOO00000000OO0OO =O0OO0OOO000O0O0O0 #line:2458
					except :pass #line:2459
					if OOOO00000000OO0OO .startswith ('pvr'):O000OOO00O0O00OO0 =O00OO00O0OO000OO0 #line:2460
					OOO00O000O000OO00 =dependsList (OOOO00000000OO0OO )#line:2461
					for OO0O00O0OOO0O00O0 in OOO00O000O000OO00 :#line:2462
						if not OO0O00O0OOO0O00O0 in EXCLUDES :#line:2463
							EXCLUDES .append (OO0O00O0OOO0O00O0 )#line:2464
						O0OO000OOOO00O0O0 =dependsList (OO0O00O0OOO0O00O0 )#line:2465
						for O00O0O000O000000O in O0OO000OOOO00O0O0 :#line:2466
							if not O00O0O000O000000O in EXCLUDES :#line:2467
								EXCLUDES .append (O00O0O000O000000O )#line:2468
					if not OOOO00000000OO0OO in EXCLUDES :#line:2469
						EXCLUDES .append (OOOO00000000OO0OO )#line:2470
				if not O000OOO00O0O00OO0 =='':wiz .setS ('pvrclient',OOOO00000000OO0OO )#line:2471
		if wiz .getS ('pvrclient')=='':#line:2472
			for O0OO0OOO000O0O0O0 in EXCLUDES :#line:2473
				if O0OO0OOO000O0O0O0 .startswith ('pvr'):#line:2474
					wiz .setS ('pvrclient',O0OO0OOO000O0O0O0 )#line:2475
		DP .update (0 ,"[COLOR %s] מנקה קבצים וספריות"%COLOR2 )#line:2476
		O0000O0OOO00OO0OO =wiz .latestDB ('Addons')#line:2477
		for OOO0000O0OO0000OO ,OO00OO0O0O000OO00 ,O0000O000O0O0O0O0 in os .walk (O00000OOO0OOO00OO ,topdown =True ):#line:2478
			OO00OO0O0O000OO00 [:]=[O0OOOOOO00O0O0000 for O0OOOOOO00O0O0000 in OO00OO0O0O000OO00 if O0OOOOOO00O0O0000 not in EXCLUDES ]#line:2479
			for OOO0000O00OO0O000 in O0000O000O0O0O0O0 :#line:2480
				O000O0O00O0OO00OO +=1 #line:2481
				OOOO00000000OO0OO =OOO0000O0OO0000OO .replace ('/','\\').split ('\\')#line:2482
				O00OOO0O0000O0000 =len (OOOO00000000OO0OO )-1 #line:2483
				if OOO0000O00OO0O000 =='sources.xml'and OOOO00000000OO0OO [-1 ]=='userdata'and KEEPSOURCES =='true':wiz .log ("Keep Sources: %s"%os .path .join (OOO0000O0OO0000OO ,OOO0000O00OO0O000 ),xbmc .LOGNOTICE )#line:2484
				elif OOO0000O00OO0O000 =='favourites.xml'and OOOO00000000OO0OO [-1 ]=='userdata'and KEEPFAVS =='true':wiz .log ("Keep Favourites: %s"%os .path .join (OOO0000O0OO0000OO ,OOO0000O00OO0O000 ),xbmc .LOGNOTICE )#line:2485
				elif OOO0000O00OO0O000 =='profiles.xml'and OOOO00000000OO0OO [-1 ]=='userdata'and KEEPPROFILES =='true':wiz .log ("Keep Profiles: %s"%os .path .join (OOO0000O0OO0000OO ,OOO0000O00OO0O000 ),xbmc .LOGNOTICE )#line:2486
				elif OOO0000O00OO0O000 =='advancedsettings.xml'and OOOO00000000OO0OO [-1 ]=='userdata'and KEEPADVANCED =='true':wiz .log ("Keep Advanced Settings: %s"%os .path .join (OOO0000O0OO0000OO ,OOO0000O00OO0O000 ),xbmc .LOGNOTICE )#line:2487
				elif OOO0000O00OO0O000 in LOGFILES :wiz .log ("Keep Log File: %s"%OOO0000O00OO0O000 ,xbmc .LOGNOTICE )#line:2488
				elif OOO0000O00OO0O000 .endswith ('.db'):#line:2489
					try :#line:2490
						if OOO0000O00OO0O000 ==O0000O0OOO00OO0OO and KODIV >=17 :wiz .log ("Ignoring %s on v%s"%(OOO0000O00OO0O000 ,KODIV ),xbmc .LOGNOTICE )#line:2491
						else :os .remove (os .path .join (OOO0000O0OO0000OO ,OOO0000O00OO0O000 ))#line:2492
					except Exception as O0OO00OOO0OOO0000 :#line:2493
						if not OOO0000O00OO0O000 .startswith ('Textures13'):#line:2494
							wiz .log ('Failed to delete, Purging DB',xbmc .LOGNOTICE )#line:2495
							wiz .log ("-> %s"%(str (O0OO00OOO0OOO0000 )),xbmc .LOGNOTICE )#line:2496
							wiz .purgeDb (os .path .join (OOO0000O0OO0000OO ,OOO0000O00OO0O000 ))#line:2497
				else :#line:2498
					DP .update (int (wiz .percentage (O000O0O00O0OO00OO ,O000OO00O00O0O000 )),'','[COLOR %s] קובץ [/COLOR][COLOR %s]%s[/COLOR]'%(COLOR2 ,COLOR1 ,OOO0000O00OO0O000 ),'')#line:2499
					try :os .remove (os .path .join (OOO0000O0OO0000OO ,OOO0000O00OO0O000 ))#line:2500
					except Exception as O0OO00OOO0OOO0000 :#line:2501
						wiz .log ("Error removing %s"%os .path .join (OOO0000O0OO0000OO ,OOO0000O00OO0O000 ),xbmc .LOGNOTICE )#line:2502
						wiz .log ("-> / %s"%(str (O0OO00OOO0OOO0000 )),xbmc .LOGNOTICE )#line:2503
			if DP .iscanceled ():#line:2504
				DP .close ()#line:2505
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Fresh Start Cancelled[/COLOR]"%COLOR2 )#line:2506
				return False #line:2507
		for OOO0000O0OO0000OO ,OO00OO0O0O000OO00 ,O0000O000O0O0O0O0 in os .walk (O00000OOO0OOO00OO ,topdown =True ):#line:2508
			OO00OO0O0O000OO00 [:]=[OOOO0O00O0O0O0O00 for OOOO0O00O0O0O0O00 in OO00OO0O0O000OO00 if OOOO0O00O0O0O0O00 not in EXCLUDES ]#line:2509
			for OOO0000O00OO0O000 in OO00OO0O0O000OO00 :#line:2510
				DP .update (100 ,'','Cleaning Up Empty Folder: [COLOR %s]%s[/COLOR]'%(COLOR1 ,OOO0000O00OO0O000 ),'')#line:2511
				if OOO0000O00OO0O000 not in ["Database","userdata","temp","addons","addon_data"]:#line:2512
					shutil .rmtree (os .path .join (OOO0000O0OO0000OO ,OOO0000O00OO0O000 ),ignore_errors =True ,onerror =None )#line:2513
			if DP .iscanceled ():#line:2514
				DP .close ()#line:2515
				wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Fresh Start Cancelled[/COLOR]"%COLOR2 )#line:2516
				return False #line:2517
		DP .close ()#line:2518
		wiz .clearS ('build')#line:2519
		if over ==True :#line:2520
			return True #line:2521
		elif install =='restore':#line:2522
			return True #line:2523
		elif install :#line:2524
			buildWizard (install ,'normal',over =True )#line:2525
		else :#line:2526
			if INSTALLMETHOD ==1 :O00O00O00000OO0OO =1 #line:2527
			elif INSTALLMETHOD ==2 :O00O00O00000OO0OO =0 #line:2528
			else :O00O00O00000OO0OO =DIALOG .yesno (ADDONTITLE ,"[COLOR %s]You Need To [COLOR %s]Force close[/COLOR] This App [COLOR %s]And[/COLOR] Then Restart It Again[/COLOR]"%(COLOR2 ,COLOR1 ,COLOR1 ),yeslabel ="[B][COLOR white]>>>>>>[/COLOR][/B]",nolabel ="[B][COLOR springgreen]Force Close[/COLOR][/B]")#line:2529
			if O00O00O00000OO0OO ==1 :wiz .reloadFix ('fresh')#line:2530
			else :wiz .addonUpdates ('reset');wiz .killxbmc (True )#line:2531
	else :#line:2532
		if not install =='restore':#line:2533
			wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),'[COLOR %s]Fresh Install: Cancelled![/COLOR]'%COLOR2 )#line:2534
			wiz .refresh ()#line:2535
def clearCache ():#line:2541
	if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם לנקות זכרון מטמון?[/COLOR]'%COLOR2 ,nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]נקה מטמון[/COLOR][/B]'):#line:2542
		wiz .clearCache ()#line:2543
		DC .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2544
def clearArchive ():#line:2545
	if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם תרצה לנקות את ספריית  \'Archive_Cache\' [/COLOR]'%COLOR2 ,nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]כן נקה[/COLOR][/B]'):#line:2546
		wiz .clearArchive ()#line:2547
def clearPackages ():#line:2548
	if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם למחוק את חבילות ההתקנה?[/COLOR]'%COLOR2 ,nolabel ='[B][COLOR red]לא, בטל[/COLOR][/B]',yeslabel ='[B][COLOR green]מחק[/COLOR][/B]'):#line:2549
		wiz .clearPackages ('total')#line:2550
		DPK .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2551
		TPK .setLabel ('-קבצים  [B][COLOR lime]0[/B][/COLOR]')#line:2552
def totalClean ():#line:2554
	if DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם לנקות  תמונות, חבילות ומטמון?[/COLOR]'%COLOR2 ,nolabel ='[B][COLOR red]בטל תהליך[/COLOR][/B]',yeslabel ='[B][COLOR green]נקה הכל[/COLOR][/B]'):#line:2555
		wiz .clearCache ()#line:2556
		wiz .clearPackages ('total')#line:2557
		clearThumb ('total')#line:2558
		TC .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2559
		DC .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2560
		DPK .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2561
		TPK .setLabel ('-קבצים  [B][COLOR lime]0[/B][/COLOR]')#line:2562
		DTH .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2563
		TTH .setLabel ('-קבצים  [B][COLOR lime]0[/B][/COLOR]')#line:2564
def clearThumb (type =None ):#line:2565
	O0O0OO0OOO0O0O00O =wiz .latestDB ('Textures')#line:2566
	if not type ==None :O0OO0O0O00OOO000O =1 #line:2567
	else :O0OO0O0O00OOO000O =DIALOG .yesno (ADDONTITLE ,'[COLOR %s]האם תרצה למחוק את  %s ואת ספריית התמונות? '%(COLOR2 ,O0O0OO0OOO0O0O00O ),"הם ימוקמו מחדש לאחר הפעלה. [/COLOR]",nolabel ='[B][COLOR red]אל תמחק[/COLOR][/B]',yeslabel ='[B][COLOR green]מחק קבצים[/COLOR][/B]')#line:2568
	if O0OO0O0O00OOO000O ==1 :#line:2569
		try :wiz .removeFile (os .join (DATABASE ,O0O0OO0OOO0O0O00O ))#line:2570
		except :wiz .log ('Failed to delete, Purging DB.');wiz .purgeDb (O0O0OO0OOO0O0O00O )#line:2571
		wiz .removeFolder (THUMBS )#line:2572
		DTH .setLabel ('-גודל [B][COLOR lime]0.0 B[/B][/COLOR]')#line:2573
		TTH .setLabel ('-קבצים  [B][COLOR lime]0[/B][/COLOR]')#line:2574
	else :wiz .log ('Clear thumbnames cancelled')#line:2575
	wiz .redoThumbs ()#line:2576
def purgeDb ():#line:2577
	OO000OOOO0OO00OO0 =[];O0O0000O0OOO0OOOO =[]#line:2578
	for OOO0OO0O0OO0OOOO0 ,OO0O00000O0OOOOOO ,O0O0O0OO0OOOO00OO in os .walk (HOME ):#line:2579
		for O0OO00OO000OO00O0 in fnmatch .filter (O0O0O0OO0OOOO00OO ,'*.db'):#line:2580
			if O0OO00OO000OO00O0 !='Thumbs.db':#line:2581
				OOO00OO0OOOO0O000 =os .path .join (OOO0OO0O0OO0OOOO0 ,O0OO00OO000OO00O0 )#line:2582
				OO000OOOO0OO00OO0 .append (OOO00OO0OOOO0O000 )#line:2583
				O00OO0O00OOOO0O00 =OOO00OO0OOOO0O000 .replace ('\\','/').split ('/')#line:2584
				O0O0000O0OOO0OOOO .append ('(%s) %s'%(O00OO0O00OOOO0O00 [len (O00OO0O00OOOO0O00 )-2 ],O00OO0O00OOOO0O00 [len (O00OO0O00OOOO0O00 )-1 ]))#line:2585
	if KODIV >=16 :#line:2586
		OO00OOO0OO0OO0O0O =DIALOG .multiselect ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0000O0OOO0OOOO )#line:2587
		if OO00OOO0OO0OO0O0O ==None :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:2588
		elif len (OO00OOO0OO0OO0O0O )==0 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:2589
		else :#line:2590
			for O0OO000O0OO0000O0 in OO00OOO0OO0OO0O0O :wiz .purgeDb (OO000OOOO0OO00OO0 [O0OO000O0OO0000O0 ])#line:2591
	else :#line:2592
		OO00OOO0OO0OO0O0O =DIALOG .select ("[COLOR %s]Select DB File to Purge[/COLOR]"%COLOR2 ,O0O0000O0OOO0OOOO )#line:2593
		if OO00OOO0OO0OO0O0O ==-1 :wiz .LogNotify ("[COLOR %s]Purge Database[/COLOR]"%COLOR1 ,"[COLOR %s]Cancelled[/COLOR]"%COLOR2 )#line:2594
		else :wiz .purgeDb (OO000OOOO0OO00OO0 [O0OO000O0OO0000O0 ])#line:2595
def Add_Directory_Item (O00O0OOO0000O0O00 ,O0OO0O00OOOOOO0OO ,O000O000000OOOO0O ,OOO0O0O0OO000O0O0 ):#line:2624
	xbmcplugin .addDirectoryItem (O00O0OOO0000O0O00 ,O0OO0O00OOOOOO0OO ,O000O000000OOOO0O ,OOO0O0O0OO000O0O0 )#line:2625
def addDir2 (O00OOOOO00O00OO0O ,OO0O0OO00OOO0O0OO ,OO0OO0O00O00OO0OO ,O0OO0O0OOOO0OO00O ,OOO0O000O00OO000O ):#line:2626
		O0O0O0OOO000OOOOO =sys .argv [0 ]+"?url="+urllib .quote_plus (OO0O0OO00OOO0O0OO )+"&mode="+str (OO0OO0O00O00OO0OO )+"&name="+urllib .quote_plus (O00OOOOO00O00OO0O )+"&iconimage="+urllib .quote_plus (O0OO0O0OOOO0OO00O )#line:2627
		OOOO0O0O0OO0O0000 =True #line:2628
		OOO0OOO000000O000 =xbmcgui .ListItem (O00OOOOO00O00OO0O ,iconImage ="DefaultFolder.png",thumbnailImage =O0OO0O0OOOO0OO00O )#line:2629
		OOO0OOO000000O000 .setInfo (type ="Video",infoLabels ={"Title":O00OOOOO00O00OO0O ,"Plot":O00OOOOO00O00OO0O })#line:2630
		OOO0OOO000000O000 .setProperty ('fanart_image',OOO0O000O00OO000O )#line:2631
		OOOO0O0O0OO0O0000 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O0O0O0OOO000OOOOO ,listitem =OOO0OOO000000O000 ,isFolder =True )#line:2632
		return OOOO0O0O0OO0O0000 #line:2633
def addFolder (O00OO0OO0OOOO0O00 ,O00OO0O0OO00OO0O0 ,O00O0OOO0O0O00OOO ,O000O00O0O00OOOOO ,iconimage ='',FanArt ='',video ='',description =''):#line:2634
	if O00OO0OO0OOOO0O00 !='folder2'and O00OO0OO0OOOO0O00 !='addon':#line:2635
		if len (iconimage )>0 :#line:2636
			iconimage =Images +iconimage #line:2637
		else :#line:2638
			iconimage ='DefaultFolder.png'#line:2639
	if O00OO0OO0OOOO0O00 =='addon':#line:2640
		if len (iconimage )>0 :#line:2641
			iconimage =iconimage #line:2642
		else :#line:2643
			iconimage ='none'#line:2644
	if FanArt =='':#line:2645
		FanArt =FanArt #line:2646
	OOO0O0000OO0O0OOO =sys .argv [0 ]+"?url="+urllib .quote_plus (O00O0OOO0O0O00OOO )+"&mode="+str (O000O00O0O00OOOOO )+"&name="+urllib .quote_plus (O00OO0O0OO00OO0O0 )+"&FanArt="+urllib .quote_plus (FanArt )+"&video="+urllib .quote_plus (video )+"&description="+urllib .quote_plus (description )#line:2647
	OOO00O0000000O00O =True #line:2648
	OO0OO000O000O0OO0 =xbmcgui .ListItem (O00OO0O0OO00OO0O0 ,iconImage ="DefaultFolder.png",thumbnailImage =iconimage )#line:2649
	OO0OO000O000O0OO0 .setInfo (type ="Video",infoLabels ={"Title":O00OO0O0OO00OO0O0 ,"Plot":description })#line:2650
	OO0OO000O000O0OO0 .setProperty ("FanArt_Image",FanArt )#line:2651
	OO0OO000O000O0OO0 .setProperty ("Build.Video",video )#line:2652
	if (O00OO0OO0OOOO0O00 =='folder')or (O00OO0OO0OOOO0O00 =='folder2')or (O00OO0OO0OOOO0O00 =='tutorial_folder')or (O00OO0OO0OOOO0O00 =='news_folder'):#line:2653
		OOO00O0000000O00O =Add_Directory_Item (handle =int (sys .argv [1 ]),url =OOO0O0000OO0O0OOO ,listitem =OO0OO000O000O0OO0 ,isFolder =True )#line:2654
	else :#line:2655
		OOO00O0000000O00O =Add_Directory_Item (handle =int (sys .argv [1 ]),url =OOO0O0000OO0O0OOO ,listitem =OO0OO000O000O0OO0 ,isFolder =False )#line:2656
	return OOO00O0000000O00O #line:2657
def addDir (OOO00O000OO0O00O0 ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:2658
	OOO00O000000OO000 =sys .argv [0 ]#line:2659
	if not mode ==None :OOO00O000000OO000 +="?mode=%s"%urllib .quote_plus (mode )#line:2660
	if not name ==None :OOO00O000000OO000 +="&name="+urllib .quote_plus (name )#line:2661
	if not url ==None :OOO00O000000OO000 +="&url="+urllib .quote_plus (url )#line:2662
	OOOO0OOOO0OO00OO0 =True #line:2663
	if themeit :OOO00O000OO0O00O0 =themeit %OOO00O000OO0O00O0 #line:2664
	O000OOO00O0OO000O =xbmcgui .ListItem (OOO00O000OO0O00O0 ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:2665
	O000OOO00O0OO000O .setInfo (type ="Video",infoLabels ={"Title":OOO00O000OO0O00O0 ,"Plot":description })#line:2666
	O000OOO00O0OO000O .setProperty ("Fanart_Image",fanart )#line:2667
	if not menu ==None :O000OOO00O0OO000O .addContextMenuItems (menu ,replaceItems =overwrite )#line:2668
	OOOO0OOOO0OO00OO0 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =OOO00O000000OO000 ,listitem =O000OOO00O0OO000O ,isFolder =True )#line:2669
	return OOOO0OOOO0OO00OO0 #line:2670
def addFile (O00O0OOO0OO00O00O ,mode =None ,name =None ,url =None ,menu =None ,description =ADDONTITLE ,overwrite =True ,fanart =FANART ,icon =ICON ,themeit =None ):#line:2671
	O000OO0O00OOO00O0 =sys .argv [0 ]#line:2672
	if not mode ==None :O000OO0O00OOO00O0 +="?mode=%s"%urllib .quote_plus (mode )#line:2673
	if not name ==None :O000OO0O00OOO00O0 +="&name="+urllib .quote_plus (name )#line:2674
	if not url ==None :O000OO0O00OOO00O0 +="&url="+urllib .quote_plus (url )#line:2675
	OO000O0OO0000OO00 =True #line:2676
	if themeit :O00O0OOO0OO00O00O =themeit %O00O0OOO0OO00O00O #line:2677
	O0OO0O0000OOOOO0O =xbmcgui .ListItem (O00O0OOO0OO00O00O ,iconImage ="DefaultFolder.png",thumbnailImage =icon )#line:2678
	O0OO0O0000OOOOO0O .setInfo (type ="Video",infoLabels ={"Title":O00O0OOO0OO00O00O ,"Plot":description })#line:2679
	O0OO0O0000OOOOO0O .setProperty ("Fanart_Image",fanart )#line:2680
	if not menu ==None :O0OO0O0000OOOOO0O .addContextMenuItems (menu ,replaceItems =overwrite )#line:2681
	OO000O0OO0000OO00 =xbmcplugin .addDirectoryItem (handle =int (sys .argv [1 ]),url =O000OO0O00OOO00O0 ,listitem =O0OO0O0000OOOOO0O ,isFolder =False )#line:2682
	return OO000O0OO0000OO00 #line:2683
def get_params ():#line:2684
	OOO000O000OO00O0O =[]#line:2685
	OO0O0OOO0OO0O00OO =sys .argv [2 ]#line:2686
	if len (OO0O0OOO0OO0O00OO )>=2 :#line:2687
		O0OO0000000OO00O0 =sys .argv [2 ]#line:2688
		O0OO00O0OO00O00O0 =O0OO0000000OO00O0 .replace ('?','')#line:2689
		if (O0OO0000000OO00O0 [len (O0OO0000000OO00O0 )-1 ]=='/'):#line:2690
			O0OO0000000OO00O0 =O0OO0000000OO00O0 [0 :len (O0OO0000000OO00O0 )-2 ]#line:2691
		O000OO000OOOOOO0O =O0OO00O0OO00O00O0 .split ('&')#line:2692
		OOO000O000OO00O0O ={}#line:2693
		for O00OO00O0OO00OO0O in range (len (O000OO000OOOOOO0O )):#line:2694
			O00OO00OOOO0O00OO ={}#line:2695
			O00OO00OOOO0O00OO =O000OO000OOOOOO0O [O00OO00O0OO00OO0O ].split ('=')#line:2696
			if (len (O00OO00OOOO0O00OO ))==2 :#line:2697
				OOO000O000OO00O0O [O00OO00OOOO0O00OO [0 ]]=O00OO00OOOO0O00OO [1 ]#line:2698
		return OOO000O000OO00O0O #line:2699
if len (sys .argv )>1 :#line:2700
    params =get_params ()#line:2701
url =None #line:2702
name =None #line:2703
mode =None #line:2704
try :mode =urllib .unquote_plus (params ["mode"])#line:2705
except :pass #line:2706
try :name =urllib .unquote_plus (params ["name"])#line:2707
except :pass #line:2708
try :url =urllib .unquote_plus (params ["url"])#line:2709
except :pass #line:2710
def setView (O00OO00O000000O00 ,OO00O000O00OOOO0O ):#line:2712
	if wiz .getS ('auto-view')=='true':#line:2713
		OO0OOOOO00000O0OO =wiz .getS (OO00O000O00OOOO0O )#line:2714
		if OO0OOOOO00000O0OO =='50'and KODIV >=17 and SKIN =='skin.estuary':OO0OOOOO00000O0OO ='55'#line:2715
		if OO0OOOOO00000O0OO =='500'and KODIV >=17 and SKIN =='skin.estuary':OO0OOOOO00000O0OO ='50'#line:2716
		wiz .ebi ("Container.SetViewMode(%s)"%OO0OOOOO00000O0OO )#line:2717
wiz .FTGlog ('<Must remain to get any support>')#line:2725
FOCUS_BUTTON_COLOR =uservar .FOCUS_BUTTON_COLOR #line:2726
DESCOLOR =uservar .DESCOLOR #line:2727
DES_T_COLOR =uservar .DES_T_COLOR #line:2728
MAIN_BUTTONS_TEXT =uservar .MAIN_BUTTONS_TEXT #line:2729
OTHER_BUTTONS_TEXT =uservar .OTHER_BUTTONS_TEXT #line:2730
LIST_TEXT =uservar .LIST_TEXT #line:2731
HIGHLIGHT_LIST =uservar .HIGHLIGHT_LIST #line:2732
net =net .Net ()#line:2734
window =pyxbmct .AddonDialogWindow ('')#line:2735
EXIT =os .path .join (ART ,'%s.png'%uservar .EXIT_BUTTON_COLOR )#line:2736
FBUTTON =os .path .join (ART ,'%s.png'%FOCUS_BUTTON_COLOR )#line:2737
LBUTTON =os .path .join (ART ,'%s.png'%HIGHLIGHT_LIST )#line:2738
BUTTON =os .path .join (ART ,'button.png')#line:2739
LISTBG =os .path .join (ART ,'listbg.png')#line:2740
SPLASH =os .path .join (ART ,'splash.jpg')#line:2741
SpeedBG =os .path .join (ART ,'speedtest.jpg')#line:2742
MAINBG =os .path .join (ART ,'main.jpg')#line:2743
NOTXT =os .path .join (ART ,'%s.gif'%uservar .NO_TXT_FILE )#line:2744
def playVideoB (OOOOOOOO0O00OO000 ):#line:2767
	if 'watch?v='in OOOOOOOO0O00OO000 :#line:2768
		O0000OO00000O0OOO ,OOO0OO0000OOOOOO0 =OOOOOOOO0O00OO000 .split ('?')#line:2769
		O00O0O0OOO00OO00O =OOO0OO0000OOOOOO0 .split ('&')#line:2770
		for OOOOOOOO0O0OOO00O in O00O0O0OOO00OO00O :#line:2771
			if OOOOOOOO0O0OOO00O .startswith ('v='):#line:2772
				OOOOOOOO0O00OO000 =OOOOOOOO0O0OOO00O [2 :]#line:2773
				break #line:2774
			else :continue #line:2775
	elif 'embed'in OOOOOOOO0O00OO000 or 'youtu.be'in OOOOOOOO0O00OO000 :#line:2776
		O0000OO00000O0OOO =OOOOOOOO0O00OO000 .split ('/')#line:2777
		if len (O0000OO00000O0OOO [-1 ])>5 :#line:2778
			OOOOOOOO0O00OO000 =O0000OO00000O0OOO [-1 ]#line:2779
		elif len (O0000OO00000O0OOO [-2 ])>5 :#line:2780
			OOOOOOOO0O00OO000 =O0000OO00000O0OOO [-2 ]#line:2781
	wiz .log ("YouTube URL: %s"%OOOOOOOO0O00OO000 )#line:2782
	notify .Preview (OOOOOOOO0O00OO000 )#line:2783
def runspeedtest ():#line:2785
	OO00O0O0000OOO0OO =speedtest .speedtest ()#line:2786
	speedthumb .setImage (OO00O0O0000OOO0OO [0 ])#line:2787
def HIDEALL ():#line:2789
	try :#line:2790
		InstallButtonROM .setVisible (False )#line:2791
	except :pass #line:2792
	try :#line:2793
		InstallButtonEMU .setVisible (False )#line:2794
	except :pass #line:2795
	try :#line:2796
		no_txt .setVisible (False )#line:2797
	except :pass #line:2798
	try :#line:2799
		splash .setVisible (False )#line:2800
	except :pass #line:2801
	try :#line:2802
		AddonButton .setVisible (False )#line:2803
	except :pass #line:2804
	try :#line:2805
		APKButton .setVisible (False )#line:2806
	except :pass #line:2807
	try :#line:2808
		ROMButton .setVisible (False )#line:2809
	except :pass #line:2810
	try :#line:2811
		EmuButton .setVisible (False )#line:2812
	except :pass #line:2813
	try :#line:2814
		InstallButton .setVisible (False )#line:2815
	except :pass #line:2816
	try :#line:2817
		FreshStartButton .setVisible (False )#line:2818
	except :pass #line:2819
	try :#line:2820
		listbg .setVisible (False )#line:2821
	except :pass #line:2822
	try :#line:2823
		no_txt .setVisible (False )#line:2824
	except :pass #line:2825
	try :#line:2826
		splash .setVisible (False )#line:2827
	except :pass #line:2828
	try :#line:2829
		speedthumb .setVisible (False )#line:2830
	except :pass #line:2831
	try :#line:2832
		buildlist .setVisible (False )#line:2833
	except :pass #line:2834
	try :#line:2835
		PreviewButton .setVisible (False )#line:2836
	except :pass #line:2837
	try :#line:2838
		ThemeButton .setVisible (False )#line:2839
	except :pass #line:2840
	try :#line:2841
		buildinfobg .setVisible (False )#line:2842
	except :pass #line:2843
	try :#line:2844
		buildbg .setVisible (False )#line:2845
	except :pass #line:2846
	try :#line:2847
		buildthumb .setVisible (False )#line:2848
	except :pass #line:2849
	try :#line:2850
		buildtextbox .setVisible (False )#line:2851
	except :pass #line:2852
	try :#line:2853
		vertextbox .setVisible (False )#line:2854
	except :pass #line:2855
	try :#line:2856
		koditextbox .setVisible (False )#line:2857
	except :pass #line:2858
	try :#line:2859
		desctextbox .setVisible (False )#line:2860
	except :pass #line:2861
	try :#line:2862
		addthumb .setVisible (False )#line:2863
	except :pass #line:2864
	try :#line:2865
		InstallButtonA .setVisible (False )#line:2866
	except :pass #line:2867
	try :#line:2868
		addonlist .setVisible (False )#line:2869
	except :pass #line:2870
	try :#line:2871
		addthumb .setVisible (False )#line:2872
	except :pass #line:2873
	try :#line:2874
		desctextboxA .setVisible (False )#line:2875
	except :pass #line:2876
	try :#line:2877
		addtextbox .setVisible (False )#line:2878
	except :pass #line:2879
	try :#line:2880
		listbgA .setVisible (False )#line:2881
	except :pass #line:2882
	try :#line:2883
		buildbgA .setVisible (False )#line:2884
	except :pass #line:2885
	try :#line:2886
		apkthumb .setVisible (False )#line:2887
	except :pass #line:2888
	try :#line:2889
		apklist .setVisible (False )#line:2890
	except :pass #line:2891
	try :#line:2892
		apkthumb .setVisible (False )#line:2893
	except :pass #line:2894
	try :#line:2895
		apktextbox .setVisible (False )#line:2896
	except :pass #line:2897
	try :#line:2898
		desctextboxAPK .setVisible (False )#line:2899
	except :pass #line:2900
	try :#line:2901
		InstallButtonAPK .setVisible (False )#line:2902
	except :pass #line:2903
	try :#line:2904
		emulist .setVisible (False )#line:2905
	except :pass #line:2906
	try :#line:2907
		emuthumb .setVisible (False )#line:2908
	except :pass #line:2909
	try :#line:2910
		desctextboxEMU .setVisible (False )#line:2911
	except :pass #line:2912
	try :#line:2913
		emutextbox .setVisible (False )#line:2914
	except :pass #line:2915
	try :#line:2916
		InstallButtonEMU .setVisible (False )#line:2917
	except :pass #line:2918
	try :#line:2919
		romlist .setVisible (False )#line:2920
	except :pass #line:2921
	try :#line:2922
		romthumb .setVisible (False )#line:2923
	except :pass #line:2924
	try :#line:2925
		desctextboxROM .setVisible (False )#line:2926
	except :pass #line:2927
	try :#line:2928
		romtextbox .setVisible (False )#line:2929
	except :pass #line:2930
	try :#line:2931
		InstallButtonROM .setVisible (False )#line:2932
	except :pass #line:2933
	try :#line:2934
		maintbg .setVisible (False )#line:2935
	except :pass #line:2936
	try :#line:2937
		total_clean_button .setVisible (False )#line:2938
	except :pass #line:2939
	try :#line:2940
		total_cache_button .setVisible (False )#line:2941
	except :pass #line:2942
	try :#line:2943
		total_packages_button .setVisible (False )#line:2944
	except :pass #line:2945
	try :#line:2946
		total_thumbnails_button .setVisible (False )#line:2947
	except :pass #line:2948
	try :#line:2949
		TC .setVisible (False )#line:2950
	except :pass #line:2951
	try :#line:2952
		DC .setVisible (False )#line:2953
	except :pass #line:2954
	try :#line:2955
		DPK .setVisible (False )#line:2956
	except :pass #line:2957
	try :#line:2958
		DTH .setVisible (False )#line:2959
	except :pass #line:2960
	try :#line:2961
		TPK .setVisible (False )#line:2962
	except :pass #line:2963
	try :#line:2964
		TTH .setVisible (False )#line:2965
	except :pass #line:2966
	try :#line:2967
		sysinfobg .setVisible (False )#line:2968
	except :pass #line:2969
	try :#line:2970
		speedtest_button .setVisible (False )#line:2971
	except :pass #line:2972
	try :#line:2973
		sysinfo_title .setVisible (False )#line:2974
	except :pass #line:2975
	try :#line:2976
		version1 .setVisible (False )#line:2977
	except :pass #line:2978
	try :#line:2979
		store .setVisible (False )#line:2980
	except :pass #line:2981
	try :#line:2982
		rom_used .setVisible (False )#line:2983
	except :pass #line:2984
	try :#line:2985
		rom_free .setVisible (False )#line:2986
	except :pass #line:2987
	try :#line:2988
		rom_total .setVisible (False )#line:2989
	except :pass #line:2990
	try :#line:2991
		mem .setVisible (False )#line:2992
	except :pass #line:2993
	try :#line:2994
		ram_used .setVisible (False )#line:2995
	except :pass #line:2996
	try :#line:2997
		ram_free .setVisible (False )#line:2998
	except :pass #line:2999
	try :#line:3000
		ram_total .setVisible (False )#line:3001
	except :pass #line:3002
	try :#line:3003
		kodi .setVisible (False )#line:3004
	except :pass #line:3005
	try :#line:3006
		total .setVisible (False )#line:3007
	except :pass #line:3008
	try :#line:3009
		video .setVisible (False )#line:3010
	except :pass #line:3011
	try :#line:3012
		program .setVisible (False )#line:3013
	except :pass #line:3014
	try :#line:3015
		music .setVisible (False )#line:3016
	except :pass #line:3017
	try :#line:3018
		picture .setVisible (False )#line:3019
	except :pass #line:3020
	try :#line:3021
		repos .setVisible (False )#line:3022
	except :pass #line:3023
	try :#line:3024
		skins .setVisible (False )#line:3025
	except :pass #line:3026
	try :#line:3027
		scripts .setVisible (False )#line:3028
	except :pass #line:3029
	try :#line:3030
		netinfobg .setVisible (False )#line:3031
	except :pass #line:3032
	try :#line:3033
		netinfo_title .setVisible (False )#line:3034
	except :pass #line:3035
	try :#line:3036
		un_hide_net .setVisible (False )#line:3037
	except :pass #line:3038
	try :#line:3039
		settings_button1 .setVisible (False )#line:3040
	except :pass #line:3041
	try :#line:3042
		trigger_title .setVisible (False )#line:3043
	except :pass #line:3044
	try :#line:3045
		MAC .setVisible (False )#line:3046
	except :pass #line:3047
	try :#line:3048
		INTER_IP .setVisible (False )#line:3049
	except :pass #line:3050
	try :#line:3051
		IP .setVisible (False )#line:3052
	except :pass #line:3053
	try :#line:3054
		ISP .setVisible (False )#line:3055
	except :pass #line:3056
	try :#line:3057
		CITY .setVisible (False )#line:3058
	except :pass #line:3059
	try :#line:3060
		STATE .setVisible (False )#line:3061
	except :pass #line:3062
	try :#line:3063
		COUNTRY .setVisible (False )#line:3064
	except :pass #line:3065
	try :#line:3066
		bakresbg .setVisible (False )#line:3067
	except :pass #line:3068
	try :#line:3069
		favs .setVisible (False )#line:3070
	except :pass #line:3071
	try :#line:3072
		backuploc .setVisible (False )#line:3073
	except :pass #line:3074
	try :#line:3075
		Backup .setVisible (False )#line:3076
	except :pass #line:3077
	try :#line:3078
		backup_build_button .setVisible (False )#line:3079
	except :pass #line:3080
	try :#line:3081
		backup_gui_button .setVisible (False )#line:3082
	except :pass #line:3083
	try :#line:3084
		backup_addondata_button .setVisible (False )#line:3085
	except :pass #line:3086
	try :#line:3087
		restore_build_button .setVisible (False )#line:3088
	except :pass #line:3089
	try :#line:3090
		restore_gui_button .setVisible (False )#line:3091
	except :pass #line:3092
	try :#line:3093
		restore_addondata_button .setVisible (False )#line:3094
	except :pass #line:3095
	try :#line:3096
		clear_backup_button .setVisible (False )#line:3097
	except :pass #line:3098
	try :#line:3099
		savefav_button .setVisible (False )#line:3100
	except :pass #line:3101
	try :#line:3102
		restorefav_button .setVisible (False )#line:3103
	except :pass #line:3104
	try :#line:3105
		clearfav_button .setVisible (False )#line:3106
	except :pass #line:3107
	try :#line:3108
		backupaddonpack_button .setVisible (False )#line:3109
	except :pass #line:3110
	try :#line:3111
		restore_title .setVisible (False )#line:3112
	except :pass #line:3113
	try :#line:3114
		delete_title .setVisible (False )#line:3115
	except :pass #line:3116
	try :#line:3117
		set_title .setVisible (False )#line:3118
	except :pass #line:3119
	try :#line:3120
		settings_button .setVisible (False )#line:3121
	except :pass #line:3122
	try :#line:3123
		view_error_button .setVisible (False )#line:3124
	except :pass #line:3125
	try :#line:3126
		full_log_button .setVisible (False )#line:3127
	except :pass #line:3128
	try :#line:3129
		upload_log_button .setVisible (False )#line:3130
	except :pass #line:3131
	try :#line:3132
		removeaddons_button .setVisible (False )#line:3133
	except :pass #line:3134
	try :#line:3135
		removeaddondata_all_button .setVisible (False )#line:3136
	except :pass #line:3137
	try :#line:3138
		removeaddondata_u_button .setVisible (False )#line:3139
	except :pass #line:3140
	try :#line:3141
		removeaddondata_e_button .setVisible (False )#line:3142
	except :pass #line:3143
	try :#line:3144
		checksources_button .setVisible (False )#line:3145
	except :pass #line:3146
	try :#line:3147
		checkrepos_button .setVisible (False )#line:3148
	except :pass #line:3149
	try :#line:3150
		forceupdate_button .setVisible (False )#line:3151
	except :pass #line:3152
	try :#line:3153
		fixaddonupdate_button .setVisible (False )#line:3154
	except :pass #line:3155
	try :#line:3156
		Addon .setVisible (False )#line:3157
	except :pass #line:3158
	try :#line:3159
		scan .setVisible (False )#line:3160
	except :pass #line:3161
	try :#line:3162
		fix .setVisible (False )#line:3163
	except :pass #line:3164
	try :#line:3165
		delet .setVisible (False )#line:3166
	except :pass #line:3167
	try :#line:3168
		delet1 .setVisible (False )#line:3169
	except :pass #line:3170
	try :#line:3171
		Log_title .setVisible (False )#line:3172
	except :pass #line:3173
	try :#line:3174
		toolsbg .setVisible (False )#line:3175
	except :pass #line:3176
	try :#line:3177
		Log_errors .setVisible (False )#line:3178
	except :pass #line:3179
	try :#line:3180
		WhiteList .setVisible (False )#line:3181
	except :pass #line:3182
	try :#line:3183
		whitelist_edit_button .setVisible (False )#line:3184
	except :pass #line:3185
	try :#line:3186
		whitelist_view_button .setVisible (False )#line:3187
	except :pass #line:3188
	try :#line:3189
		whitelist_clear_button .setVisible (False )#line:3190
	except :pass #line:3191
	try :#line:3192
		whitelist_import_button .setVisible (False )#line:3193
	except :pass #line:3194
	try :#line:3195
		whitelist_export_button .setVisible (False )#line:3196
	except :pass #line:3197
	try :#line:3198
		Advan .setVisible (False )#line:3199
	except :pass #line:3200
	try :#line:3201
		autoadvanced_buttonQ .setVisible (False )#line:3202
	except :pass #line:3203
	try :#line:3204
		autoadvanced_button .setVisible (False )#line:3205
	except :pass #line:3206
	try :#line:3207
		currentsettings_button .setVisible (False )#line:3208
	except :pass #line:3209
	try :#line:3210
		removeadvanced_button .setVisible (False )#line:3211
	except :pass #line:3212
	try :#line:3213
		buildname .setVisible (False )#line:3214
	except :pass #line:3215
	try :#line:3216
		buildversion .setVisible (False )#line:3217
	except :pass #line:3218
	try :#line:3219
		buildtheme .setVisible (False )#line:3220
	except :pass #line:3221
	try :#line:3222
		skinname .setVisible (False )#line:3223
	except :pass #line:3224
	try :#line:3225
		errorinstall .setVisible (False )#line:3226
	except :pass #line:3227
	try :#line:3228
		lastupdatchk .setVisible (False )#line:3229
	except :pass #line:3230
def list_update ():#line:3232
	global Bname #line:3233
	global url #line:3234
	global name #line:3235
	global plugin #line:3236
	try :#line:3237
		if window .getFocus ()==buildlist :#line:3238
			O0OO00OO000O0O0OO =buildlist .getSelectedPosition ()#line:3239
			O0OO0O00O0O0O00O0 =net .http_GET (BUILDFILE ).content .replace ('\n','').replace ('\r','')#line:3240
			url =re .compile ('url="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3241
			name =re .compile ('name="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3242
			O000O00O0O0OOOOOO =re .compile ('icon="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3243
			OO00O0O00O0OOOO00 =re .compile ('version="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3244
			OO0O0O000OO0OOOOO =re .compile ('kodi="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3245
			O000000OOOOOO0000 =re .compile ('description="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3246
			buildtextbox .setLabel ('[COLOR %s] -בילד נבחר  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3247
			vertextbox .setLabel ('[COLOR %s] -גרסה [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO00O0O00O0OOOO00 ))#line:3248
			koditextbox .setLabel ('[COLOR %s] -גרסת קודי  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO0O0O000OO0OOOOO ))#line:3249
			desctextbox .setText ('[COLOR %s][COLOR hotpink][B]בחרו בהתקנה רגילה אם יש לכם בילד מותקן[/B][/COLOR][COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O000000OOOOOO0000 ))#line:3250
			buildthumb .setImage (O000O00O0O0OOOOOO )#line:3251
			O00OOO0O0O0OOOO0O =buildlist .getListItem (buildlist .getSelectedPosition ()).getLabel ()#line:3252
			Bname =wiz .stripcolortags (O00OOO0O0O0OOOO0O )#line:3253
	except :pass #line:3254
	try :#line:3255
		if window .getFocus ()==addonlist :#line:3256
			O0OO00OO000O0O0OO =addonlist .getSelectedPosition ()#line:3257
			O0OO0O00O0O0O00O0 =net .http_GET (ADDONFILE ).content .replace ('\n','').replace ('\r','')#line:3258
			O0OO00O000OO00O00 =re .compile ('icon="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3259
			url =re .compile ('url="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3260
			name =re .compile ('name="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3261
			O000000OOOOOO0000 =re .compile ('description="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3262
			plugin =re .compile ('plugin="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3263
			addtextbox .setLabel ('[COLOR %s]Addon Selected:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3264
			desctextboxA .setText ('[COLOR %s]Addon Description:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O000000OOOOOO0000 ))#line:3265
			addthumb .setImage (O0OO00O000OO00O00 )#line:3266
			O00OOO0O0O0OOOO0O =addonlist .getListItem (addonlist .getSelectedPosition ()).getLabel ()#line:3267
			name =wiz .stripcolortags (O00OOO0O0O0OOOO0O )#line:3268
	except :pass #line:3269
	try :#line:3270
		if window .getFocus ()==apklist :#line:3271
			O0OO00OO000O0O0OO =apklist .getSelectedPosition (name ,url )#line:3272
			O0OO0O00O0O0O00O0 =net .http_GET (APKFILE ).content .replace ('\n','').replace ('\r','')#line:3273
			O0O0O0OO0O00OOOOO =re .compile ('icon="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3274
			url =re .compile ('url="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3275
			name =re .compile ('name="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3276
			O000000OOOOOO0000 =re .compile ('description="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3277
			apktextbox .setLabel ('[COLOR %s]APK Selected:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3278
			desctextboxAPK .setText ('[COLOR %s]APK Description:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O000000OOOOOO0000 ))#line:3279
			apkthumb .setImage (O0O0O0OO0O00OOOOO )#line:3280
			O00OOO0O0O0OOOO0O =apklist .getListItem (apklist .getSelectedPosition ()).getLabel ()#line:3281
			name =wiz .stripcolortags (O00OOO0O0O0OOOO0O )#line:3282
	except :pass #line:3283
	try :#line:3284
		if window .getFocus ()==emulist :#line:3285
			O0OO00OO000O0O0OO =emulist .getSelectedPosition (name ,url )#line:3286
			O0OO0O00O0O0O00O0 =net .http_GET (EMUAPKS ).content .replace ('\n','').replace ('\r','')#line:3287
			OO0OO00OOOO00OOO0 =re .compile ('icon="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3288
			url =re .compile ('url="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3289
			name =re .compile ('name="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3290
			O000000OOOOOO0000 =re .compile ('description="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3291
			emutextbox .setLabel ('[COLOR %s]EMU Selected:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3292
			desctextboxEMU .setText ('[COLOR %s]EMU Description:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O000000OOOOOO0000 ))#line:3293
			emuthumb .setImage (OO0OO00OOOO00OOO0 )#line:3294
	except :pass #line:3295
	try :#line:3296
		if window .getFocus ()==romlist :#line:3297
			O0OO00OO000O0O0OO =romlist .getSelectedPosition (name ,url )#line:3298
			O0OO0O00O0O0O00O0 =net .http_GET (ROMPACK ).content .replace ('\n','').replace ('\r','')#line:3299
			OO0OO00OOOO00OOO0 =re .compile ('icon="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3300
			url =re .compile ('url="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3301
			name =re .compile ('name="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3302
			O000000OOOOOO0000 =re .compile ('description="(.+?)"').findall (O0OO0O00O0O0O00O0 )[O0OO00OO000O0O0OO ]#line:3303
			romtextbox .setLabel ('[COLOR %s]ROM PACK Selected:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,name ))#line:3304
			desctextboxROM .setText ('[COLOR %s]ROM PACK Description:[COLOR %s] %s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O000000OOOOOO0000 ))#line:3305
			romthumb .setImage (OO0OO00OOOO00OOO0 )#line:3306
	except :pass #line:3307
def BuildList ():#line:3309
	global InstallButton #line:3310
	global FreshStartButton #line:3311
	global buildlist #line:3312
	global buildthumb #line:3313
	global buildtextbox #line:3314
	global vertextbox #line:3315
	global koditextbox #line:3316
	global desctextbox #line:3317
	global no_txt #line:3318
	global buildname #line:3319
	global buildversion #line:3320
	global buildtheme #line:3321
	global skinname #line:3322
	global errorinstall #line:3323
	global lastupdatchk #line:3324
	global Bname #line:3325
	global PreviewButton #line:3326
	global ThemeButton #line:3327
	list_update ()#line:3328
	HIDEALL ()#line:3330
	if not BUILDFILE =='http://'and not BUILDFILE =='':#line:3331
		listbg .setVisible (True )#line:3333
		buildbg .setVisible (True )#line:3334
		buildinfobg .setVisible (True )#line:3335
		PreviewButton =pyxbmct .Button ('[COLOR %s][B]סרטון הדגמה[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3337
		window .placeControl (PreviewButton ,20 ,20 ,8 ,8 )#line:3338
		window .connect (PreviewButton ,lambda :buildVideo (Bname ))#line:3339
		InstallButton =pyxbmct .Button ('[COLOR %s][B]התקנה רגילה[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3341
		window .placeControl (InstallButton ,28 ,20 ,8 ,8 )#line:3342
		window .connect (InstallButton ,lambda :buildWizard (Bname ,'normal'))#line:3343
		FreshStartButton =pyxbmct .Button ('[COLOR %s][B]התקנה נקיה[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3345
		window .placeControl (FreshStartButton ,36 ,20 ,8 ,8 )#line:3346
		window .connect (FreshStartButton ,lambda :buildWizard (Bname ,'fresh'))#line:3347
		ThemeButton =pyxbmct .Button ('[COLOR %s][B]התקנת ערכות[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3349
		window .placeControl (ThemeButton ,44 ,20 ,8 ,8 )#line:3350
		window .connect (ThemeButton ,lambda :buildWizard (Bname ,'theme'))#line:3351
		buildthumb =pyxbmct .Image (ICON )#line:3356
		window .placeControl (buildthumb ,21 ,30 ,45 ,19 )#line:3357
		buildlist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:3359
		window .placeControl (buildlist ,14 ,1 ,79 ,15 )#line:3360
		buildtextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3362
		window .placeControl (buildtextbox ,13 ,20 ,10 ,25 )#line:3363
		vertextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3365
		window .placeControl (vertextbox ,60 ,20 ,10 ,15 )#line:3366
		koditextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3368
		window .placeControl (koditextbox ,65 ,20 ,10 ,15 )#line:3369
		desctextbox =pyxbmct .TextBox ()#line:3371
		window .placeControl (desctextbox ,70 ,20 ,17 ,30 )#line:3372
		desctextbox .autoScroll (1100 ,1100 ,1100 )#line:3373
		O0OO0O0OO00O00OOO =ADDON .getSetting ('buildname')#line:3375
		OOOO0OOOOOO0O00OO =ADDON .getSetting ('buildversion')#line:3376
		OOOO0OOO00OO00O0O =ADDON .getSetting ('defaultskinname')#line:3377
		OOOO00000O0OOOO0O =ADDON .getSetting ('buildtheme')#line:3378
		O00OOO0000000OO00 =ADDON .getSetting ('errors')#line:3379
		O00OOO0O0O0OO0O0O =ADDON .getSetting ('lastbuildcheck')#line:3380
		if O0OO0O0OO00O00OOO =='':buildname =None #line:3383
		else :buildname =ADDON .getSetting ('buildname')#line:3384
		if OOOO0OOOOOO0O00OO =='':buildversion =None #line:3386
		else :buildversion =ADDON .getSetting ('buildversion')#line:3387
		if OOOO0OOO00OO00O0O =='':OO00O000O000OOO0O =None #line:3389
		else :OO00O000O000OOO0O =ADDON .getSetting ('defaultskinname')#line:3390
		if OOOO00000O0OOOO0O =='':buildtheme =None #line:3392
		else :buildtheme =ADDON .getSetting ('buildtheme')#line:3393
		if O00OOO0000000OO00 =='':OOO0OOOOO0000O00O =None #line:3395
		else :OOO0OOOOO0000O00O =ADDON .getSetting ('errors')#line:3396
		if O00OOO0O0O0OO0O0O =='':OOOOO00OO0OOOO00O =None #line:3398
		else :OOOOO00OO0OOOO00O =ADDON .getSetting ('lastbuildcheck')#line:3399
		buildname =pyxbmct .Label ('[COLOR %s] בילד נוכחי מותקן [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,buildname ))#line:3403
		window .placeControl (buildname ,90 ,2 ,8 ,25 )#line:3404
		buildversion =pyxbmct .Label ('[COLOR %s] גרסת בילד [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,buildversion ))#line:3406
		window .placeControl (buildversion ,95 ,2 ,8 ,20 )#line:3407
		skinname =pyxbmct .Label ('[COLOR %s] סקין בילד מותקן [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO00O000O000OOO0O ))#line:3409
		window .placeControl (skinname ,100 ,2 ,11 ,20 )#line:3410
		buildtheme =pyxbmct .Label ('[COLOR %s] ערכת בילד מותקן  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,buildtheme ))#line:3412
		window .placeControl (buildtheme ,90 ,28 ,8 ,21 )#line:3413
		errorinstall =pyxbmct .Label ('[COLOR %s] שגיאות במהלך ההתקנה  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOO0OOOOO0000O00O ))#line:3415
		window .placeControl (errorinstall ,95 ,28 ,8 ,20 )#line:3416
		lastupdatchk =pyxbmct .Label ('[COLOR %s] בדיקת עדכון אחרון  [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOOOO00OO0OOOO00O ))#line:3418
		window .placeControl (lastupdatchk ,100 ,28 ,8 ,20 )#line:3419
		buildlist .reset ()#line:3422
		buildlist .setVisible (True )#line:3423
		buildthumb .setVisible (True )#line:3424
		InstallButton .setVisible (True )#line:3426
		FreshStartButton .setVisible (True )#line:3427
		buildtextbox .setVisible (True )#line:3428
		vertextbox .setVisible (True )#line:3429
		koditextbox .setVisible (True )#line:3430
		desctextbox .setVisible (True )#line:3431
		buildname .setVisible (True )#line:3433
		buildversion .setVisible (True )#line:3434
		buildtheme .setVisible (True )#line:3435
		skinname .setVisible (True )#line:3436
		errorinstall .setVisible (True )#line:3437
		lastupdatchk .setVisible (True )#line:3438
		buildthumb .setImage (ICON )#line:3440
		O0OOO0OO00O00000O =net .http_GET (BUILDFILE ).content .replace ('\n','').replace ('\r','')#line:3441
		OO0OOOOO0O00OOO0O =re .compile ('name="(.+?)"').findall (O0OOO0OO00O00000O )#line:3442
		for OO0O00OOO0OO0OOO0 in OO0OOOOO0O00OOO0O :#line:3443
			OO0O00OOO0OO0OOO0 ='[COLOR %s]'%LIST_TEXT +OO0O00OOO0OO0OOO0 +'[/COLOR]'#line:3444
			buildlist .addItem (OO0O00OOO0OO0OOO0 )#line:3445
		BuildsButton .controlUp (buildlist )#line:3447
		BuildsButton .controlDown (buildlist )#line:3448
		buildlist .controlRight (PreviewButton )#line:3450
		buildlist .controlUp (BuildsButton )#line:3451
		PreviewButton .controlDown (InstallButton )#line:3453
		PreviewButton .controlUp (BuildsButton )#line:3454
		PreviewButton .controlLeft (buildlist )#line:3455
		InstallButton .controlDown (FreshStartButton )#line:3457
		InstallButton .controlUp (PreviewButton )#line:3458
		InstallButton .controlLeft (buildlist )#line:3459
		FreshStartButton .controlDown (ThemeButton )#line:3461
		FreshStartButton .controlUp (InstallButton )#line:3462
		FreshStartButton .controlLeft (buildlist )#line:3463
		ThemeButton .controlUp (FreshStartButton )#line:3466
		ThemeButton .controlLeft (buildlist )#line:3467
	else :#line:3468
		no_txt .setVisible (True )#line:3469
		wiz .FTGlog ('No Build txt')#line:3470
def AddonInstall (OO0O00O0O00OO00O0 ):#line:3472
	OOOOO0O00OOOO0000 =wiz .openURL (ADDONFILE ).replace ('\n','').replace ('\r','').replace ('\t','').replace ('repository=""','repository="none"').replace ('repositoryurl=""','repositoryurl="http://"').replace ('repositoryxml=""','repositoryxml="http://"')#line:3473
	OOO0O0O00OO00OO00 =re .compile ('name="%s".+?lugin="(.+?)".+?rl="(.+?)".+?epository="(.+?)".+?epositoryxml="(.+?)".+?epositoryurl="(.+?)".+?con="(.+?)".+?anart="(.+?)".+?dult="(.+?)".+?escription="(.+?)"'%OO0O00O0O00OO00O0 ).findall (OOOOO0O00OOOO0000 )#line:3474
	if len (OOO0O0O00OO00OO00 )>0 :#line:3475
		OO0OOOOOOO0000O0O =0 #line:3476
		for O0OO0000000OOOOO0 ,OOOOO00OOO0OO000O ,O0O000OO0000O00O0 ,OO0OO00OO00O0O0O0 ,OO00OOOO0O00O000O ,O00OOO00OOO000O0O ,O0OO000000O0O0000 ,O0000O0O00O0OOOOO ,O00OO0O0OOOOO000O in OOO0O0O00OO00OO00 :#line:3477
			if O0OO0000000OOOOO0 .lower ()=='skin':#line:3478
				skinInstaller (OO0O00O0O00OO00O0 ,url )#line:3479
			elif O0OO0000000OOOOO0 .lower ()=='pack':#line:3480
				packInstaller (OO0O00O0O00OO00O0 ,url )#line:3481
			else :#line:3482
				addonInstaller (O0OO0000000OOOOO0 ,url )#line:3483
def APKinstall (OOOOO0O00O0O0O000 ):#line:3485
	O0OO0000OO0OO00O0 =OOOOO0O00O0O0O000 #line:3486
	O00OOOOOO0O0OOOO0 =checkAPK (OOOOO0O00O0O0O000 ,'url')#line:3487
	apkInstaller1 (O0OO0000OO0OO00O0 ,O00OOOOOO0O0OOOO0 )#line:3488
def AddonList ():#line:3490
	global InstallButtonA #line:3491
	global addonlist #line:3492
	global addthumb #line:3493
	global desctextboxA #line:3494
	global addtextbox #line:3495
	global no_txt #line:3496
	global url #line:3497
	global name #line:3498
	HIDEALL ()#line:3500
	if not ADDONFILE =='http://'and not ADDONFILE =='':#line:3501
		listbgA .setVisible (True )#line:3503
		buildbgA .setVisible (True )#line:3504
		InstallButtonA =pyxbmct .Button ('[COLOR %s][B]Install[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3507
		window .placeControl (InstallButtonA ,30 ,20 ,9 ,8 )#line:3508
		window .connect (InstallButtonA ,lambda :AddonInstall (name ))#line:3510
		addthumb =pyxbmct .Image (ICON )#line:3512
		window .placeControl (addthumb ,31 ,30 ,45 ,19 )#line:3513
		addonlist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:3515
		window .placeControl (addonlist ,24 ,1 ,79 ,15 )#line:3516
		addtextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3518
		window .placeControl (addtextbox ,24 ,20 ,10 ,25 )#line:3519
		desctextboxA =pyxbmct .TextBox ()#line:3521
		window .placeControl (desctextboxA ,80 ,20 ,17 ,30 )#line:3522
		desctextboxA .autoScroll (1100 ,1100 ,1100 )#line:3523
		addonlist .reset ()#line:3525
		addonlist .setVisible (True )#line:3526
		addthumb .setVisible (True )#line:3527
		AddonButton .setVisible (True )#line:3529
		APKButton .setVisible (True )#line:3530
		ROMButton .setVisible (True )#line:3531
		EmuButton .setVisible (True )#line:3532
		InstallButtonA .setVisible (True )#line:3534
		addtextbox .setVisible (True )#line:3535
		desctextboxA .setVisible (True )#line:3536
		addthumb .setImage (ICON )#line:3538
		OO00O00OO0OOOOO0O =net .http_GET (ADDONFILE ).content .replace ('\n','').replace ('\r','')#line:3539
		O000O0OO0O000O00O =re .compile ('name="(.+?)"').findall (OO00O00OO0OOOOO0O )#line:3540
		for name in O000O0OO0O000O00O :#line:3541
			name ='[COLOR %s]'%LIST_TEXT +name +'[/COLOR]'#line:3542
			addonlist .addItem (name )#line:3543
		AddonButton .controlDown (addonlist )#line:3545
		addonlist .controlRight (InstallButtonA )#line:3547
		addonlist .controlUp (AddonButton )#line:3548
		InstallButtonA .controlLeft (addonlist )#line:3550
		InstallButtonA .controlUp (AddonButton )#line:3551
	else :#line:3555
		no_txt .setVisible (True )#line:3556
		AddonButton .setVisible (True )#line:3557
		APKButton .setVisible (True )#line:3558
		ROMButton .setVisible (True )#line:3559
		EmuButton .setVisible (True )#line:3560
		wiz .FTGlog ('No Addon txt')#line:3561
def APKList ():#line:3563
	global InstallButtonAPK #line:3564
	global apklist #line:3565
	global apkthumb #line:3566
	global desctextboxAPK #line:3567
	global apktextbox #line:3568
	global no_txt #line:3569
	HIDEALL ()#line:3571
	if not APKFILE =='http://'and not APKFILE =='':#line:3572
		listbgA .setVisible (True )#line:3574
		buildbgA .setVisible (True )#line:3575
		InstallButtonAPK =pyxbmct .Button ('[COLOR %s][B]Install[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3577
		window .placeControl (InstallButtonAPK ,30 ,20 ,9 ,8 )#line:3578
		window .connect (InstallButtonAPK ,lambda :apkInstaller1 (OOO0OOOO0OOOO0OOO ,url ))#line:3579
		apkthumb =pyxbmct .Image (ICON )#line:3581
		window .placeControl (apkthumb ,31 ,30 ,45 ,19 )#line:3582
		apklist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:3584
		window .placeControl (apklist ,24 ,1 ,79 ,15 )#line:3585
		apktextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3587
		window .placeControl (apktextbox ,24 ,20 ,10 ,25 )#line:3588
		desctextboxAPK =pyxbmct .TextBox ()#line:3590
		window .placeControl (desctextboxAPK ,80 ,20 ,17 ,30 )#line:3591
		desctextboxAPK .autoScroll (1100 ,1100 ,1100 )#line:3592
		AddonButton .setVisible (True )#line:3594
		APKButton .setVisible (True )#line:3595
		ROMButton .setVisible (True )#line:3596
		EmuButton .setVisible (True )#line:3597
		apklist .reset ()#line:3599
		apklist .setVisible (True )#line:3600
		apkthumb .setVisible (True )#line:3601
		InstallButtonAPK .setVisible (True )#line:3602
		apktextbox .setVisible (True )#line:3603
		desctextboxAPK .setVisible (True )#line:3604
		apkthumb .setImage (ICON )#line:3606
		OO0O000O000O0OOOO =net .http_GET (APKFILE ).content .replace ('\n','').replace ('\r','')#line:3607
		O0OO0O0OOOOOO00O0 =re .compile ('name="(.+?)"').findall (OO0O000O000O0OOOO )#line:3608
		for OOO0OOOO0OOOO0OOO in O0OO0O0OOOOOO00O0 :#line:3609
			OOO0OOOO0OOOO0OOO ='[COLOR %s]'%LIST_TEXT +OOO0OOOO0OOOO0OOO +'[/COLOR]'#line:3610
			apklist .addItem (OOO0OOOO0OOOO0OOO )#line:3611
		APKButton .controlDown (apklist )#line:3613
		apklist .controlRight (InstallButtonAPK )#line:3615
		apklist .controlUp (APKButton )#line:3616
		InstallButtonAPK .controlLeft (apklist )#line:3618
		InstallButtonAPK .controlUp (APKButton )#line:3619
	else :#line:3620
		no_txt .setVisible (True )#line:3621
		AddonButton .setVisible (True )#line:3622
		APKButton .setVisible (True )#line:3623
		ROMButton .setVisible (True )#line:3624
		EmuButton .setVisible (True )#line:3625
		wiz .FTGlog ('No APK txt')#line:3626
def EmuList ():#line:3628
	global emulist #line:3629
	global emuthumb #line:3630
	global desctextboxEMU #line:3631
	global emutextbox #line:3632
	global InstallButtonEMU #line:3633
	global no_txt #line:3634
	HIDEALL ()#line:3636
	if not EMUAPKS =='http://'and not EMUAPKS =='':#line:3637
		listbgA .setVisible (True )#line:3639
		buildbgA .setVisible (True )#line:3640
		InstallButtonEMU =pyxbmct .Button ('[COLOR %s][B]Install[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3642
		window .placeControl (InstallButtonEMU ,30 ,20 ,9 ,8 )#line:3643
		window .connect (InstallButtonEMU ,lambda :apkInstaller1 (O0OO00O0O0000OO0O ,url ))#line:3644
		emulist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:3646
		window .placeControl (emulist ,24 ,1 ,79 ,15 )#line:3647
		emuthumb =pyxbmct .Image (ICON )#line:3649
		window .placeControl (emuthumb ,31 ,30 ,45 ,19 )#line:3650
		emutextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3652
		window .placeControl (emutextbox ,24 ,20 ,10 ,25 )#line:3653
		desctextboxEMU =pyxbmct .TextBox ()#line:3655
		window .placeControl (desctextboxEMU ,80 ,20 ,17 ,30 )#line:3656
		desctextboxEMU .autoScroll (1100 ,1100 ,1100 )#line:3657
		AddonButton .setVisible (True )#line:3659
		APKButton .setVisible (True )#line:3660
		ROMButton .setVisible (True )#line:3661
		EmuButton .setVisible (True )#line:3662
		emulist .setVisible (True )#line:3667
		desctextboxEMU .setVisible (True )#line:3668
		emutextbox .setVisible (True )#line:3669
		InstallButtonEMU .setVisible (True )#line:3670
		emulist .reset ()#line:3672
		emulist .setVisible (True )#line:3673
		emuthumb .setVisible (True )#line:3674
		OO0O0OO0000000OOO =net .http_GET (EMUAPKS ).content .replace ('\n','').replace ('\r','')#line:3675
		OO0OO000000OOO0O0 =re .compile ('name="(.+?)"').findall (OO0O0OO0000000OOO )#line:3676
		for O0OO00O0O0000OO0O in OO0OO000000OOO0O0 :#line:3677
			O0OO00O0O0000OO0O ='[COLOR %s]'%LIST_TEXT +O0OO00O0O0000OO0O +'[/COLOR]'#line:3678
			emulist .addItem (O0OO00O0O0000OO0O )#line:3679
		EmuButton .controlDown (emulist )#line:3681
		emulist .controlRight (InstallButtonEMU )#line:3683
		emulist .controlUp (EmuButton )#line:3684
		InstallButtonEMU .controlLeft (emulist )#line:3686
		InstallButtonEMU .controlUp (EmuButton )#line:3687
	else :#line:3688
		no_txt .setVisible (True )#line:3689
		AddonButton .setVisible (True )#line:3690
		APKButton .setVisible (True )#line:3691
		ROMButton .setVisible (True )#line:3692
		EmuButton .setVisible (True )#line:3693
		wiz .FTGlog ('No EMU txt')#line:3694
def RomList ():#line:3696
	global romlist #line:3697
	global romthumb #line:3698
	global desctextboxROM #line:3699
	global romtextbox #line:3700
	global InstallButtonROM #line:3701
	global no_txt #line:3702
	HIDEALL ()#line:3704
	if not ROMPACK =='http://'and not ROMPACK =='':#line:3705
		listbgA .setVisible (True )#line:3707
		buildbgA .setVisible (True )#line:3708
		InstallButtonROM =pyxbmct .Button ('[COLOR %s][B]Install[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3710
		window .placeControl (InstallButtonROM ,30 ,20 ,9 ,8 )#line:3711
		window .connect (InstallButtonROM ,lambda :UNZIPROM ())#line:3712
		romlist =pyxbmct .List (buttonFocusTexture =LBUTTON )#line:3714
		window .placeControl (romlist ,24 ,1 ,79 ,15 )#line:3715
		romthumb =pyxbmct .Image (ICON )#line:3717
		window .placeControl (romthumb ,31 ,30 ,45 ,19 )#line:3718
		romtextbox =pyxbmct .Label ('',textColor ='0xFFFFFFFF')#line:3720
		window .placeControl (romtextbox ,24 ,20 ,10 ,25 )#line:3721
		desctextboxROM =pyxbmct .TextBox ()#line:3724
		window .placeControl (desctextboxROM ,80 ,20 ,17 ,30 )#line:3725
		desctextboxROM .autoScroll (1100 ,1100 ,1100 )#line:3726
		AddonButton .setVisible (True )#line:3728
		APKButton .setVisible (True )#line:3729
		ROMButton .setVisible (True )#line:3730
		EmuButton .setVisible (True )#line:3731
		romlist .setVisible (True )#line:3733
		romthumb .setVisible (True )#line:3734
		desctextboxROM .setVisible (True )#line:3735
		romtextbox .setVisible (True )#line:3736
		InstallButtonROM .setVisible (True )#line:3737
		romlist .reset ()#line:3739
		romlist .setVisible (True )#line:3740
		O00O0000OO0OOO0OO =net .http_GET (ROMPACK ).content .replace ('\n','').replace ('\r','')#line:3742
		O0O00OOOOO00000OO =re .compile ('name="(.+?)"').findall (O00O0000OO0OOO0OO )#line:3743
		for O0OO00O000O0OOOOO in O0O00OOOOO00000OO :#line:3744
			O0OO00O000O0OOOOO ='[COLOR %s]'%LIST_TEXT +O0OO00O000O0OOOOO +'[/COLOR]'#line:3745
			romlist .addItem (O0OO00O000O0OOOOO )#line:3746
		ROMButton .controlDown (romlist )#line:3748
		romlist .controlRight (InstallButtonROM )#line:3750
		romlist .controlUp (ROMButton )#line:3751
		InstallButtonROM .controlLeft (romlist )#line:3753
		InstallButtonROM .controlUp (ROMButton )#line:3754
	else :#line:3755
		no_txt .setVisible (True )#line:3756
		AddonButton .setVisible (True )#line:3757
		APKButton .setVisible (True )#line:3758
		ROMButton .setVisible (True )#line:3759
		EmuButton .setVisible (True )#line:3760
		wiz .FTGlog ('No ROM txt')#line:3761
def Un_Hide_Net ():#line:3763
	OOO0000000O0O00OO ,OOOO0000OO00OOO0O ,OO0OO0OO000O0OOO0 ,O0OOOO0OOOOO00OO0 ,O0O0O0O000000OOOO ,OOOOO00OO0O0OOOO0 ,OOOO000000OOO0OO0 =wiz .net_info ()#line:3764
	MAC .setLabel ('[COLOR %s]Mac:[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOO0000000O0O00OO ))#line:3765
	INTER_IP .setLabel ('[COLOR %s]-אייפי פנימי [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOOO0000OO00OOO0O ))#line:3766
	IP .setLabel ('[COLOR %s]-אייפי חיצוני [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO0OO0OO000O0OOO0 ))#line:3767
	CITY .setLabel ('[COLOR %s]-עיר [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O0OOOO0OOOOO00OO0 ))#line:3768
	STATE .setLabel ('[COLOR %s]-ארץ [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O0O0O0O000000OOOO ))#line:3769
	COUNTRY .setLabel ('[COLOR %s]-מדינה [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOOOO00OO0O0OOOO0 ))#line:3770
	ISP .setLabel ('[COLOR %s]-ספק [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOOO000000OOO0OO0 ))#line:3771
def Maint ():#line:3773
	HIDEALL ()#line:3774
	global total_clean_button #line:3775
	global total_cache_button #line:3776
	global total_packages_button #line:3777
	global total_thumbnails_button #line:3778
	global TC #line:3779
	global DC #line:3780
	global DPK #line:3781
	global DTH #line:3782
	global TPK #line:3783
	global TTH #line:3784
	global speedtest_button #line:3785
	global sysinfo_title #line:3786
	global version1 #line:3787
	global store #line:3788
	global rom_used #line:3789
	global rom_free #line:3790
	global rom_total #line:3791
	global mem #line:3792
	global ram_used #line:3793
	global ram_free #line:3794
	global ram_total #line:3795
	global kodi #line:3796
	global total #line:3797
	global video #line:3798
	global program #line:3799
	global music #line:3800
	global picture #line:3801
	global repos #line:3802
	global skins #line:3803
	global scripts #line:3804
	sysinfobg .setVisible (True )#line:3806
	maintbg .setVisible (True )#line:3807
	speedthumb .setVisible (True )#line:3808
	netinfobg .setVisible (True )#line:3809
	O0O00O0O0OO000OO0 =wiz .getSize (PACKAGES )#line:3811
	OO0O00O00OO0OOOOO =wiz .getTotal (PACKAGES )#line:3812
	OO0OOOO0O000O0OO0 =wiz .getSize (THUMBS )#line:3813
	OOO000O0OO00OOO00 =wiz .getTotal (THUMBS )#line:3814
	OOOOOOO00OO0000OO =wiz .getCacheSize ()#line:3815
	OO0OOO0O0O00OOOOO =O0O00O0O0OO000OO0 +OO0OOOO0O000O0OO0 +OOOOOOO00OO0000OO #line:3816
	picture ,music ,video ,O0O00O0OO0O0O0000 ,repos ,scripts ,skins ,OOOO0OO000O00O0OO ,OOO000OOO00OO0OOO ,O000O00OO0000O0OO ,OOOO0OO0OOOOO0O0O ,OOO0O0OO0O0OO0O0O ,O00000OO0OO000OO0 ,ram_free ,ram_used ,ram_total =wiz .SYSINFO ()#line:3817
	sysinfo_title =pyxbmct .Label ('[COLOR %s][B]נתוני מערכת[/B][/COLOR]'%DES_T_COLOR )#line:3821
	window .placeControl (sysinfo_title ,12 ,31 ,10 ,15 )#line:3822
	version1 =pyxbmct .Label ('[COLOR %s]-גרסה [/COLOR] [COLOR %s]%s[/COLOR] - [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOOO0OO000O00O0OO ,DESCOLOR ,OOO000OOO00OO0OOO ))#line:3823
	window .placeControl (version1 ,18 ,37 ,10 ,15 )#line:3824
	store =pyxbmct .Label ('[B][COLOR %s] אחסון [/COLOR][/B]'%DESCOLOR )#line:3825
	window .placeControl (store ,23 ,39 ,10 ,10 )#line:3826
	rom_used =pyxbmct .Label ('[COLOR %s]-בשימוש [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOO0O0OO0O0OO0O0O ))#line:3827
	window .placeControl (rom_used ,28 ,39 ,10 ,10 )#line:3828
	rom_free =pyxbmct .Label ('[COLOR %s]-פנוי [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOOO0OO0OOOOO0O0O ))#line:3829
	window .placeControl (rom_free ,32 ,39 ,10 ,10 )#line:3830
	rom_total =pyxbmct .Label ('[COLOR %s]-כללי [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O00000OO0OO000OO0 ))#line:3831
	window .placeControl (rom_total ,37 ,39 ,10 ,10 )#line:3832
	mem =pyxbmct .Label ('[B][COLOR %s] זכרון [/COLOR][/B]'%DESCOLOR )#line:3833
	window .placeControl (mem ,43 ,39 ,10 ,10 )#line:3834
	ram_used =pyxbmct .Label ('[COLOR %s]-בשימוש [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,ram_used ))#line:3836
	window .placeControl (ram_used ,48 ,39 ,10 ,10 )#line:3837
	ram_free =pyxbmct .Label ('[COLOR %s]-פנוי [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,ram_free ))#line:3838
	window .placeControl (ram_free ,53 ,39 ,10 ,10 )#line:3839
	ram_total =pyxbmct .Label ('[COLOR %s]-כללי [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,ram_total ))#line:3840
	window .placeControl (ram_total ,58 ,39 ,10 ,10 )#line:3841
	kodi =pyxbmct .Label ('[COLOR %s]-שם [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O000O00OO0000O0OO ))#line:3845
	window .placeControl (kodi ,17 ,22 ,10 ,15 )#line:3846
	O00OO0OO00O0O0000 =len (picture )+len (music )+len (video )+len (O0O00O0OO0O0O0000 )+len (scripts )+len (skins )+len (repos )#line:3847
	total =pyxbmct .Label ('[COLOR %s]-סך הרחבות [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,O00OO0OO00O0O0000 ))#line:3848
	window .placeControl (total ,22 ,22 ,10 ,10 )#line:3849
	video =pyxbmct .Label ('[COLOR %s]-הרחבות וידאו [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (video ))))#line:3850
	window .placeControl (video ,27 ,22 ,10 ,10 )#line:3851
	program =pyxbmct .Label ('[COLOR %s]-הרחבות תוכנה [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (O0O00O0OO0O0O0000 ))))#line:3852
	window .placeControl (program ,33 ,22 ,10 ,10 )#line:3853
	music =pyxbmct .Label ('[COLOR %s]-הרחבות מוזיקה [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (music ))))#line:3854
	window .placeControl (music ,37 ,22 ,10 ,10 )#line:3855
	picture =pyxbmct .Label ('[COLOR %s]-הרחבות תמונה [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (picture ))))#line:3856
	window .placeControl (picture ,42 ,22 ,10 ,10 )#line:3857
	repos =pyxbmct .Label ('[COLOR %s]- מספר ריפויים [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (repos ))))#line:3858
	window .placeControl (repos ,47 ,22 ,10 ,10 )#line:3859
	skins =pyxbmct .Label ('[COLOR %s]-מעטפת [/COLOR][COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (skins ))))#line:3860
	window .placeControl (skins ,52 ,22 ,10 ,10 )#line:3861
	scripts =pyxbmct .Label ('[COLOR %s]-מודול/סקריפט[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,str (len (scripts ))))#line:3862
	window .placeControl (scripts ,57 ,22 ,10 ,10 )#line:3863
	global MAC #line:3865
	global INTER_IP #line:3866
	global IP #line:3867
	global CITY #line:3868
	global STATE #line:3869
	global COUNTRY #line:3870
	global ISP #line:3871
	global netinfo_title #line:3872
	global un_hide_net #line:3873
	global settings_button1 #line:3874
	global trigger_title #line:3875
	netinfo_title =pyxbmct .Label ('[COLOR %s][B]מאפייני רשת[/B][/COLOR]'%DES_T_COLOR )#line:3880
	window .placeControl (netinfo_title ,12 ,7 ,10 ,20 )#line:3881
	MAC =pyxbmct .Label ('[COLOR %s]Mac: [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:3882
	window .placeControl (MAC ,18 ,1 ,10 ,18 )#line:3883
	INTER_IP =pyxbmct .Label ('[COLOR %s]-אייפי פנימי [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:3884
	window .placeControl (INTER_IP ,23 ,1 ,10 ,18 )#line:3885
	IP =pyxbmct .Label ('[COLOR %s]-אייפי חיצוני [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:3886
	window .placeControl (IP ,28 ,1 ,10 ,18 )#line:3887
	CITY =pyxbmct .Label ('[COLOR %s]-עיר [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:3888
	window .placeControl (CITY ,33 ,1 ,10 ,18 )#line:3889
	STATE =pyxbmct .Label ('[COLOR %s]-ארץ [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:3890
	window .placeControl (STATE ,38 ,1 ,10 ,18 )#line:3891
	COUNTRY =pyxbmct .Label ('[COLOR %s]-מדינה [/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:3892
	window .placeControl (COUNTRY ,43 ,1 ,10 ,18 )#line:3893
	ISP =pyxbmct .Label ('[COLOR %s]-ספק[/COLOR] [COLOR %s]מוסתר[/COLOR]'%(DES_T_COLOR ,DESCOLOR ))#line:3894
	window .placeControl (ISP ,48 ,1 ,10 ,18 )#line:3895
	TC =pyxbmct .Label ('[COLOR %s]-גודל[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,wiz .convertSize (OO0OOO0O0O00OOOOO )))#line:3898
	window .placeControl (TC ,80 ,21 ,10 ,9 )#line:3899
	DC =pyxbmct .Label ('[COLOR %s]-גודל[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,wiz .convertSize (OOOOOOO00OO0000OO )))#line:3900
	window .placeControl (DC ,96 ,21 ,10 ,9 )#line:3901
	DPK =pyxbmct .Label ('[COLOR %s]-גודל[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,wiz .convertSize (O0O00O0O0OO000OO0 )))#line:3902
	window .placeControl (DPK ,96 ,31 ,10 ,9 )#line:3903
	TPK =pyxbmct .Label ('[COLOR %s]-קבצים [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OO0O00O00OO0OOOOO ))#line:3904
	window .placeControl (TPK ,101 ,31 ,10 ,9 )#line:3905
	DTH =pyxbmct .Label ('[COLOR %s]-גודל[/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,wiz .convertSize (OO0OOOO0O000O0OO0 )))#line:3906
	window .placeControl (DTH ,96 ,41 ,10 ,9 )#line:3907
	TTH =pyxbmct .Label ('[COLOR %s]-קבצים [/COLOR] [COLOR %s]%s[/COLOR]'%(DES_T_COLOR ,DESCOLOR ,OOO000O0OO00OOO00 ))#line:3908
	window .placeControl (TTH ,101 ,41 ,10 ,9 )#line:3909
	total_clean_button =pyxbmct .Button ('[COLOR %s]ניקוי כללי[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3912
	window .placeControl (total_clean_button ,72 ,21 ,9 ,8 )#line:3913
	window .connect (total_clean_button ,lambda :totalClean ())#line:3914
	total_cache_button =pyxbmct .Button ('[COLOR %s]מחק מטמון[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3916
	window .placeControl (total_cache_button ,87 ,21 ,9 ,9 )#line:3917
	window .connect (total_cache_button ,lambda :clearCache ())#line:3918
	total_packages_button =pyxbmct .Button ('[COLOR %s]מחק חבילות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3920
	window .placeControl (total_packages_button ,87 ,31 ,9 ,9 )#line:3921
	window .connect (total_packages_button ,lambda :clearPackages ())#line:3922
	total_thumbnails_button =pyxbmct .Button ('[COLOR %s]מחק תמונות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3924
	window .placeControl (total_thumbnails_button ,87 ,41 ,9 ,9 )#line:3925
	window .connect (total_thumbnails_button ,lambda :clearThumb (type =None ))#line:3926
	speedtest_button =pyxbmct .Button ('[COLOR %s]בדיקת מהירות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3928
	window .placeControl (speedtest_button ,58 ,1 ,9 ,8 )#line:3929
	window .connect (speedtest_button ,lambda :runspeedtest ())#line:3930
	un_hide_net =pyxbmct .Button ('[COLOR %s]הראה מאפייני רשת[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3932
	window .placeControl (un_hide_net ,58 ,10 ,9 ,8 )#line:3933
	window .connect (un_hide_net ,lambda :Un_Hide_Net ())#line:3934
	trigger_title =pyxbmct .Label ('[COLOR lime][B]כלים נוספים[/B][/COLOR]')#line:3936
	window .placeControl (trigger_title ,72 ,33 ,1 ,11 )#line:3937
	settings_button1 =pyxbmct .Button ('[COLOR %s]הגדרות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:3939
	window .placeControl (settings_button1 ,72 ,41 ,9 ,8 )#line:3940
	window .connect (settings_button1 ,lambda :wiz .openS ('בדיקת מהירות'))#line:3941
	splash .setVisible (False )#line:3945
	total_clean_button .setVisible (True )#line:3946
	total_cache_button .setVisible (True )#line:3947
	total_packages_button .setVisible (True )#line:3948
	total_thumbnails_button .setVisible (True )#line:3949
	TC .setVisible (True )#line:3950
	DC .setVisible (True )#line:3951
	DPK .setVisible (True )#line:3952
	DTH .setVisible (True )#line:3953
	TPK .setVisible (True )#line:3954
	TTH .setVisible (True )#line:3955
	speedtest_button .setVisible (True )#line:3957
	sysinfo_title .setVisible (True )#line:3959
	version1 .setVisible (True )#line:3960
	store .setVisible (True )#line:3961
	rom_used .setVisible (True )#line:3962
	rom_free .setVisible (True )#line:3963
	rom_total .setVisible (True )#line:3964
	mem .setVisible (True )#line:3965
	ram_used .setVisible (True )#line:3966
	ram_free .setVisible (True )#line:3967
	ram_total .setVisible (True )#line:3968
	kodi .setVisible (True )#line:3969
	total .setVisible (True )#line:3970
	video .setVisible (True )#line:3971
	program .setVisible (True )#line:3972
	music .setVisible (True )#line:3973
	picture .setVisible (True )#line:3974
	repos .setVisible (True )#line:3975
	skins .setVisible (True )#line:3976
	scripts .setVisible (True )#line:3977
	netinfo_title .setVisible (True )#line:3979
	MAC .setVisible (True )#line:3980
	un_hide_net .setVisible (True )#line:3981
	INTER_IP .setVisible (True )#line:3982
	IP .setVisible (True )#line:3983
	ISP .setVisible (True )#line:3984
	CITY .setVisible (True )#line:3985
	STATE .setVisible (True )#line:3986
	COUNTRY .setVisible (True )#line:3987
	settings_button1 .setVisible (True )#line:3988
	trigger_title .setVisible (True )#line:3989
	MaintButton .controlDown (speedtest_button )#line:3991
	speedtest_button .controlUp (MaintButton )#line:3993
	speedtest_button .controlDown (total_clean_button )#line:3994
	speedtest_button .controlRight (un_hide_net )#line:3995
	un_hide_net .controlUp (MaintButton )#line:3997
	un_hide_net .controlDown (total_clean_button )#line:3998
	un_hide_net .controlRight (total_clean_button )#line:3999
	un_hide_net .controlLeft (speedtest_button )#line:4000
	total_clean_button .controlUp (MaintButton )#line:4002
	total_clean_button .controlDown (total_cache_button )#line:4003
	total_clean_button .controlRight (settings_button1 )#line:4004
	total_clean_button .controlLeft (un_hide_net )#line:4005
	total_cache_button .controlUp (total_clean_button )#line:4007
	total_cache_button .controlRight (total_packages_button )#line:4008
	total_cache_button .controlLeft (un_hide_net )#line:4009
	total_packages_button .controlUp (settings_button1 )#line:4011
	total_packages_button .controlRight (total_thumbnails_button )#line:4012
	total_packages_button .controlLeft (total_cache_button )#line:4013
	total_thumbnails_button .controlUp (settings_button1 )#line:4015
	total_thumbnails_button .controlLeft (total_packages_button )#line:4016
	settings_button1 .controlUp (MaintButton )#line:4018
	settings_button1 .controlDown (total_thumbnails_button )#line:4019
	settings_button1 .controlLeft (total_clean_button )#line:4020
def BackRes ():#line:4022
	HIDEALL ()#line:4023
	global favs #line:4024
	global backuploc #line:4025
	global Backup #line:4026
	global backup_build_button #line:4027
	global backup_gui_button #line:4028
	global backup_addondata_button #line:4029
	global restore_build_button #line:4030
	global restore_gui_button #line:4031
	global restore_addondata_button #line:4032
	global clear_backup_button #line:4033
	global savefav_button #line:4034
	global restorefav_button #line:4035
	global clearfav_button #line:4036
	global backupaddonpack_button #line:4037
	global restore_title #line:4038
	global delete_title #line:4039
	global set_title #line:4040
	global settings_button #line:4041
	bakresbg .setVisible (True )#line:4043
	O0OOOOO000OOO000O =str (FAVSsave )if not FAVSsave ==''else 'כרגע אין מועדפים שנשמרו'#line:4045
	favs =pyxbmct .Label ('[B][COLOR %s]-שמירה אחרונה בתאריך-[/COLOR] [COLOR %s]%s[/COLOR][/B]'%(DES_T_COLOR ,DESCOLOR ,str (O0OOOOO000OOO000O )))#line:4048
	window .placeControl (favs ,14 ,3 ,10 ,30 )#line:4049
	backuploc =pyxbmct .Label ('[B][COLOR %s] נתיב שמירת גיבוי [COLOR %s]%s[/COLOR][/B]'%(DES_T_COLOR ,DESCOLOR ,MYBUILDS ))#line:4051
	window .placeControl (backuploc ,22 ,3 ,10 ,30 )#line:4052
	Backup =pyxbmct .Label ('[B][COLOR %s] כלי גיבוי[/COLOR][/B]'%DES_T_COLOR )#line:4055
	window .placeControl (Backup ,32 ,6 ,10 ,10 )#line:4056
	backup_build_button =pyxbmct .Button ('[COLOR %s] בילד [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4058
	window .placeControl (backup_build_button ,42 ,3 ,10 ,10 )#line:4059
	window .connect (backup_build_button ,lambda :wiz .backUpOptions ('build'))#line:4060
	backup_gui_button =pyxbmct .Button ('[COLOR %s] מימשק [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4062
	window .placeControl (backup_gui_button ,52 ,3 ,10 ,10 )#line:4063
	window .connect (backup_gui_button ,lambda :wiz .backUpOptions ('guifix'))#line:4064
	backupaddonpack_button =pyxbmct .Button ('[COLOR %s] חבילת הרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4066
	window .placeControl (backupaddonpack_button ,62 ,3 ,10 ,10 )#line:4067
	window .connect (backupaddonpack_button ,lambda :wiz .backUpOptions ('addon pack'))#line:4068
	backup_addondata_button =pyxbmct .Button ('[COLOR %s] נתוני הרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4070
	window .placeControl (backup_addondata_button ,72 ,3 ,10 ,10 )#line:4071
	window .connect (backup_addondata_button ,lambda :wiz .backUpOptions ('addondata'))#line:4072
	savefav_button =pyxbmct .Button ('[COLOR %s] מועדפים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4074
	window .placeControl (savefav_button ,82 ,3 ,10 ,10 )#line:4075
	window .connect (savefav_button ,lambda :wiz .BACKUPFAV ())#line:4076
	restore_title =pyxbmct .Label ('[B][COLOR lime]כלי שחזור-לחיצה תאפס את הבילד! [/COLOR][/B]')#line:4079
	window .placeControl (restore_title ,32 ,20 ,6 ,16 )#line:4080
	restore_build_button =pyxbmct .Button ('[COLOR %s] בילד/חבילה [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4082
	window .placeControl (restore_build_button ,42 ,20 ,10 ,10 )#line:4083
	window .connect (restore_build_button ,lambda :restoreit ('build'))#line:4084
	restore_gui_button =pyxbmct .Button ('[COLOR %s] ממשק [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4086
	window .placeControl (restore_gui_button ,52 ,20 ,10 ,10 )#line:4087
	window .connect (restore_gui_button ,lambda :restoreit ('gui'))#line:4088
	restore_addondata_button =pyxbmct .Button ('[COLOR %s] נתוני הרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4090
	window .placeControl (restore_addondata_button ,62 ,20 ,10 ,10 )#line:4091
	window .connect (restore_addondata_button ,lambda :restoreit ('addondata'))#line:4092
	restorefav_button =pyxbmct .Button ('[COLOR %s] מועדפים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4094
	window .placeControl (restorefav_button ,72 ,20 ,10 ,10 )#line:4095
	window .connect (restorefav_button ,lambda :wiz .RESTOREFAV ())#line:4096
	delete_title =pyxbmct .Label ('[B][COLOR red] כלי מחיקה [/COLOR][/B]')#line:4099
	window .placeControl (delete_title ,56 ,40 ,10 ,10 )#line:4100
	clearfav_button =pyxbmct .Button ('[COLOR %s] ניקוי מועדפים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4102
	window .placeControl (clearfav_button ,64 ,37 ,10 ,10 )#line:4103
	window .connect (clearfav_button ,lambda :wiz .DELFAV ())#line:4104
	clear_backup_button =pyxbmct .Button ('[COLOR %s] ניקוי גיבויים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4106
	window .placeControl (clear_backup_button ,74 ,37 ,10 ,10 )#line:4107
	window .connect (clear_backup_button ,lambda :wiz .cleanupBackup ())#line:4108
	set_title =pyxbmct .Label ('[B][COLOR %s] הגדרות               [/COLOR][/B]'%DES_T_COLOR )#line:4111
	window .placeControl (set_title ,32 ,37 ,10 ,10 )#line:4112
	settings_button =pyxbmct .Button ('[COLOR %s] הגדרות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4114
	window .placeControl (settings_button ,42 ,37 ,10 ,10 )#line:4115
	window .connect (settings_button ,lambda :wiz .openS ('Maintenance'))#line:4116
	favs .setVisible (True )#line:4119
	backuploc .setVisible (True )#line:4120
	Backup .setVisible (True )#line:4121
	backup_build_button .setVisible (True )#line:4122
	backup_gui_button .setVisible (True )#line:4123
	backup_addondata_button .setVisible (True )#line:4124
	restore_build_button .setVisible (True )#line:4125
	restore_gui_button .setVisible (True )#line:4126
	restore_addondata_button .setVisible (True )#line:4127
	clear_backup_button .setVisible (True )#line:4128
	savefav_button .setVisible (True )#line:4129
	restorefav_button .setVisible (True )#line:4130
	clearfav_button .setVisible (True )#line:4131
	backupaddonpack_button .setVisible (True )#line:4132
	restore_title .setVisible (True )#line:4133
	delete_title .setVisible (True )#line:4134
	set_title .setVisible (True )#line:4135
	settings_button .setVisible (True )#line:4136
	BackResButton .controlDown (backup_build_button )#line:4138
	backup_build_button .controlUp (BackResButton )#line:4140
	backup_build_button .controlDown (backup_gui_button )#line:4141
	backup_build_button .controlRight (restore_build_button )#line:4142
	backup_gui_button .controlUp (backup_build_button )#line:4144
	backup_gui_button .controlDown (backupaddonpack_button )#line:4145
	backup_gui_button .controlRight (restore_gui_button )#line:4146
	backupaddonpack_button .controlUp (backup_gui_button )#line:4148
	backupaddonpack_button .controlDown (backup_addondata_button )#line:4149
	backupaddonpack_button .controlRight (restore_addondata_button )#line:4150
	backup_addondata_button .controlUp (backupaddonpack_button )#line:4152
	backup_addondata_button .controlDown (savefav_button )#line:4153
	backup_addondata_button .controlRight (restorefav_button )#line:4154
	savefav_button .controlUp (backup_addondata_button )#line:4156
	savefav_button .controlRight (restorefav_button )#line:4157
	restore_build_button .controlUp (BackResButton )#line:4159
	restore_build_button .controlDown (restore_gui_button )#line:4160
	restore_build_button .controlRight (settings_button )#line:4161
	restore_build_button .controlLeft (backup_build_button )#line:4162
	restore_gui_button .controlUp (restore_build_button )#line:4164
	restore_gui_button .controlDown (restore_addondata_button )#line:4165
	restore_gui_button .controlRight (settings_button )#line:4166
	restore_gui_button .controlLeft (backup_gui_button )#line:4167
	restore_addondata_button .controlUp (restore_gui_button )#line:4169
	restore_addondata_button .controlDown (restorefav_button )#line:4170
	restore_addondata_button .controlRight (clearfav_button )#line:4171
	restore_addondata_button .controlLeft (backupaddonpack_button )#line:4172
	restorefav_button .controlUp (restore_addondata_button )#line:4174
	restorefav_button .controlRight (clear_backup_button )#line:4175
	restorefav_button .controlLeft (backup_addondata_button )#line:4176
	settings_button .controlUp (BackResButton )#line:4178
	settings_button .controlDown (clearfav_button )#line:4179
	settings_button .controlLeft (restore_build_button )#line:4180
	clearfav_button .controlUp (settings_button )#line:4182
	clearfav_button .controlDown (clear_backup_button )#line:4183
	clearfav_button .controlLeft (restore_addondata_button )#line:4184
	clear_backup_button .controlUp (clearfav_button )#line:4186
	clear_backup_button .controlLeft (restorefav_button )#line:4187
def Tools ():#line:4189
	HIDEALL ()#line:4190
	global view_error_button #line:4192
	global full_log_button #line:4193
	global upload_log_button #line:4194
	global Log_title #line:4195
	global Log_errors #line:4196
	toolsbg .setVisible (True )#line:4198
	Log_title =pyxbmct .Label ('[B][COLOR %s]קודי- כלים        [/COLOR][/B]'%DES_T_COLOR )#line:4200
	window .placeControl (Log_title ,15 ,4 ,10 ,10 )#line:4201
	Log_errors =pyxbmct .Label ('[COLOR %s][B]-מספר שגיאות בלוג[/B][/COLOR] %s'%(OTHER_BUTTONS_TEXT ,log_tools ()))#line:4203
	window .placeControl (Log_errors ,22 ,4 ,10 ,15 )#line:4204
	view_error_button =pyxbmct .Button ('[COLOR %s]צפיה בשגיאות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4206
	window .placeControl (view_error_button ,31 ,4 ,9 ,9 )#line:4207
	window .connect (view_error_button ,lambda :errorChecking (log =None ,count =None ,last =None ))#line:4208
	full_log_button =pyxbmct .Button ('[COLOR %s]צפיה בד"וח הלוג המלא[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4210
	window .placeControl (full_log_button ,40 ,4 ,9 ,9 )#line:4211
	window .connect (full_log_button ,lambda :LogViewer ())#line:4212
	upload_log_button =pyxbmct .Button ('[COLOR %s]העלאת דו"ח לוג מלא[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4214
	window .placeControl (upload_log_button ,49 ,4 ,9 ,9 )#line:4215
	window .connect (upload_log_button ,lambda :uploadLog .Main ())#line:4216
	global removeaddons_button #line:4220
	global removeaddondata_u_button #line:4221
	global removeaddondata_e_button #line:4222
	global checksources_button #line:4223
	global checkrepos_button #line:4224
	global forceupdate_button #line:4225
	global fixaddonupdate_button #line:4226
	global removeaddondata_all_button #line:4227
	global scan #line:4228
	global fix #line:4229
	global delet #line:4230
	global delet1 #line:4231
	global Addon #line:4232
	Addon =pyxbmct .Label ('[B][COLOR %s] תחזוקת הרחבות       [/COLOR][/B]'%DES_T_COLOR )#line:4234
	window .placeControl (Addon ,69 ,21 ,9 ,9 )#line:4235
	scan =pyxbmct .Label ('[B][COLOR %s] בצע סריקה עבור      [/COLOR][/B]'%DES_T_COLOR )#line:4237
	window .placeControl (scan ,75 ,4 ,9 ,10 )#line:4238
	checksources_button =pyxbmct .Button ('[COLOR %s]מקורות לא פעילים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4240
	window .placeControl (checksources_button ,82 ,3 ,9 ,10 )#line:4241
	window .connect (checksources_button ,lambda :wiz .checkSources ())#line:4242
	checkrepos_button =pyxbmct .Button ('[COLOR %s] ריפויים לא פעילים [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4244
	window .placeControl (checkrepos_button ,92 ,3 ,9 ,10 )#line:4245
	window .connect (checkrepos_button ,lambda :wiz .checkRepos ())#line:4246
	fix =pyxbmct .Label ('[B][COLOR %s]בצע/כפה תיקון     [/COLOR][/B]'%DES_T_COLOR )#line:4248
	window .placeControl (fix ,75 ,16 ,9 ,10 )#line:4249
	forceupdate_button =pyxbmct .Button ('[COLOR %s] עדכון הרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4251
	window .placeControl (forceupdate_button ,82 ,15 ,9 ,9 )#line:4252
	window .connect (forceupdate_button ,lambda :wiz .forceUpdate ())#line:4253
	fixaddonupdate_button =pyxbmct .Button ('[COLOR %s] הרחבות לא מתעדכנות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4255
	window .placeControl (fixaddonupdate_button ,92 ,15 ,9 ,9 )#line:4256
	window .connect (fixaddonupdate_button ,lambda :fixaddonupdate )#line:4257
	delet =pyxbmct .Label ('[B][COLOR %s]מחיקת מידע הרחבות[/COLOR][/B]'%DES_T_COLOR )#line:4259
	window .placeControl (delet ,75 ,27 ,9 ,10 )#line:4260
	removeaddons_button =pyxbmct .Button ('[COLOR %s] מחיקת הרחבות שנבחרו  [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4262
	window .placeControl (removeaddons_button ,82 ,26 ,9 ,9 )#line:4263
	window .connect (removeaddons_button ,lambda :removeAddonMenu )#line:4264
	removeaddondata_all_button =pyxbmct .Button ('[COLOR %s] כלל מידע ההרחבות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4266
	window .placeControl (removeaddondata_all_button ,92 ,26 ,9 ,9 )#line:4267
	window .connect (removeaddondata_all_button ,lambda :removeAddonData ('all'))#line:4268
	delet1 =pyxbmct .Label ('[B][COLOR %s]תחזוקת ספריות[/COLOR][/B]'%DES_T_COLOR )#line:4270
	window .placeControl (delet1 ,75 ,38 ,9 ,10 )#line:4271
	removeaddondata_u_button =pyxbmct .Button ('[COLOR %s] ספריות לא מותקנות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4273
	window .placeControl (removeaddondata_u_button ,82 ,37 ,9 ,9 )#line:4274
	window .connect (removeaddondata_u_button ,lambda :removeAddonData ('uninstalled'))#line:4275
	removeaddondata_e_button =pyxbmct .Button ('[COLOR %s] ספריות ריקות [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4277
	window .placeControl (removeaddondata_e_button ,92 ,37 ,9 ,9 )#line:4278
	window .connect (removeaddondata_e_button ,lambda :removeAddonData ('empty'))#line:4279
	global WhiteList #line:4282
	global whitelist_edit_button #line:4283
	global whitelist_view_button #line:4284
	global whitelist_clear_button #line:4285
	global whitelist_import_button #line:4286
	global whitelist_export_button #line:4287
	WhiteList =pyxbmct .Label ('[B][COLOR %s] כלים עבור רשימה לבנה [/COLOR][/B]'%DES_T_COLOR )#line:4290
	window .placeControl (WhiteList ,15 ,37 ,9 ,9 )#line:4291
	whitelist_edit_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: עריכה [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4293
	window .placeControl (whitelist_edit_button ,22 ,36 ,9 ,9 )#line:4294
	window .connect (whitelist_edit_button ,lambda :wiz .whiteList ('edit'))#line:4295
	whitelist_view_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: צפיה [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4297
	window .placeControl (whitelist_view_button ,31 ,36 ,9 ,9 )#line:4298
	window .connect (whitelist_view_button ,lambda :wiz .whiteList ('view'))#line:4299
	whitelist_clear_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: נקה [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4301
	window .placeControl (whitelist_clear_button ,40 ,36 ,9 ,9 )#line:4302
	window .connect (whitelist_clear_button ,lambda :wiz .whiteList ('clear'))#line:4303
	whitelist_import_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: יבוא [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4305
	window .placeControl (whitelist_import_button ,49 ,36 ,9 ,9 )#line:4306
	window .connect (whitelist_import_button ,lambda :wiz .whiteList ('Import'))#line:4307
	whitelist_export_button =pyxbmct .Button ('[COLOR %s]רשימה לבנה: יצוא [/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4309
	window .placeControl (whitelist_export_button ,58 ,36 ,9 ,9 )#line:4310
	window .connect (whitelist_export_button ,lambda :wiz .whiteList ('export'))#line:4311
	global Advan #line:4314
	global autoadvanced_buttonQ #line:4315
	global autoadvanced_button #line:4316
	global currentsettings_button #line:4317
	global removeadvanced_button #line:4318
	Advan =pyxbmct .Label ('[B][COLOR %s]כלי הגדרת באפר[/COLOR][/B]'%DES_T_COLOR )#line:4320
	window .placeControl (Advan ,15 ,22 ,9 ,13 )#line:4321
	autoadvanced_buttonQ =pyxbmct .Button ('[COLOR %s]באפר בסיסי[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4323
	window .placeControl (autoadvanced_buttonQ ,22 ,21 ,9 ,9 )#line:4324
	window .connect (autoadvanced_buttonQ ,lambda :notify .autoConfig2 ())#line:4325
	autoadvanced_button =pyxbmct .Button ('[COLOR %s]הגדרת באפר[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4327
	window .placeControl (autoadvanced_button ,31 ,21 ,9 ,9 )#line:4328
	window .connect (autoadvanced_button ,lambda :notify .autoConfig ())#line:4329
	currentsettings_button =pyxbmct .Button ('[COLOR %s]הגדרות נוכחיות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4331
	window .placeControl (currentsettings_button ,40 ,21 ,9 ,9 )#line:4332
	window .connect (currentsettings_button ,lambda :viewAdvanced ())#line:4333
	removeadvanced_button =pyxbmct .Button ('[COLOR %s]מחיקת הגדרות[/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4335
	window .placeControl (removeadvanced_button ,49 ,21 ,9 ,9 )#line:4336
	window .connect (removeadvanced_button ,lambda :removeAdvanced ())#line:4337
	view_error_button .setVisible (True )#line:4341
	full_log_button .setVisible (True )#line:4342
	upload_log_button .setVisible (True )#line:4343
	removeaddons_button .setVisible (True )#line:4345
	removeaddondata_all_button .setVisible (True )#line:4346
	removeaddondata_u_button .setVisible (True )#line:4347
	removeaddondata_e_button .setVisible (True )#line:4348
	checksources_button .setVisible (True )#line:4350
	checkrepos_button .setVisible (True )#line:4351
	forceupdate_button .setVisible (True )#line:4352
	fixaddonupdate_button .setVisible (True )#line:4353
	Log_title .setVisible (True )#line:4355
	Log_errors .setVisible (True )#line:4356
	Addon .setVisible (True )#line:4359
	scan .setVisible (True )#line:4360
	fix .setVisible (True )#line:4361
	delet .setVisible (True )#line:4362
	delet1 .setVisible (True )#line:4363
	WhiteList .setVisible (True )#line:4364
	whitelist_edit_button .setVisible (True )#line:4366
	whitelist_view_button .setVisible (True )#line:4367
	whitelist_clear_button .setVisible (True )#line:4368
	whitelist_import_button .setVisible (True )#line:4369
	whitelist_export_button .setVisible (True )#line:4370
	Advan .setVisible (True )#line:4372
	autoadvanced_buttonQ .setVisible (True )#line:4373
	autoadvanced_button .setVisible (True )#line:4374
	currentsettings_button .setVisible (True )#line:4375
	removeadvanced_button .setVisible (True )#line:4376
	ToolsButton .controlDown (view_error_button )#line:4378
	view_error_button .controlUp (ToolsButton )#line:4380
	view_error_button .controlDown (full_log_button )#line:4381
	view_error_button .controlRight (autoadvanced_button )#line:4382
	full_log_button .controlUp (view_error_button )#line:4384
	full_log_button .controlDown (upload_log_button )#line:4385
	full_log_button .controlRight (currentsettings_button )#line:4386
	upload_log_button .controlUp (full_log_button )#line:4388
	upload_log_button .controlDown (checksources_button )#line:4389
	upload_log_button .controlRight (removeadvanced_button )#line:4390
	autoadvanced_buttonQ .controlUp (ToolsButton )#line:4392
	autoadvanced_buttonQ .controlLeft (view_error_button )#line:4393
	autoadvanced_buttonQ .controlDown (autoadvanced_button )#line:4394
	autoadvanced_buttonQ .controlRight (whitelist_edit_button )#line:4395
	autoadvanced_button .controlUp (autoadvanced_buttonQ )#line:4397
	autoadvanced_button .controlLeft (view_error_button )#line:4398
	autoadvanced_button .controlDown (currentsettings_button )#line:4399
	autoadvanced_button .controlRight (whitelist_view_button )#line:4400
	currentsettings_button .controlUp (autoadvanced_button )#line:4402
	currentsettings_button .controlLeft (full_log_button )#line:4403
	currentsettings_button .controlDown (removeadvanced_button )#line:4404
	currentsettings_button .controlRight (whitelist_clear_button )#line:4405
	removeadvanced_button .controlUp (currentsettings_button )#line:4407
	removeadvanced_button .controlLeft (upload_log_button )#line:4408
	removeadvanced_button .controlDown (forceupdate_button )#line:4409
	removeadvanced_button .controlRight (whitelist_import_button )#line:4410
	whitelist_edit_button .controlUp (ToolsButton )#line:4412
	whitelist_edit_button .controlLeft (autoadvanced_buttonQ )#line:4413
	whitelist_edit_button .controlDown (whitelist_view_button )#line:4414
	whitelist_view_button .controlUp (whitelist_edit_button )#line:4416
	whitelist_view_button .controlLeft (autoadvanced_button )#line:4417
	whitelist_view_button .controlDown (whitelist_clear_button )#line:4418
	whitelist_clear_button .controlUp (whitelist_view_button )#line:4420
	whitelist_clear_button .controlLeft (currentsettings_button )#line:4421
	whitelist_clear_button .controlDown (whitelist_import_button )#line:4422
	whitelist_import_button .controlUp (whitelist_clear_button )#line:4424
	whitelist_import_button .controlLeft (removeadvanced_button )#line:4425
	whitelist_import_button .controlDown (whitelist_export_button )#line:4426
	whitelist_export_button .controlUp (whitelist_import_button )#line:4428
	whitelist_export_button .controlLeft (removeadvanced_button )#line:4429
	whitelist_export_button .controlDown (removeaddondata_u_button )#line:4430
	checksources_button .controlUp (upload_log_button )#line:4432
	checksources_button .controlDown (checkrepos_button )#line:4433
	checksources_button .controlRight (forceupdate_button )#line:4434
	checkrepos_button .controlUp (checksources_button )#line:4436
	checkrepos_button .controlRight (fixaddonupdate_button )#line:4437
	forceupdate_button .controlUp (removeadvanced_button )#line:4439
	forceupdate_button .controlLeft (checksources_button )#line:4440
	forceupdate_button .controlDown (fixaddonupdate_button )#line:4441
	forceupdate_button .controlRight (removeaddons_button )#line:4442
	fixaddonupdate_button .controlUp (forceupdate_button )#line:4444
	fixaddonupdate_button .controlLeft (checkrepos_button )#line:4445
	fixaddonupdate_button .controlRight (removeaddondata_all_button )#line:4446
	removeaddons_button .controlUp (removeadvanced_button )#line:4448
	removeaddons_button .controlLeft (forceupdate_button )#line:4449
	removeaddons_button .controlDown (removeaddondata_all_button )#line:4450
	removeaddons_button .controlRight (removeaddondata_u_button )#line:4451
	removeaddondata_all_button .controlUp (removeaddons_button )#line:4453
	removeaddondata_all_button .controlLeft (fixaddonupdate_button )#line:4454
	removeaddondata_all_button .controlRight (removeaddondata_e_button )#line:4455
	removeaddondata_u_button .controlUp (whitelist_export_button )#line:4457
	removeaddondata_u_button .controlLeft (removeaddons_button )#line:4458
	removeaddondata_u_button .controlDown (removeaddondata_e_button )#line:4459
	removeaddondata_e_button .controlUp (removeaddondata_u_button )#line:4461
	removeaddondata_e_button .controlLeft (removeaddondata_all_button )#line:4462
def Installables ():#line:4464
	global AddonButton #line:4466
	global APKButton #line:4467
	global ROMButton #line:4468
	global EmuButton #line:4469
	global Bname #line:4470
	HIDEALL ()#line:4471
	listbgA .setVisible (True )#line:4473
	buildbgA .setVisible (True )#line:4474
	AddonButton =pyxbmct .Button ('[COLOR %s][B]Wizards[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:4476
	window .placeControl (AddonButton ,12 ,9 ,7 ,8 )#line:4477
	window .connect (AddonButton ,lambda :AddonList ())#line:4478
	APKButton =pyxbmct .Button ('[COLOR %s][B]אפליקציות[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:4480
	window .placeControl (APKButton ,12 ,17 ,7 ,8 )#line:4481
	window .connect (APKButton ,lambda :APKList ())#line:4482
	ROMButton =pyxbmct .Button ('[COLOR %s][B]עדכון מהיר[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:4484
	window .placeControl (ROMButton ,12 ,25 ,7 ,8 )#line:4485
	window .connect (ROMButton ,lambda :buildWizard (ADDON .getSetting ('buildname'),'gui'))#line:4486
	EmuButton =pyxbmct .Button ('[COLOR %s][B]-[/B][/COLOR]'%OTHER_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:4488
	window .placeControl (EmuButton ,12 ,33 ,7 ,8 )#line:4489
	window .connect (EmuButton ,lambda :EmuList ())#line:4490
	InstallablesButton .controlDown (AddonButton )#line:4492
	AddonButton .controlUp (InstallablesButton )#line:4493
	APKButton .controlUp (InstallablesButton )#line:4494
	ROMButton .controlUp (InstallablesButton )#line:4495
	EmuButton .controlUp (InstallablesButton )#line:4496
	AddonButton .controlRight (APKButton )#line:4498
	AddonButton .controlLeft (EmuButton )#line:4499
	APKButton .controlRight (ROMButton )#line:4501
	APKButton .controlLeft (AddonButton )#line:4502
	ROMButton .controlRight (EmuButton )#line:4504
	ROMButton .controlLeft (APKButton )#line:4505
	EmuButton .controlRight (AddonButton )#line:4507
	EmuButton .controlLeft (ROMButton )#line:4508
window .connectEventList ([pyxbmct .ACTION_MOVE_DOWN ,pyxbmct .ACTION_MOVE_UP ,pyxbmct .ACTION_MOUSE_WHEEL_DOWN ,pyxbmct .ACTION_MOUSE_WHEEL_UP ,pyxbmct .ACTION_MOUSE_MOVE ],list_update )#line:4517
global ver #line:4520
global fan #line:4521
global listbg #line:4522
global buildbg #line:4523
global maintbg #line:4524
global speedthumb #line:4525
global sysinfobg #line:4526
global netinfobg #line:4527
global splash #line:4528
global bakresbg #line:4529
global toolsbg #line:4530
global wizinfogb #line:4531
global listbgA #line:4532
global buildbgA #line:4533
global buildinfobg #line:4534
window .setGeometry (1280 ,720 ,100 ,50 )#line:4537
fan =pyxbmct .Image (MAINBG )#line:4538
window .placeControl (fan ,-10 ,-6 ,125 ,62 )#line:4539
wiz .FTGlog ('Window Opened')#line:4540
listbg =pyxbmct .Image (LISTBG )#line:4544
window .placeControl (listbg ,10 ,0 ,80 ,17 )#line:4545
buildbg =pyxbmct .Image (LISTBG )#line:4547
window .placeControl (buildbg ,10 ,16 ,80 ,35 )#line:4548
buildinfobg =pyxbmct .Image (LISTBG )#line:4550
window .placeControl (buildinfobg ,88 ,0 ,23 ,50 )#line:4551
listbgA =pyxbmct .Image (LISTBG )#line:4553
window .placeControl (listbgA ,20 ,0 ,80 ,17 )#line:4554
buildbgA =pyxbmct .Image (LISTBG )#line:4556
window .placeControl (buildbgA ,20 ,16 ,80 ,35 )#line:4557
maintbg =pyxbmct .Image (LISTBG )#line:4559
window .placeControl (maintbg ,70 ,19 ,40 ,32 )#line:4560
sysinfobg =pyxbmct .Image (LISTBG )#line:4562
window .placeControl (sysinfobg ,10 ,19 ,60 ,32 )#line:4563
netinfobg =pyxbmct .Image (LISTBG )#line:4565
window .placeControl (netinfobg ,10 ,0 ,60 ,20 )#line:4566
speedthumb =pyxbmct .Image (SpeedBG )#line:4568
window .placeControl (speedthumb ,70 ,0 ,40 ,20 )#line:4569
splash =pyxbmct .Image (SPLASH )#line:4571
window .placeControl (splash ,10 ,1 ,100 ,48 )#line:4572
bakresbg =pyxbmct .Image (LISTBG )#line:4574
window .placeControl (bakresbg ,10 ,1 ,100 ,48 )#line:4575
toolsbg =pyxbmct .Image (LISTBG )#line:4577
window .placeControl (toolsbg ,10 ,1 ,100 ,48 )#line:4578
wizinfogb =pyxbmct .Image (LISTBG )#line:4580
window .placeControl (wizinfogb ,-6 ,9 ,9 ,32 )#line:4581
wiz_title =pyxbmct .Label ('[COLOR %s][B]%s[/B][/COLOR]'%(uservar .WIZTITLE_COLOR ,uservar .WIZTITLE ))#line:4583
window .placeControl (wiz_title ,-5 ,11 ,7 ,20 )#line:4584
wiz_ver =pyxbmct .Label ('[COLOR %s]Version: [COLOR %s][B]%s[/B][/COLOR]'%(uservar .VERTITLE_COLOR ,uservar .VER_NUMBER_COLOR ,VERSION ))#line:4586
window .placeControl (wiz_ver ,-5 ,31 ,7 ,10 )#line:4587
no_txt =pyxbmct .Image (NOTXT )#line:4589
window .placeControl (no_txt ,23 ,8 ,80 ,35 )#line:4590
global MaintButton #line:4597
global BackResButton #line:4598
global ToolsButton #line:4599
global BuildsButton #line:4600
global Toolbox #line:4601
BuildsButton =pyxbmct .Button ('[COLOR %s][B]בילדים[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4604
window .placeControl (BuildsButton ,-2 ,1 ,13 ,8 )#line:4605
window .connect (BuildsButton ,lambda :BuildList ())#line:4606
MaintButton =pyxbmct .Button ('[COLOR %s][B]כלי מערכת[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4608
window .placeControl (MaintButton ,2 ,9 ,9 ,8 )#line:4609
window .connect (MaintButton ,lambda :Maint ())#line:4610
BackResButton =pyxbmct .Button ('[COLOR %s][B]גיבוי/שחזור[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4612
window .placeControl (BackResButton ,2 ,17 ,9 ,8 )#line:4613
window .connect (BackResButton ,lambda :BackRes ())#line:4614
ToolsButton =pyxbmct .Button ('[COLOR %s][B]כלים[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4616
window .placeControl (ToolsButton ,2 ,25 ,9 ,8 )#line:4617
window .connect (ToolsButton ,lambda :Tools ())#line:4618
InstallablesButton =pyxbmct .Button ('[COLOR %s][B]התקנות[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =FBUTTON ,noFocusTexture =BUTTON )#line:4620
window .placeControl (InstallablesButton ,2 ,33 ,9 ,8 )#line:4621
window .connect (InstallablesButton ,lambda :Installables ())#line:4622
CloseButton =pyxbmct .Button ('[COLOR %s][B]סגירה[/B][/COLOR]'%MAIN_BUTTONS_TEXT ,focusTexture =EXIT ,noFocusTexture =BUTTON )#line:4624
window .placeControl (CloseButton ,-2 ,41 ,13 ,8 )#line:4625
window .connect (CloseButton ,window .close )#line:4626
BuildsButton .controlRight (MaintButton )#line:4628
BuildsButton .controlLeft (CloseButton )#line:4629
MaintButton .controlRight (BackResButton )#line:4631
MaintButton .controlLeft (BuildsButton )#line:4632
BackResButton .controlRight (ToolsButton )#line:4634
BackResButton .controlLeft (MaintButton )#line:4635
ToolsButton .controlRight (InstallablesButton )#line:4637
ToolsButton .controlLeft (BackResButton )#line:4638
InstallablesButton .controlRight (CloseButton )#line:4640
InstallablesButton .controlLeft (ToolsButton )#line:4641
CloseButton .controlRight (BuildsButton )#line:4643
CloseButton .controlLeft (InstallablesButton )#line:4644
def testnotify ():#line:4657
	OOOOO00000O0O00O0 =wiz .workingURL (NOTIFICATION )#line:4658
	if OOOOO00000O0O00O0 ==True :#line:4659
		try :#line:4660
			O00000000O0O0000O ,O0000O0OO000O0O0O =wiz .splitNotify (NOTIFICATION )#line:4661
			if O00000000O0O0000O ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:4662
			notify .notification (O0000O0OO000O0O0O ,True )#line:4663
		except Exception as O000O0OO00O0O0O00 :#line:4664
			wiz .log ("Error on Notifications Window: %s"%str (O000O0OO00O0O0O00 ),xbmc .LOGERROR )#line:4665
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:4666
def servicemanual ():#line:4667
	OOOOO00O00O0O000O =wiz .workingURL (NOTIFICATION2 )#line:4668
	if OOOOO00O00O0O000O ==True :#line:4669
		try :#line:4670
			O00OO00O00O00OO00 ,O00OOO00O0O00000O =wiz .splitNotify (NOTIFICATION2 )#line:4671
			if O00OO00O00O00OO00 ==False :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Notification: Not Formated Correctly[/COLOR]"%COLOR2 );return #line:4672
			notify .notification2 (O00OOO00O0O00000O ,True )#line:4673
		except Exception as O00OOO00O00000OO0 :#line:4674
			wiz .log ("Error on Notifications Window: %s"%str (O00OOO00O00000OO0 ),xbmc .LOGERROR )#line:4675
	else :wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Invalid URL for Notification[/COLOR]"%COLOR2 )#line:4676
def testupdate ():#line:4678
	if BUILDNAME =="":#line:4679
		notify .updateWindow ()#line:4680
	else :#line:4681
		notify .updateWindow (BUILDNAME ,BUILDVERSION ,BUILDLATEST ,wiz .checkBuild (BUILDNAME ,'icon'),wiz .checkBuild (BUILDNAME ,'fanart'))#line:4682
def testfirst ():#line:4684
	notify .firstRun ()#line:4685
def testfirstRun ():#line:4687
	notify .firstRunSettings ()#line:4688
	################!!!!!NEVER DELETE!!!!############
window .connect (pyxbmct .ACTION_NAV_BACK ,window .close )#line:4696
window .setFocus (BuildsButton )#line:4698
HIDEALL ()#line:4701
splash .setVisible (True )#line:4702
if mode =='index':index ()#line:4712
elif mode =='wizardupdate':wiz .wizardUpdate ()#line:4713
elif mode =='builds':buildMenu ()#line:4714
elif mode =='viewbuild':viewBuild (name )#line:4715
elif mode =='buildinfo':buildInfo (name )#line:4716
elif mode =='buildpreview':buildVideo (name )#line:4717
elif mode =='install':buildWizard (name ,url )#line:4718
elif mode =='theme':buildWizard (name ,mode ,url )#line:4719
elif mode =='viewthirdparty':viewThirdList (name )#line:4720
elif mode =='installthird':thirdPartyInstall (name ,url )#line:4721
elif mode =='editthird':editThirdParty (name );wiz .refresh ()#line:4722
elif mode =='maint':maintMenu (name )#line:4723
elif mode =='kodi17fix':wiz .kodi17Fix ()#line:4724
elif mode =='unknownsources':skinSwitch .swapUS ()#line:4725
elif mode =='advancedsetting':advancedWindow (name )#line:4726
elif mode =='autoadvanced1':showAutoAdvanced1 ();wiz .refresh ()#line:4727
elif mode =='removeadvanced':removeAdvanced ();wiz .refresh ()#line:4728
elif mode =='asciicheck':wiz .asciiCheck ()#line:4729
elif mode =='backupbuild':wiz .backUpOptions ('build')#line:4730
elif mode =='backupgui':wiz .backUpOptions ('guifix')#line:4731
elif mode =='backuptheme':wiz .backUpOptions ('theme')#line:4732
elif mode =='backupaddonpack':wiz .backUpOptions ('addon pack')#line:4733
elif mode =='backupaddon':wiz .backUpOptions ('addondata')#line:4734
elif mode =='oldThumbs':wiz .oldThumbs ()#line:4735
elif mode =='clearbackup':wiz .cleanupBackup ()#line:4736
elif mode =='convertpath':wiz .convertSpecial (HOME )#line:4737
elif mode =='currentsettings':viewAdvanced ()#line:4738
elif mode =='fullclean':totalClean ();wiz .refresh ()#line:4739
elif mode =='clearcache':clearCache ();wiz .refresh ()#line:4740
elif mode =='clearpackages':wiz .clearPackages ();wiz .refresh ()#line:4741
elif mode =='clearcrash':wiz .clearCrash ();wiz .refresh ()#line:4742
elif mode =='clearthumb':clearThumb ();wiz .refresh ()#line:4743
elif mode =='cleararchive':clearArchive ();wiz .refresh ()#line:4744
elif mode =='checksources':wiz .checkSources ();wiz .refresh ()#line:4745
elif mode =='checkrepos':wiz .checkRepos ();wiz .refresh ()#line:4746
elif mode =='freshstart':freshStart ()#line:4747
elif mode =='forceupdate':wiz .forceUpdate ()#line:4748
elif mode =='forceprofile':wiz .reloadProfile (wiz .getInfo ('System.ProfileName'))#line:4749
elif mode =='forceclose':wiz .killxbmc ()#line:4750
elif mode =='forceskin':wiz .ebi ("ReloadSkin()");wiz .refresh ()#line:4751
elif mode =='hidepassword':wiz .hidePassword ()#line:4752
elif mode =='unhidepassword':wiz .unhidePassword ()#line:4753
elif mode =='enableaddons':enableAddons ()#line:4754
elif mode =='toggleaddon':wiz .toggleAddon (name ,url );wiz .refresh ()#line:4755
elif mode =='togglecache':toggleCache (name );wiz .refresh ()#line:4756
elif mode =='toggleadult':wiz .toggleAdult ();wiz .refresh ()#line:4757
elif mode =='changefeq':changeFeq ();wiz .refresh ()#line:4758
elif mode =='uploadlog':uploadLog .Main ()#line:4759
elif mode =='viewlog':LogViewer ()#line:4760
elif mode =='viewwizlog':LogViewer (WIZLOG )#line:4761
elif mode =='viewerrorlog':errorChecking ()#line:4762
elif mode =='viewerrorlast':errorChecking (last =True )#line:4763
elif mode =='clearwizlog':f =open (WIZLOG ,'w');f .close ();wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Wizard Log Cleared![/COLOR]"%COLOR2 )#line:4764
elif mode =='purgedb':purgeDb ()#line:4765
elif mode =='fixaddonupdate':fixUpdate ()#line:4766
elif mode =='removeaddons':removeAddonMenu ()#line:4767
elif mode =='removeaddon':removeAddon (name )#line:4768
elif mode =='removeaddondata':removeAddonDataMenu ()#line:4769
elif mode =='removedata':removeAddonData (name )#line:4770
elif mode =='resetaddon':total =wiz .cleanHouse (ADDONDATA ,ignore =True );wiz .LogNotify ("[COLOR %s]%s[/COLOR]"%(COLOR1 ,ADDONTITLE ),"[COLOR %s]Addon_Data reset[/COLOR]"%COLOR2 )#line:4771
elif mode =='systeminfo':systemInfo ()#line:4772
elif mode =='restorezip':restoreit ('build')#line:4773
elif mode =='restoregui':restoreit ('gui')#line:4774
elif mode =='restoreaddon':restoreit ('addondata')#line:4775
elif mode =='restoreextzip':restoreextit ('build')#line:4776
elif mode =='restoreextgui':restoreextit ('gui')#line:4777
elif mode =='restoreextaddon':restoreextit ('addondata')#line:4778
elif mode =='writeadvanced':writeAdvanced (name ,url )#line:4779
elif mode =='speedtest':speedTest ()#line:4780
elif mode =='speed':speed ();wiz .refresh ()#line:4781
elif mode =='clearspeedtest':clearSpeedTest ();wiz .refresh ()#line:4782
elif mode =='viewspeedtest':viewSpeedTest (name );wiz .refresh ()#line:4783
elif mode =='apk':apkMenu (name ,url )#line:4784
elif mode =='apkscrape':apkScraper (name )#line:4785
elif mode =='apkinstall':apkInstaller (name ,url )#line:4786
elif mode =='apkinstall1':apkInstaller1 (name ,url )#line:4787
elif mode =='rominstall':romInstaller (name ,url )#line:4788
elif mode =='youtube':youtubeMenu (name ,url )#line:4789
elif mode =='viewVideo':playVideo (url )#line:4790
elif mode =='addons':addonMenu (name ,url )#line:4791
elif mode =='addonpack':packInstaller (name ,url )#line:4792
elif mode =='skinpack':skinInstaller (name ,url )#line:4793
elif mode =='addoninstall':addonInstaller (name ,url )#line:4794
elif mode =='savedata':saveMenu ()#line:4795
elif mode =='togglesetting':wiz .setS (name ,'false'if wiz .getS (name )=='true'else 'true');wiz .refresh ()#line:4796
elif mode =='managedata':manageSaveData (name )#line:4797
elif mode =='whitelist':wiz .whiteList (name )#line:4798
elif mode =='trakt':traktMenu ()#line:4799
elif mode =='savetrakt':traktit .traktIt ('update',name )#line:4800
elif mode =='restoretrakt':traktit .traktIt ('restore',name )#line:4801
elif mode =='addontrakt':traktit .traktIt ('clearaddon',name )#line:4802
elif mode =='cleartrakt':traktit .clearSaved (name )#line:4803
elif mode =='authtrakt':traktit .activateTrakt (name );wiz .refresh ()#line:4804
elif mode =='updatetrakt':traktit .autoUpdate ('all')#line:4805
elif mode =='importtrakt':traktit .importlist (name );wiz .refresh ()#line:4806
elif mode =='realdebrid':realMenu ()#line:4807
elif mode =='savedebrid':debridit .debridIt ('update',name )#line:4808
elif mode =='restoredebrid':debridit .debridIt ('restore',name )#line:4809
elif mode =='addondebrid':debridit .debridIt ('clearaddon',name )#line:4810
elif mode =='cleardebrid':debridit .clearSaved (name )#line:4811
elif mode =='authdebrid':debridit .activateDebrid (name );wiz .refresh ()#line:4812
elif mode =='updatedebrid':debridit .autoUpdate ('all')#line:4813
elif mode =='importdebrid':debridit .importlist (name );wiz .refresh ()#line:4814
elif mode =='alluc':allucMenu ()#line:4815
elif mode =='savealluc':allucit .allucIt ('update',name )#line:4816
elif mode =='restorealluc':allucit .allucIt ('restore',name )#line:4817
elif mode =='addonalluc':allucit .allucIt ('clearaddon',name )#line:4818
elif mode =='clearalluc':allucit .clearSaved (name )#line:4819
elif mode =='authalluc':allucit .activateAlluc (name );wiz .refresh ()#line:4820
elif mode =='updatealluc':allucit .autoUpdate ('all')#line:4821
elif mode =='importalluc':allucit .importlist (name );wiz .refresh ()#line:4822
elif mode =='login':loginMenu ()#line:4823
elif mode =='savelogin':loginit .loginIt ('update',name )#line:4824
elif mode =='restorelogin':loginit .loginIt ('restore',name )#line:4825
elif mode =='addonlogin':loginit .loginIt ('clearaddon',name )#line:4826
elif mode =='clearlogin':loginit .clearSaved (name )#line:4827
elif mode =='authlogin':loginit .activateLogin (name );wiz .refresh ()#line:4828
elif mode =='updatelogin':loginit .autoUpdate ('all')#line:4829
elif mode =='importlogin':loginit .importlist (name );wiz .refresh ()#line:4830
elif mode =='contact':notify .contact (CONTACT )#line:4831
elif mode =='settings':wiz .openS (name );wiz .refresh ()#line:4832
elif mode =='forcetext':wiz .forceText ()#line:4833
elif mode =='opensettings':id =eval (url .upper ()+'ID')[name ]['plugin'];addonid =wiz .addonId (id );addonid .openSettings ();wiz .refresh ()#line:4834
elif mode =='developer':developer ()#line:4835
elif mode =='converttext':wiz .convertText ()#line:4836
elif mode =='createqr':wiz .createQR ()#line:4837
elif mode =='testnotify':testnotify ()#line:4838
elif mode =='testupdate':testupdate ()#line:4839
elif mode =='testfirst':testfirst ()#line:4840
elif mode =='testfirstrun':testfirstRun ()#line:4841
elif mode =='backup':backup ()#line:4843
elif mode =='addon':addon ()#line:4844
elif mode =='misc':misc ()#line:4845
elif mode =='tweaks':tweaks ()#line:4846
elif mode =='net':net_tools ()#line:4847
elif mode =='viewIP':viewIP ()#line:4848
elif mode =='backup':backup ()#line:4849
elif mode =='apk1':apkMenu ()#line:4850
elif mode =='apkgame':APKGAME (url )#line:4851
elif mode =='select':APKSELECT2 (url )#line:4852
elif mode =='grab':APKGRAB (name ,url )#line:4853
elif mode =='rom':romMenu (url )#line:4854
elif mode =='apkscrape':APK ()#line:4855
elif mode =='apkshow':apkshowMenu (url )#line:4856
elif mode =='apkkodi':apkkodiMenu ()#line:4857
elif mode =='apkinstall':apkInstaller (name ,url ,"None")#line:4858
elif mode =='APPINSTALLER':APPINSTALL (name ,url ,description )#line:4859
elif mode =='ftgmod':ftgmod ()#line:4860
elif mode =='viewpack':viewpack ()#line:4861
elif mode =='addonpackwiz':addonpackwiz ()#line:4862
elif mode =='FavsMenu':FavsMenu ()#line:4863
elif mode =='savefav':wiz .BACKUPFAV ()#line:4864
elif mode =='restorefav':wiz .RESTOREFAV ()#line:4865
elif mode =='clearfav':wiz .DELFAV ()#line:4866
elif mode =='apkfiles':apkfiles ()#line:4867
elif mode =='retromenu':retromenu ()#line:4868
elif mode =='emumenu':emumenu ()#line:4869
elif mode =='rompackmenu':rompackmenu ()#line:4870
elif mode =='UNZIPROM':UNZIPROM ()#line:4871
elif mode =='ftgmod':ftgmod ()#line:4872
elif mode =='GetList':GetList (url )#line:4873
elif mode =='autoadvanced':notify .autoConfig2 ();wiz .refresh ()#line:4874
elif mode =='autoconfig':autoconfig ()#line:4875
elif mode =='sswap':skinSwitch .popUPmenu ()#line:4876
list_update ()#line:4879
window .connect (pyxbmct .ACTION_NAV_BACK ,window .close )#line:4880
window .doModal ()#line:4881
del window #line:4882
